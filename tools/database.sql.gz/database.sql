# WordPress MySQL database migration
#
# Generated: Saturday 9. March 2024 05:28 UTC
# Hostname: mariadb
# Database: `wordpress`
# URL: //localhost:82
# Path: /var/www/html
# Tables: wp_actionscheduler_actions, wp_actionscheduler_claims, wp_actionscheduler_groups, wp_actionscheduler_logs, wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_wc_admin_note_actions, wp_wc_admin_notes, wp_wc_category_lookup, wp_wc_customer_lookup, wp_wc_download_log, wp_wc_order_addresses, wp_wc_order_coupon_lookup, wp_wc_order_operational_data, wp_wc_order_product_lookup, wp_wc_order_stats, wp_wc_order_tax_lookup, wp_wc_orders, wp_wc_orders_meta, wp_wc_product_attributes_lookup, wp_wc_product_download_directories, wp_wc_product_meta_lookup, wp_wc_rate_limits, wp_wc_reserved_stock, wp_wc_tax_rate_classes, wp_wc_webhooks, wp_woocommerce_api_keys, wp_woocommerce_attribute_taxonomies, wp_woocommerce_downloadable_product_permissions, wp_woocommerce_log, wp_woocommerce_order_itemmeta, wp_woocommerce_order_items, wp_woocommerce_payment_tokenmeta, wp_woocommerce_payment_tokens, wp_woocommerce_sessions, wp_woocommerce_shipping_zone_locations, wp_woocommerce_shipping_zone_methods, wp_woocommerce_shipping_zones, wp_woocommerce_tax_rate_locations, wp_woocommerce_tax_rates
# Table Prefix: wp_
# Post Types: revision, attachment, page, post, product, product_variation, shop_order_placehold, wp_block, wp_global_styles, wp_navigation, wp_template, wp_template_part
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_actionscheduler_actions`
#

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;


#
# Table structure of table `wp_actionscheduler_actions`
#

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) NOT NULL,
  `status` varchar(20) NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `priority` tinyint(3) unsigned NOT NULL DEFAULT 10,
  `args` varchar(191) DEFAULT NULL,
  `schedule` longtext DEFAULT NULL,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `extended_args` varchar(8000) DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook_status_scheduled_date_gmt` (`hook`(163),`status`,`scheduled_date_gmt`),
  KEY `status_scheduled_date_gmt` (`status`,`scheduled_date_gmt`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_actionscheduler_actions`
#
INSERT INTO `wp_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `priority`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(11, 'action_scheduler/migration_hook', 'pending', '2024-03-08 12:22:02', '2024-03-08 12:22:02', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709900522;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709900522;s:19:"scheduled_timestamp";i:1709900522;s:9:"timestamp";i:1709900522;}', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(12, 'woocommerce_cleanup_draft_orders', 'pending', '2024-03-08 12:21:06', '2024-03-08 12:21:06', 10, '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1709900466;s:18:"\0*\0first_timestamp";i:1709900466;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1709900466;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1709900466;s:15:"first_timestamp";i:1709900466;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1709900466;s:19:"interval_in_seconds";i:86400;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(13, 'woocommerce_update_marketplace_suggestions', 'pending', '2024-03-08 13:11:36', '2024-03-08 13:11:36', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903496;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903496;s:19:"scheduled_timestamp";i:1709903496;s:9:"timestamp";i:1709903496;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(14, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:32', '2024-03-08 13:17:32', 10, '[20,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903852;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903852;s:19:"scheduled_timestamp";i:1709903852;s:9:"timestamp";i:1709903852;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(15, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:32', '2024-03-08 13:17:32', 10, '[21,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903852;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903852;s:19:"scheduled_timestamp";i:1709903852;s:9:"timestamp";i:1709903852;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(16, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:32', '2024-03-08 13:17:32', 10, '[22,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903852;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903852;s:19:"scheduled_timestamp";i:1709903852;s:9:"timestamp";i:1709903852;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(17, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:32', '2024-03-08 13:17:32', 10, '[23,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903852;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903852;s:19:"scheduled_timestamp";i:1709903852;s:9:"timestamp";i:1709903852;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(18, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:33', '2024-03-08 13:17:33', 10, '[24,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903853;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903853;s:19:"scheduled_timestamp";i:1709903853;s:9:"timestamp";i:1709903853;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(19, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:33', '2024-03-08 13:17:33', 10, '[25,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903853;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903853;s:19:"scheduled_timestamp";i:1709903853;s:9:"timestamp";i:1709903853;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(20, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:33', '2024-03-08 13:17:33', 10, '[26,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903853;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903853;s:19:"scheduled_timestamp";i:1709903853;s:9:"timestamp";i:1709903853;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(21, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:33', '2024-03-08 13:17:33', 10, '[27,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903853;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903853;s:19:"scheduled_timestamp";i:1709903853;s:9:"timestamp";i:1709903853;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(22, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:33', '2024-03-08 13:17:33', 10, '[28,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903853;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903853;s:19:"scheduled_timestamp";i:1709903853;s:9:"timestamp";i:1709903853;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(23, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:33', '2024-03-08 13:17:33', 10, '[29,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903853;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903853;s:19:"scheduled_timestamp";i:1709903853;s:9:"timestamp";i:1709903853;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(24, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:33', '2024-03-08 13:17:33', 10, '[30,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903853;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903853;s:19:"scheduled_timestamp";i:1709903853;s:9:"timestamp";i:1709903853;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(25, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:33', '2024-03-08 13:17:33', 10, '[31,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903853;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903853;s:19:"scheduled_timestamp";i:1709903853;s:9:"timestamp";i:1709903853;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(26, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:33', '2024-03-08 13:17:33', 10, '[32,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903853;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903853;s:19:"scheduled_timestamp";i:1709903853;s:9:"timestamp";i:1709903853;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(27, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:34', '2024-03-08 13:17:34', 10, '[33,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903854;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903854;s:19:"scheduled_timestamp";i:1709903854;s:9:"timestamp";i:1709903854;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(28, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:34', '2024-03-08 13:17:34', 10, '[34,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903854;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903854;s:19:"scheduled_timestamp";i:1709903854;s:9:"timestamp";i:1709903854;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(29, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:34', '2024-03-08 13:17:34', 10, '[35,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903854;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903854;s:19:"scheduled_timestamp";i:1709903854;s:9:"timestamp";i:1709903854;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(30, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:34', '2024-03-08 13:17:34', 10, '[36,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903854;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903854;s:19:"scheduled_timestamp";i:1709903854;s:9:"timestamp";i:1709903854;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(31, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:34', '2024-03-08 13:17:34', 10, '[37,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903854;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903854;s:19:"scheduled_timestamp";i:1709903854;s:9:"timestamp";i:1709903854;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(32, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:34', '2024-03-08 13:17:34', 10, '[38,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903854;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903854;s:19:"scheduled_timestamp";i:1709903854;s:9:"timestamp";i:1709903854;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(33, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:34', '2024-03-08 13:17:34', 10, '[39,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903854;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903854;s:19:"scheduled_timestamp";i:1709903854;s:9:"timestamp";i:1709903854;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(34, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:34', '2024-03-08 13:17:34', 10, '[40,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903854;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903854;s:19:"scheduled_timestamp";i:1709903854;s:9:"timestamp";i:1709903854;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(35, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:34', '2024-03-08 13:17:34', 10, '[41,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903854;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903854;s:19:"scheduled_timestamp";i:1709903854;s:9:"timestamp";i:1709903854;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(36, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:34', '2024-03-08 13:17:34', 10, '[42,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903854;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903854;s:19:"scheduled_timestamp";i:1709903854;s:9:"timestamp";i:1709903854;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(37, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:35', '2024-03-08 13:17:35', 10, '[43,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903855;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903855;s:19:"scheduled_timestamp";i:1709903855;s:9:"timestamp";i:1709903855;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(38, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:35', '2024-03-08 13:17:35', 10, '[44,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903855;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903855;s:19:"scheduled_timestamp";i:1709903855;s:9:"timestamp";i:1709903855;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(39, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:35', '2024-03-08 13:17:35', 10, '[45,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903855;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903855;s:19:"scheduled_timestamp";i:1709903855;s:9:"timestamp";i:1709903855;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(40, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:35', '2024-03-08 13:17:35', 10, '[46,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903855;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903855;s:19:"scheduled_timestamp";i:1709903855;s:9:"timestamp";i:1709903855;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(41, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:35', '2024-03-08 13:17:35', 10, '[47,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903855;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903855;s:19:"scheduled_timestamp";i:1709903855;s:9:"timestamp";i:1709903855;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(42, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:35', '2024-03-08 13:17:35', 10, '[48,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903855;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903855;s:19:"scheduled_timestamp";i:1709903855;s:9:"timestamp";i:1709903855;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(43, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:35', '2024-03-08 13:17:35', 10, '[49,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903855;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903855;s:19:"scheduled_timestamp";i:1709903855;s:9:"timestamp";i:1709903855;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(44, 'woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications', 'pending', '2024-03-08 13:17:36', '2024-03-08 13:17:36', 10, '[]', 'O:28:"ActionScheduler_NullSchedule":0:{}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(45, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:17:59', '2024-03-08 13:17:59', 10, '[22,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903879;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903879;s:19:"scheduled_timestamp";i:1709903879;s:9:"timestamp";i:1709903879;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(46, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:03', '2024-03-08 13:18:03', 10, '[64,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903883;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903883;s:19:"scheduled_timestamp";i:1709903883;s:9:"timestamp";i:1709903883;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(47, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:03', '2024-03-08 13:18:03', 10, '[65,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903883;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903883;s:19:"scheduled_timestamp";i:1709903883;s:9:"timestamp";i:1709903883;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(48, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:03', '2024-03-08 13:18:03', 10, '[66,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903883;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903883;s:19:"scheduled_timestamp";i:1709903883;s:9:"timestamp";i:1709903883;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(49, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:04', '2024-03-08 13:18:04', 10, '[67,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903884;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903884;s:19:"scheduled_timestamp";i:1709903884;s:9:"timestamp";i:1709903884;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(50, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:04', '2024-03-08 13:18:04', 10, '[68,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903884;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903884;s:19:"scheduled_timestamp";i:1709903884;s:9:"timestamp";i:1709903884;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(51, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:04', '2024-03-08 13:18:04', 10, '[69,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903884;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903884;s:19:"scheduled_timestamp";i:1709903884;s:9:"timestamp";i:1709903884;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(52, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:04', '2024-03-08 13:18:04', 10, '[70,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903884;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903884;s:19:"scheduled_timestamp";i:1709903884;s:9:"timestamp";i:1709903884;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(53, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:04', '2024-03-08 13:18:04', 10, '[71,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903884;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903884;s:19:"scheduled_timestamp";i:1709903884;s:9:"timestamp";i:1709903884;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(54, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:04', '2024-03-08 13:18:04', 10, '[72,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903884;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903884;s:19:"scheduled_timestamp";i:1709903884;s:9:"timestamp";i:1709903884;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(55, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:20', '2024-03-08 13:18:20', 10, '[28,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903900;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903900;s:19:"scheduled_timestamp";i:1709903900;s:9:"timestamp";i:1709903900;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(56, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:20', '2024-03-08 13:18:20', 10, '[38,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903900;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903900;s:19:"scheduled_timestamp";i:1709903900;s:9:"timestamp";i:1709903900;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(57, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:20', '2024-03-08 13:18:20', 10, '[42,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903900;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903900;s:19:"scheduled_timestamp";i:1709903900;s:9:"timestamp";i:1709903900;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(58, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:20', '2024-03-08 13:18:20', 10, '[64,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903900;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903900;s:19:"scheduled_timestamp";i:1709903900;s:9:"timestamp";i:1709903900;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(59, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:20', '2024-03-08 13:18:20', 10, '[68,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903900;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903900;s:19:"scheduled_timestamp";i:1709903900;s:9:"timestamp";i:1709903900;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(60, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:27', '2024-03-08 13:18:27', 10, '[81,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903907;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903907;s:19:"scheduled_timestamp";i:1709903907;s:9:"timestamp";i:1709903907;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(61, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:28', '2024-03-08 13:18:28', 10, '[82,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903908;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903908;s:19:"scheduled_timestamp";i:1709903908;s:9:"timestamp";i:1709903908;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(62, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:28', '2024-03-08 13:18:28', 10, '[83,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903908;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903908;s:19:"scheduled_timestamp";i:1709903908;s:9:"timestamp";i:1709903908;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(63, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:28', '2024-03-08 13:18:28', 10, '[84,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903908;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903908;s:19:"scheduled_timestamp";i:1709903908;s:9:"timestamp";i:1709903908;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(64, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:28', '2024-03-08 13:18:28', 10, '[85,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903908;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903908;s:19:"scheduled_timestamp";i:1709903908;s:9:"timestamp";i:1709903908;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(65, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:28', '2024-03-08 13:18:28', 10, '[86,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903908;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903908;s:19:"scheduled_timestamp";i:1709903908;s:9:"timestamp";i:1709903908;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(66, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:28', '2024-03-08 13:18:28', 10, '[87,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903908;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903908;s:19:"scheduled_timestamp";i:1709903908;s:9:"timestamp";i:1709903908;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(67, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:28', '2024-03-08 13:18:28', 10, '[88,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903908;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903908;s:19:"scheduled_timestamp";i:1709903908;s:9:"timestamp";i:1709903908;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(68, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:28', '2024-03-08 13:18:28', 10, '[89,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903908;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903908;s:19:"scheduled_timestamp";i:1709903908;s:9:"timestamp";i:1709903908;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(69, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:29', '2024-03-08 13:18:29', 10, '[90,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903909;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903909;s:19:"scheduled_timestamp";i:1709903909;s:9:"timestamp";i:1709903909;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(70, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:29', '2024-03-08 13:18:29', 10, '[91,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903909;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903909;s:19:"scheduled_timestamp";i:1709903909;s:9:"timestamp";i:1709903909;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(71, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:29', '2024-03-08 13:18:29', 10, '[92,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903909;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903909;s:19:"scheduled_timestamp";i:1709903909;s:9:"timestamp";i:1709903909;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(72, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:29', '2024-03-08 13:18:29', 10, '[93,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903909;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903909;s:19:"scheduled_timestamp";i:1709903909;s:9:"timestamp";i:1709903909;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(73, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:29', '2024-03-08 13:18:29', 10, '[94,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903909;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903909;s:19:"scheduled_timestamp";i:1709903909;s:9:"timestamp";i:1709903909;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(74, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:29', '2024-03-08 13:18:29', 10, '[95,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903909;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903909;s:19:"scheduled_timestamp";i:1709903909;s:9:"timestamp";i:1709903909;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(75, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:29', '2024-03-08 13:18:29', 10, '[96,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903909;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903909;s:19:"scheduled_timestamp";i:1709903909;s:9:"timestamp";i:1709903909;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(76, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:29', '2024-03-08 13:18:29', 10, '[97,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903909;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903909;s:19:"scheduled_timestamp";i:1709903909;s:9:"timestamp";i:1709903909;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(77, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:29', '2024-03-08 13:18:29', 10, '[98,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903909;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903909;s:19:"scheduled_timestamp";i:1709903909;s:9:"timestamp";i:1709903909;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(78, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:29', '2024-03-08 13:18:29', 10, '[99,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903909;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903909;s:19:"scheduled_timestamp";i:1709903909;s:9:"timestamp";i:1709903909;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(79, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:30', '2024-03-08 13:18:30', 10, '[100,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903910;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903910;s:19:"scheduled_timestamp";i:1709903910;s:9:"timestamp";i:1709903910;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(80, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:30', '2024-03-08 13:18:30', 10, '[101,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903910;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903910;s:19:"scheduled_timestamp";i:1709903910;s:9:"timestamp";i:1709903910;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(81, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:30', '2024-03-08 13:18:30', 10, '[102,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903910;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903910;s:19:"scheduled_timestamp";i:1709903910;s:9:"timestamp";i:1709903910;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(82, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:30', '2024-03-08 13:18:30', 10, '[103,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903910;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903910;s:19:"scheduled_timestamp";i:1709903910;s:9:"timestamp";i:1709903910;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(83, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:30', '2024-03-08 13:18:30', 10, '[104,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903910;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903910;s:19:"scheduled_timestamp";i:1709903910;s:9:"timestamp";i:1709903910;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(84, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:30', '2024-03-08 13:18:30', 10, '[105,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903910;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903910;s:19:"scheduled_timestamp";i:1709903910;s:9:"timestamp";i:1709903910;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(85, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:30', '2024-03-08 13:18:30', 10, '[106,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903910;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903910;s:19:"scheduled_timestamp";i:1709903910;s:9:"timestamp";i:1709903910;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(86, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:30', '2024-03-08 13:18:30', 10, '[107,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903910;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903910;s:19:"scheduled_timestamp";i:1709903910;s:9:"timestamp";i:1709903910;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(87, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:30', '2024-03-08 13:18:30', 10, '[108,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903910;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903910;s:19:"scheduled_timestamp";i:1709903910;s:9:"timestamp";i:1709903910;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(88, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:30', '2024-03-08 13:18:30', 10, '[109,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903910;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903910;s:19:"scheduled_timestamp";i:1709903910;s:9:"timestamp";i:1709903910;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(89, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:47', '2024-03-08 13:18:47', 10, '[72,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903927;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903927;s:19:"scheduled_timestamp";i:1709903927;s:9:"timestamp";i:1709903927;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(90, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:47', '2024-03-08 13:18:47', 10, '[84,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903927;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903927;s:19:"scheduled_timestamp";i:1709903927;s:9:"timestamp";i:1709903927;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(91, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:47', '2024-03-08 13:18:47', 10, '[88,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903927;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903927;s:19:"scheduled_timestamp";i:1709903927;s:9:"timestamp";i:1709903927;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(92, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:47', '2024-03-08 13:18:47', 10, '[92,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903927;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903927;s:19:"scheduled_timestamp";i:1709903927;s:9:"timestamp";i:1709903927;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(93, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:47', '2024-03-08 13:18:47', 10, '[97,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903927;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903927;s:19:"scheduled_timestamp";i:1709903927;s:9:"timestamp";i:1709903927;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(94, 'woocommerce_run_product_attribute_lookup_update_callback', 'pending', '2024-03-08 13:18:47', '2024-03-08 13:18:47', 10, '[96,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1709903927;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1709903927;s:19:"scheduled_timestamp";i:1709903927;s:9:"timestamp";i:1709903927;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL) ;

#
# End of data contents of table `wp_actionscheduler_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_claims`
#

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;


#
# Table structure of table `wp_actionscheduler_claims`
#

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_actionscheduler_claims`
#

#
# End of data contents of table `wp_actionscheduler_claims`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_groups`
#

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;


#
# Table structure of table `wp_actionscheduler_groups`
#

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_actionscheduler_groups`
#
INSERT INTO `wp_actionscheduler_groups` ( `group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, ''),
(3, 'woocommerce-db-updates') ;

#
# End of data contents of table `wp_actionscheduler_groups`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_logs`
#

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;


#
# Table structure of table `wp_actionscheduler_logs`
#

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_actionscheduler_logs`
#
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(1, 11, 'action created', '2024-03-08 12:21:02', '2024-03-08 12:21:02'),
(2, 12, 'action created', '2024-03-08 12:21:06', '2024-03-08 12:21:06'),
(3, 13, 'action created', '2024-03-08 13:11:36', '2024-03-08 13:11:36'),
(4, 14, 'action created', '2024-03-08 13:17:31', '2024-03-08 13:17:31'),
(5, 15, 'action created', '2024-03-08 13:17:31', '2024-03-08 13:17:31'),
(6, 16, 'action created', '2024-03-08 13:17:31', '2024-03-08 13:17:31'),
(7, 17, 'action created', '2024-03-08 13:17:31', '2024-03-08 13:17:31'),
(8, 18, 'action created', '2024-03-08 13:17:32', '2024-03-08 13:17:32'),
(9, 19, 'action created', '2024-03-08 13:17:32', '2024-03-08 13:17:32'),
(10, 20, 'action created', '2024-03-08 13:17:32', '2024-03-08 13:17:32'),
(11, 21, 'action created', '2024-03-08 13:17:32', '2024-03-08 13:17:32'),
(12, 22, 'action created', '2024-03-08 13:17:32', '2024-03-08 13:17:32'),
(13, 23, 'action created', '2024-03-08 13:17:32', '2024-03-08 13:17:32'),
(14, 24, 'action created', '2024-03-08 13:17:32', '2024-03-08 13:17:32'),
(15, 25, 'action created', '2024-03-08 13:17:32', '2024-03-08 13:17:32'),
(16, 26, 'action created', '2024-03-08 13:17:32', '2024-03-08 13:17:32'),
(17, 27, 'action created', '2024-03-08 13:17:33', '2024-03-08 13:17:33'),
(18, 28, 'action created', '2024-03-08 13:17:33', '2024-03-08 13:17:33'),
(19, 29, 'action created', '2024-03-08 13:17:33', '2024-03-08 13:17:33'),
(20, 30, 'action created', '2024-03-08 13:17:33', '2024-03-08 13:17:33'),
(21, 31, 'action created', '2024-03-08 13:17:33', '2024-03-08 13:17:33'),
(22, 32, 'action created', '2024-03-08 13:17:33', '2024-03-08 13:17:33'),
(23, 33, 'action created', '2024-03-08 13:17:33', '2024-03-08 13:17:33'),
(24, 34, 'action created', '2024-03-08 13:17:33', '2024-03-08 13:17:33'),
(25, 35, 'action created', '2024-03-08 13:17:33', '2024-03-08 13:17:33'),
(26, 36, 'action created', '2024-03-08 13:17:33', '2024-03-08 13:17:33'),
(27, 37, 'action created', '2024-03-08 13:17:34', '2024-03-08 13:17:34'),
(28, 38, 'action created', '2024-03-08 13:17:34', '2024-03-08 13:17:34'),
(29, 39, 'action created', '2024-03-08 13:17:34', '2024-03-08 13:17:34'),
(30, 40, 'action created', '2024-03-08 13:17:34', '2024-03-08 13:17:34'),
(31, 41, 'action created', '2024-03-08 13:17:34', '2024-03-08 13:17:34'),
(32, 42, 'action created', '2024-03-08 13:17:34', '2024-03-08 13:17:34'),
(33, 43, 'action created', '2024-03-08 13:17:34', '2024-03-08 13:17:34'),
(34, 44, 'action created', '2024-03-08 13:17:36', '2024-03-08 13:17:36'),
(35, 45, 'action created', '2024-03-08 13:17:58', '2024-03-08 13:17:58'),
(36, 46, 'action created', '2024-03-08 13:18:02', '2024-03-08 13:18:02'),
(37, 47, 'action created', '2024-03-08 13:18:02', '2024-03-08 13:18:02'),
(38, 48, 'action created', '2024-03-08 13:18:02', '2024-03-08 13:18:02'),
(39, 49, 'action created', '2024-03-08 13:18:03', '2024-03-08 13:18:03'),
(40, 50, 'action created', '2024-03-08 13:18:03', '2024-03-08 13:18:03'),
(41, 51, 'action created', '2024-03-08 13:18:03', '2024-03-08 13:18:03'),
(42, 52, 'action created', '2024-03-08 13:18:03', '2024-03-08 13:18:03'),
(43, 53, 'action created', '2024-03-08 13:18:03', '2024-03-08 13:18:03'),
(44, 54, 'action created', '2024-03-08 13:18:03', '2024-03-08 13:18:03'),
(45, 55, 'action created', '2024-03-08 13:18:19', '2024-03-08 13:18:19'),
(46, 56, 'action created', '2024-03-08 13:18:19', '2024-03-08 13:18:19'),
(47, 57, 'action created', '2024-03-08 13:18:19', '2024-03-08 13:18:19'),
(48, 58, 'action created', '2024-03-08 13:18:19', '2024-03-08 13:18:19'),
(49, 59, 'action created', '2024-03-08 13:18:19', '2024-03-08 13:18:19'),
(50, 60, 'action created', '2024-03-08 13:18:26', '2024-03-08 13:18:26'),
(51, 61, 'action created', '2024-03-08 13:18:27', '2024-03-08 13:18:27'),
(52, 62, 'action created', '2024-03-08 13:18:27', '2024-03-08 13:18:27'),
(53, 63, 'action created', '2024-03-08 13:18:27', '2024-03-08 13:18:27'),
(54, 64, 'action created', '2024-03-08 13:18:27', '2024-03-08 13:18:27'),
(55, 65, 'action created', '2024-03-08 13:18:27', '2024-03-08 13:18:27'),
(56, 66, 'action created', '2024-03-08 13:18:27', '2024-03-08 13:18:27'),
(57, 67, 'action created', '2024-03-08 13:18:27', '2024-03-08 13:18:27'),
(58, 68, 'action created', '2024-03-08 13:18:27', '2024-03-08 13:18:27'),
(59, 69, 'action created', '2024-03-08 13:18:28', '2024-03-08 13:18:28'),
(60, 70, 'action created', '2024-03-08 13:18:28', '2024-03-08 13:18:28'),
(61, 71, 'action created', '2024-03-08 13:18:28', '2024-03-08 13:18:28'),
(62, 72, 'action created', '2024-03-08 13:18:28', '2024-03-08 13:18:28'),
(63, 73, 'action created', '2024-03-08 13:18:28', '2024-03-08 13:18:28'),
(64, 74, 'action created', '2024-03-08 13:18:28', '2024-03-08 13:18:28'),
(65, 75, 'action created', '2024-03-08 13:18:28', '2024-03-08 13:18:28'),
(66, 76, 'action created', '2024-03-08 13:18:28', '2024-03-08 13:18:28'),
(67, 77, 'action created', '2024-03-08 13:18:28', '2024-03-08 13:18:28'),
(68, 78, 'action created', '2024-03-08 13:18:28', '2024-03-08 13:18:28'),
(69, 79, 'action created', '2024-03-08 13:18:29', '2024-03-08 13:18:29'),
(70, 80, 'action created', '2024-03-08 13:18:29', '2024-03-08 13:18:29'),
(71, 81, 'action created', '2024-03-08 13:18:29', '2024-03-08 13:18:29'),
(72, 82, 'action created', '2024-03-08 13:18:29', '2024-03-08 13:18:29'),
(73, 83, 'action created', '2024-03-08 13:18:29', '2024-03-08 13:18:29'),
(74, 84, 'action created', '2024-03-08 13:18:29', '2024-03-08 13:18:29'),
(75, 85, 'action created', '2024-03-08 13:18:29', '2024-03-08 13:18:29'),
(76, 86, 'action created', '2024-03-08 13:18:29', '2024-03-08 13:18:29'),
(77, 87, 'action created', '2024-03-08 13:18:29', '2024-03-08 13:18:29'),
(78, 88, 'action created', '2024-03-08 13:18:29', '2024-03-08 13:18:29'),
(79, 89, 'action created', '2024-03-08 13:18:46', '2024-03-08 13:18:46'),
(80, 90, 'action created', '2024-03-08 13:18:46', '2024-03-08 13:18:46'),
(81, 91, 'action created', '2024-03-08 13:18:46', '2024-03-08 13:18:46'),
(82, 92, 'action created', '2024-03-08 13:18:46', '2024-03-08 13:18:46'),
(83, 93, 'action created', '2024-03-08 13:18:46', '2024-03-08 13:18:46'),
(84, 94, 'action created', '2024-03-08 13:18:46', '2024-03-08 13:18:46') ;

#
# End of data contents of table `wp_actionscheduler_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2024-03-08 11:45:30', '2024-03-08 11:45:30', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=759 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:82', 'yes'),
(2, 'home', 'http://localhost:82', 'yes'),
(3, 'blogname', 'Woo Base', 'yes'),
(4, 'blogdescription', 'Treding T Shirt', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'admin@email.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:203:{s:24:"^wc-auth/v([1]{1})/(.*)?";s:63:"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]";s:22:"^wc-api/v([1-3]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-3]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:21:"^wc/file/transient/?$";s:33:"index.php?wc-transient-file-name=";s:24:"^wc/file/transient/(.+)$";s:44:"index.php?wc-transient-file-name=$matches[1]";s:7:"shop/?$";s:27:"index.php?post_type=product";s:37:"shop/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:32:"shop/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:24:"shop/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:43:"category/(.+?)/wc/file/transient(/(.*))?/?$";s:65:"index.php?category_name=$matches[1]&wc/file/transient=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:40:"tag/([^/]+)/wc/file/transient(/(.*))?/?$";s:55:"index.php?tag=$matches[1]&wc/file/transient=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:55:"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:50:"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:31:"product-category/(.+?)/embed/?$";s:44:"index.php?product_cat=$matches[1]&embed=true";s:43:"product-category/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:25:"product-category/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:52:"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:47:"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:28:"product-tag/([^/]+)/embed/?$";s:44:"index.php?product_tag=$matches[1]&embed=true";s:40:"product-tag/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:22:"product-tag/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:35:"product/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"product/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"product/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"product/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"product/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"product/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"product/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:33:"product/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?product=$matches[1]&wc-api=$matches[3]";s:44:"product/([^/]+)/wc/file/transient(/(.*))?/?$";s:59:"index.php?product=$matches[1]&wc/file/transient=$matches[3]";s:39:"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"product/[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:61:"product/[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:32:"product/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"product/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"product/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"product/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:38:"ep-synonym/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:48:"ep-synonym/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:68:"ep-synonym/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"ep-synonym/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"ep-synonym/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:44:"ep-synonym/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:27:"ep-synonym/([^/]+)/embed/?$";s:43:"index.php?ep-synonym=$matches[1]&embed=true";s:31:"ep-synonym/([^/]+)/trackback/?$";s:37:"index.php?ep-synonym=$matches[1]&tb=1";s:39:"ep-synonym/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?ep-synonym=$matches[1]&paged=$matches[2]";s:46:"ep-synonym/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?ep-synonym=$matches[1]&cpage=$matches[2]";s:36:"ep-synonym/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?ep-synonym=$matches[1]&wc-api=$matches[3]";s:47:"ep-synonym/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?ep-synonym=$matches[1]&wc/file/transient=$matches[3]";s:42:"ep-synonym/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:53:"ep-synonym/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:53:"ep-synonym/[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:64:"ep-synonym/[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:35:"ep-synonym/([^/]+)(?:/([0-9]+))?/?$";s:49:"index.php?ep-synonym=$matches[1]&page=$matches[2]";s:27:"ep-synonym/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"ep-synonym/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"ep-synonym/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"ep-synonym/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"ep-synonym/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"ep-synonym/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:28:"wc/file/transient(/(.*))?/?$";s:40:"index.php?&wc/file/transient=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:37:"comments/wc/file/transient(/(.*))?/?$";s:40:"index.php?&wc/file/transient=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:40:"search/(.+)/wc/file/transient(/(.*))?/?$";s:53:"index.php?s=$matches[1]&wc/file/transient=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:43:"author/([^/]+)/wc/file/transient(/(.*))?/?$";s:63:"index.php?author_name=$matches[1]&wc/file/transient=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc/file/transient(/(.*))?/?$";s:93:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc/file/transient=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:52:"([0-9]{4})/([0-9]{1,2})/wc/file/transient(/(.*))?/?$";s:77:"index.php?year=$matches[1]&monthnum=$matches[2]&wc/file/transient=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:39:"([0-9]{4})/wc/file/transient(/(.*))?/?$";s:56:"index.php?year=$matches[1]&wc/file/transient=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:36:"(.?.+?)/wc/file/transient(/(.*))?/?$";s:60:"index.php?pagename=$matches[1]&wc/file/transient=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:25:"(.?.+?)/orders(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&orders=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:28:"(.?.+?)/downloads(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&downloads=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:34:"(.?.+?)/payment-methods(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&payment-methods=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:40:"(.?.+?)/delete-payment-method(/(.*))?/?$";s:64:"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]";s:45:"(.?.+?)/set-default-payment-method(/(.*))?/?$";s:69:"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:53:".?.+?/attachment/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:25:"([^/]+)/wc-api(/(.*))?/?$";s:45:"index.php?name=$matches[1]&wc-api=$matches[3]";s:36:"([^/]+)/wc/file/transient(/(.*))?/?$";s:56:"index.php?name=$matches[1]&wc/file/transient=$matches[3]";s:31:"[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:53:"[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:7:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:29:"elasticpress/elasticpress.php";i:2;s:27:"redis-cache/redis-cache.php";i:3;s:41:"varnish-http-purge/varnish-http-purge.php";i:4;s:49:"woo-variation-swatches/woo-variation-swatches.php";i:5;s:27:"woocommerce/woocommerce.php";i:6;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'twentytwentyfour', 'yes'),
(41, 'stylesheet', 'twentytwentyfour', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '56657', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'posts', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:0:{}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '0', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '59', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1725450329', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'wp_attachment_pages_enabled', '0', 'yes'),
(100, 'initial_db_version', '56657', 'yes'),
(101, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:115:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:19:"manage_elasticpress";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:1:{s:4:"read";b:1;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop manager";s:12:"capabilities";a:92:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"edit_theme_options";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(102, 'fresh_site', '0', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'cron', 'a:23:{i:1709898332;a:5:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1709898336;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1709898341;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1709898396;a:1:{s:28:"wp_update_comment_type_batch";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1709898472;a:1:{s:30:"wp_delete_temp_updater_backups";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1709898475;a:1:{s:26:"rediscache_discard_metrics";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1709900459;a:1:{s:26:"action_scheduler_run_queue";a:1:{s:32:"0d04ed39571b55704c122d726248bbac";a:3:{s:8:"schedule";s:12:"every_minute";s:4:"args";a:1:{i:0;s:7:"WP Cron";}s:8:"interval";i:60;}}}i:1709900461;a:3:{s:14:"wc_admin_daily";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:20:"jetpack_clean_nonces";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}s:20:"jetpack_v2_heartbeat";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1709900462;a:1:{s:33:"wc_admin_process_orders_milestone";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1709900471;a:4:{s:33:"woocommerce_cleanup_personal_data";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:30:"woocommerce_tracker_send_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:30:"generate_category_lookup_table";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}s:29:"wc_admin_unsnooze_admin_notes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1709900521;a:1:{s:25:"woocommerce_geoip_updater";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:11:"fifteendays";s:4:"args";a:0:{}s:8:"interval";i:1296000;}}}i:1709902045;a:1:{s:31:"woocommerce_flush_rewrite_rules";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1709904061;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1709905672;a:1:{s:26:"upgrader_scheduled_cleanup";a:1:{s:32:"686c8315be36c96dc00d0d7ed3656b43";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:6;}}}}i:1709906137;a:1:{s:26:"upgrader_scheduled_cleanup";a:1:{s:32:"d63aca0b7e6237c7964320bd7fc95644";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:7;}}}}i:1709906152;a:1:{s:26:"upgrader_scheduled_cleanup";a:1:{s:32:"60fda3b54003017dc64a0c492471bbfe";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:8;}}}}i:1709911261;a:2:{s:24:"woocommerce_cleanup_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:31:"woocommerce_cleanup_rate_limits";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1709922061;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1709942400;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1709984732;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1709989973;a:1:{s:26:"importer_scheduled_cleanup";a:1:{s:32:"bad9df8a7c3fa92d28999d03f4ccb29e";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:18;}}}}i:1709990231;a:1:{s:26:"importer_scheduled_cleanup";a:1:{s:32:"45f91c1ee81280c48cfb715d2c9931b0";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:19;}}}}s:7:"version";i:2;}', 'yes'),
(132, 'can_compress_scripts', '0', 'yes'),
(147, 'theme_mods_twentytwentyfour', 'a:1:{s:18:"custom_css_post_id";i:-1;}', 'yes'),
(148, 'recently_activated', 'a:0:{}', 'yes'),
(157, 'vhp_varnish_devmode', 'a:2:{s:6:"active";s:4:"true";s:6:"expire";i:1709985491;}', 'no'),
(158, 'vhp_varnish_url', 'http://localhost:82', 'no'),
(159, 'vhp_varnish_ip', 'wordpress', 'no'),
(160, 'vhp_varnish_debug', 'a:1:{s:19:"http://localhost:82";a:7:{s:16:"Development Mode";a:2:{s:4:"icon";s:6:"notice";s:7:"message";s:61:"NOTICE: Caching is disabled while Development Mode is active.";}s:13:"Cache Service";a:2:{s:4:"icon";s:3:"bad";s:7:"message";s:54:"No known cache service has been detected on your site.";}s:9:"Remote IP";a:2:{s:7:"message";s:298:"Your Proxy IP address is set to wordpress but a proxy (like Cloudflare or Sucuri) has not been detected. This is mostly harmless, but if you have issues with your cache not emptying when you make a post, you may need to remove the IP. Please check with your webhost or server admin before doing so.";s:4:"icon";s:6:"notice";}s:11:"Age Headers";a:2:{s:4:"icon";s:3:"bad";s:7:"message";s:122:"Your domain does not report an "Age" header, making it impossible to determine if the page is actually serving from cache.";}s:10:"No Cookies";a:2:{s:4:"icon";s:7:"awesome";s:7:"message";s:173:"No active cookies have been detected on your site. You may safely ignore any warnings about cookies set by plugins or themes, as your server has properly accounted for them.";}s:12:"Plugin Check";a:2:{s:4:"icon";s:4:"good";s:7:"message";s:60:"No installed plugins were found on the known conflicts list.";}s:11:"Theme Check";a:2:{s:4:"icon";s:4:"good";s:7:"message";s:59:"No installed themes were found on the known conflicts list.";}}}', 'no'),
(161, 'vhp_varnish_max_posts_before_all', '50', 'no'),
(162, 'ep_version', '5.0.2', 'yes'),
(163, 'ep_feature_requirement_statuses', 'a:12:{s:6:"search";i:0;s:15:"instant-results";i:2;s:11:"autosuggest";i:1;s:12:"did-you-mean";i:1;s:11:"woocommerce";i:2;s:6:"facets";i:0;s:13:"related_posts";i:0;s:14:"searchordering";i:0;s:17:"protected_content";i:1;s:9:"documents";i:2;s:8:"comments";i:1;s:5:"terms";i:1;}', 'yes'),
(165, 'ep_feature_settings', 'a:12:{s:6:"search";a:7:{s:6:"active";b:1;s:14:"force_inactive";b:0;s:16:"decaying_enabled";s:1:"0";s:20:"synonyms_editor_mode";s:6:"simple";s:17:"highlight_enabled";s:1:"1";s:17:"highlight_excerpt";s:1:"1";s:13:"highlight_tag";s:4:"mark";}s:6:"facets";a:3:{s:6:"active";b:1;s:14:"force_inactive";b:0;s:10:"match_type";s:3:"all";}s:13:"related_posts";a:2:{s:6:"active";b:0;s:14:"force_inactive";b:1;}s:14:"searchordering";a:2:{s:6:"active";b:0;s:14:"force_inactive";b:1;}s:15:"instant-results";a:8:{s:6:"active";b:0;s:14:"force_inactive";b:0;s:13:"highlight_tag";s:4:"mark";s:6:"facets";s:35:"post_type,tax-category,tax-post_tag";s:10:"match_type";s:3:"all";s:10:"term_count";s:1:"1";s:8:"per_page";s:2:"10";s:15:"search_behavior";s:1:"0";}s:11:"autosuggest";a:5:{s:6:"active";b:0;s:14:"force_inactive";b:0;s:12:"endpoint_url";s:0:"";s:20:"autosuggest_selector";s:0:"";s:16:"trigger_ga_event";s:1:"0";}s:12:"did-you-mean";a:3:{s:6:"active";b:0;s:14:"force_inactive";b:0;s:15:"search_behavior";s:1:"0";}s:11:"woocommerce";a:3:{s:6:"active";b:0;s:14:"force_inactive";b:0;s:6:"orders";s:1:"0";}s:17:"protected_content";a:2:{s:6:"active";b:0;s:14:"force_inactive";b:0;}s:9:"documents";a:2:{s:6:"active";b:0;s:14:"force_inactive";b:0;}s:8:"comments";a:2:{s:6:"active";b:0;s:14:"force_inactive";b:0;}s:5:"terms";a:2:{s:6:"active";b:0;s:14:"force_inactive";b:0;}}', 'yes'),
(166, 'widget_ep-facet', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(167, 'widget_ep-related-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(168, 'acf_first_activated_version', '6.2.7', 'yes'),
(169, 'acf_version', '6.2.7', 'yes'),
(170, 'ep_language', 'site-default', 'yes'),
(171, 'ep_host', 'elasticsearch:9200', 'yes'),
(172, 'ep_credentials', 'a:2:{s:8:"username";s:0:"";s:5:"token";s:0:"";}', 'yes'),
(173, 'ep_bulk_setting', '350', 'yes'),
(175, 'ep_skip_install', '1', 'yes'),
(180, 'ep_last_sync', '1709911840', 'yes'),
(182, 'ep_last_cli_index', 'a:13:{s:5:"total";i:16;s:6:"synced";i:16;s:7:"skipped";i:0;s:6:"failed";i:0;s:10:"total_time";d:1.7899408340454102;s:6:"errors";a:0:{}s:13:"end_date_time";s:25:"2024-03-08T15:30:41+00:00";s:15:"start_date_time";s:25:"2024-03-08T15:30:40+00:00";s:12:"end_time_gmt";i:1709911841;s:12:"is_full_sync";b:1;s:6:"method";s:3:"web";s:7:"trigger";s:6:"manual";s:12:"final_status";s:7:"success";}', 'no'),
(183, 'ep_sync_history', 'a:5:{i:0;a:13:{s:5:"total";i:16;s:6:"synced";i:16;s:7:"skipped";i:0;s:6:"failed";i:0;s:10:"total_time";d:1.7899408340454102;s:6:"errors";a:0:{}s:13:"end_date_time";s:25:"2024-03-08T15:30:41+00:00";s:15:"start_date_time";s:25:"2024-03-08T15:30:40+00:00";s:12:"end_time_gmt";i:1709911841;s:12:"is_full_sync";b:1;s:6:"method";s:3:"web";s:7:"trigger";s:6:"manual";s:12:"final_status";s:7:"success";}i:1;a:12:{s:5:"total";i:6;s:6:"synced";i:6;s:7:"skipped";i:0;s:6:"failed";i:0;s:10:"total_time";d:2.0917630195617676;s:13:"end_date_time";s:25:"2024-03-08T12:23:24+00:00";s:15:"start_date_time";s:25:"2024-03-08T12:23:21+00:00";s:12:"end_time_gmt";i:1709900604;s:12:"is_full_sync";b:1;s:6:"method";s:3:"web";s:7:"trigger";s:8:"features";s:12:"final_status";s:7:"success";}i:2;a:12:{s:5:"total";i:2;s:6:"synced";i:2;s:7:"skipped";i:0;s:6:"failed";i:0;s:10:"total_time";d:1.0037000179290771;s:13:"end_date_time";s:25:"2024-03-08T12:13:19+00:00";s:15:"start_date_time";s:25:"2024-03-08T12:13:18+00:00";s:12:"end_time_gmt";i:1709899999;s:12:"is_full_sync";b:1;s:6:"method";s:3:"web";s:7:"trigger";s:6:"manual";s:12:"final_status";s:7:"success";}i:3;a:12:{s:5:"total";i:0;s:6:"synced";i:0;s:7:"skipped";i:0;s:6:"failed";i:0;s:10:"total_time";d:0.04681396484375;s:13:"end_date_time";s:25:"2024-03-08T12:06:43+00:00";s:15:"start_date_time";s:25:"2024-03-08T12:06:43+00:00";s:12:"end_time_gmt";i:1709899603;s:12:"is_full_sync";b:1;s:6:"method";s:3:"web";s:7:"trigger";s:6:"manual";s:12:"final_status";s:6:"failed";}i:4;a:12:{s:5:"total";i:0;s:6:"synced";i:0;s:7:"skipped";i:0;s:6:"failed";i:0;s:10:"total_time";d:0.04661107063293457;s:13:"end_date_time";s:25:"2024-03-08T12:06:21+00:00";s:15:"start_date_time";s:25:"2024-03-08T12:06:21+00:00";s:12:"end_time_gmt";i:1709899581;s:12:"is_full_sync";b:1;s:6:"method";s:3:"web";s:7:"trigger";s:6:"manual";s:12:"final_status";s:6:"failed";}}', 'no'),
(198, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1709962139;}', 'no'),
(199, 'https_detection_errors', 'a:1:{s:20:"https_request_failed";a:1:{i:0;s:21:"HTTPS request failed.";}}', 'yes'),
(200, 'action_scheduler_hybrid_store_demarkation', '10', 'yes'),
(201, 'schema-ActionScheduler_StoreSchema', '7.0.1709900459', 'yes'),
(202, 'schema-ActionScheduler_LoggerSchema', '3.0.1709900459', 'yes'),
(203, 'woocommerce_newly_installed', 'no', 'yes'),
(204, 'woocommerce_schema_version', '430', 'yes'),
(205, 'woocommerce_store_address', '751A Au Co', 'yes'),
(206, 'woocommerce_store_address_2', 'Tan Phu', 'yes'),
(207, 'woocommerce_store_city', 'Ho Chi Minh', 'yes'),
(208, 'woocommerce_default_country', 'VN', 'yes'),
(209, 'woocommerce_store_postcode', '70000', 'yes'),
(210, 'woocommerce_allowed_countries', 'specific', 'yes'),
(211, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(212, 'woocommerce_specific_allowed_countries', 'a:4:{i:0;s:2:"AU";i:1;s:2:"CA";i:2;s:2:"GB";i:3;s:2:"US";}', 'yes'),
(213, 'woocommerce_ship_to_countries', '', 'yes'),
(214, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'yes'),
(215, 'woocommerce_default_customer_address', 'base', 'yes'),
(216, 'woocommerce_calc_taxes', 'yes', 'yes'),
(217, 'woocommerce_enable_coupons', 'yes', 'yes'),
(218, 'woocommerce_calc_discounts_sequentially', 'yes', 'no'),
(219, 'woocommerce_currency', 'USD', 'yes'),
(220, 'woocommerce_currency_pos', 'left', 'yes'),
(221, 'woocommerce_price_thousand_sep', '.', 'yes'),
(222, 'woocommerce_price_decimal_sep', ',', 'yes'),
(223, 'woocommerce_price_num_decimals', '0', 'yes'),
(224, 'woocommerce_shop_page_id', '11', 'yes'),
(225, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(226, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(227, 'woocommerce_placeholder_image', '10', 'yes'),
(228, 'woocommerce_weight_unit', 'g', 'yes'),
(229, 'woocommerce_dimension_unit', 'cm', 'yes'),
(230, 'woocommerce_enable_reviews', 'yes', 'yes'),
(231, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(232, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(233, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(234, 'woocommerce_review_rating_required', 'yes', 'no'),
(235, 'woocommerce_manage_stock', 'yes', 'yes'),
(236, 'woocommerce_hold_stock_minutes', '60', 'no'),
(237, 'woocommerce_notify_low_stock', 'yes', 'no'),
(238, 'woocommerce_notify_no_stock', 'yes', 'no'),
(239, 'woocommerce_stock_email_recipient', 'admin@email.com', 'no'),
(240, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(241, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(242, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(243, 'woocommerce_stock_format', '', 'yes'),
(244, 'woocommerce_file_download_method', 'force', 'no'),
(245, 'woocommerce_downloads_redirect_fallback_allowed', 'no', 'no'),
(246, 'woocommerce_downloads_require_login', 'no', 'no'),
(247, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(248, 'woocommerce_downloads_deliver_inline', '', 'no'),
(249, 'woocommerce_downloads_add_hash_to_filename', 'yes', 'yes'),
(250, 'woocommerce_attribute_lookup_enabled', 'no', 'yes'),
(251, 'woocommerce_attribute_lookup_direct_updates', 'no', 'yes'),
(252, 'woocommerce_product_match_featured_image_by_sku', 'no', 'yes'),
(253, 'woocommerce_prices_include_tax', 'no', 'yes'),
(254, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(255, 'woocommerce_shipping_tax_class', 'inherit', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(256, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(257, 'woocommerce_tax_classes', '', 'yes'),
(258, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(259, 'woocommerce_tax_display_cart', 'excl', 'yes'),
(260, 'woocommerce_price_display_suffix', '', 'yes'),
(261, 'woocommerce_tax_total_display', 'itemized', 'no'),
(262, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(263, 'woocommerce_shipping_cost_requires_address', 'no', 'yes'),
(264, 'woocommerce_ship_to_destination', 'billing', 'no'),
(265, 'woocommerce_shipping_debug_mode', 'no', 'yes'),
(266, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(267, 'woocommerce_enable_checkout_login_reminder', 'no', 'no'),
(268, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no'),
(269, 'woocommerce_enable_myaccount_registration', 'yes', 'no'),
(270, 'woocommerce_registration_generate_username', 'yes', 'no'),
(271, 'woocommerce_registration_generate_password', 'yes', 'no'),
(272, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(273, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(274, 'woocommerce_allow_bulk_remove_personal_data', 'no', 'no'),
(275, 'woocommerce_registration_privacy_policy_text', 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].', 'yes'),
(276, 'woocommerce_checkout_privacy_policy_text', 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].', 'yes'),
(277, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(278, 'woocommerce_trash_pending_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:4:"days";}', 'no'),
(279, 'woocommerce_trash_failed_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:4:"days";}', 'no'),
(280, 'woocommerce_trash_cancelled_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:4:"days";}', 'no'),
(281, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(282, 'woocommerce_email_from_name', 'Woo Base', 'no'),
(283, 'woocommerce_email_from_address', 'admin@email.com', 'no'),
(284, 'woocommerce_email_header_image', '', 'no'),
(285, 'woocommerce_email_footer_text', '{site_title} &mdash; Built with {WooCommerce}', 'no'),
(286, 'woocommerce_email_base_color', '#7f54b3', 'no'),
(287, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(288, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(289, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(290, 'woocommerce_merchant_email_notifications', 'no', 'no'),
(291, 'woocommerce_cart_page_id', '12', 'no'),
(292, 'woocommerce_checkout_page_id', '13', 'no'),
(293, 'woocommerce_myaccount_page_id', '14', 'no'),
(294, 'woocommerce_terms_page_id', '3', 'no'),
(295, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(296, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(297, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(298, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(299, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(300, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(301, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(302, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(303, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(304, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(305, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(306, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(307, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(308, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(309, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(310, 'woocommerce_api_enabled', 'no', 'yes'),
(311, 'woocommerce_allow_tracking', 'no', 'no'),
(312, 'woocommerce_show_marketplace_suggestions', 'yes', 'no'),
(313, 'woocommerce_custom_orders_table_enabled', 'yes', 'yes'),
(314, 'woocommerce_analytics_enabled', 'no', 'yes'),
(315, 'woocommerce_navigation_enabled', 'no', 'yes'),
(316, 'woocommerce_feature_order_attribution_enabled', 'no', 'yes'),
(317, 'woocommerce_feature_product_block_editor_enabled', 'no', 'yes'),
(318, 'woocommerce_single_image_width', '600', 'yes'),
(319, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(320, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(321, 'woocommerce_demo_store', 'no', 'no'),
(322, 'wc_downloads_approved_directories_mode', 'enabled', 'yes'),
(323, 'woocommerce_permalinks', 'a:5:{s:12:"product_base";s:7:"product";s:13:"category_base";s:16:"product-category";s:8:"tag_base";s:11:"product-tag";s:14:"attribute_base";s:0:"";s:22:"use_verbose_page_rules";b:0;}', 'yes'),
(324, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(325, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(327, 'default_product_cat', '16', 'yes'),
(329, 'woocommerce_refund_returns_page_id', '15', 'yes'),
(330, 'woocommerce_paypal_settings', 'a:23:{s:7:"enabled";s:2:"no";s:5:"title";s:6:"PayPal";s:11:"description";s:85:"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.";s:5:"email";s:15:"admin@email.com";s:8:"advanced";s:0:"";s:8:"testmode";s:2:"no";s:5:"debug";s:2:"no";s:16:"ipn_notification";s:3:"yes";s:14:"receiver_email";s:15:"admin@email.com";s:14:"identity_token";s:0:"";s:14:"invoice_prefix";s:3:"WC-";s:13:"send_shipping";s:3:"yes";s:16:"address_override";s:2:"no";s:13:"paymentaction";s:4:"sale";s:9:"image_url";s:0:"";s:11:"api_details";s:0:"";s:12:"api_username";s:0:"";s:12:"api_password";s:0:"";s:13:"api_signature";s:0:"";s:20:"sandbox_api_username";s:0:"";s:20:"sandbox_api_password";s:0:"";s:21:"sandbox_api_signature";s:0:"";s:12:"_should_load";s:2:"no";}', 'yes'),
(331, 'woocommerce_version', '8.6.1', 'yes'),
(332, 'woocommerce_db_version', '8.6.1', 'yes'),
(333, 'woocommerce_store_id', 'e30ec963-7381-4d08-b41a-38dcb68a5b6f', 'yes'),
(334, 'woocommerce_admin_install_timestamp', '1709900461', 'yes'),
(335, 'woocommerce_inbox_variant_assignment', '4', 'yes'),
(336, 'wc_blocks_version', '11.8.0-dev', 'yes'),
(337, 'jetpack_connection_active_plugins', 'a:1:{s:11:"woocommerce";a:1:{s:4:"name";s:11:"WooCommerce";}}', 'yes'),
(338, 'woocommerce_maxmind_geolocation_settings', 'a:1:{s:15:"database_prefix";s:32:"1rFiHsgIuc5q50wsn6YSXRRuKqxLJaA3";}', 'yes'),
(339, 'widget_woocommerce_widget_cart', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(340, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(341, 'widget_woocommerce_layered_nav', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(342, 'widget_woocommerce_price_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(343, 'widget_woocommerce_product_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(344, 'widget_woocommerce_product_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(345, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(346, 'widget_woocommerce_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(347, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(348, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(349, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(350, 'widget_woocommerce_rating_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(351, 'has_migrated_cart', 'success', 'yes'),
(352, 'has_migrated_checkout', 'success', 'yes'),
(353, 'action_scheduler_lock_async-request-runner', '65ebf374005779.69032820|1709962160', 'no'),
(354, 'woocommerce_admin_notices', 'a:0:{}', 'yes'),
(357, 'wcpay_was_in_use', 'no', 'yes'),
(358, 'wc_admin_show_legacy_coupon_menu', '0', 'yes'),
(359, 'woocommerce_custom_orders_table_created', 'yes', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(360, 'wc_blocks_db_schema_version', '260', 'yes'),
(361, 'wc_remote_inbox_notifications_stored_state', 'O:8:"stdClass":2:{s:22:"there_were_no_products";b:1;s:22:"there_are_now_products";b:1;}', 'no'),
(362, 'woocommerce_onboarding_profile', 'a:9:{s:15:"business_choice";s:28:"im_just_starting_my_business";s:21:"selling_online_answer";N;s:17:"selling_platforms";N;s:20:"is_store_country_set";b:1;s:8:"industry";a:1:{i:0;s:24:"clothing_and_accessories";}s:18:"is_agree_marketing";b:0;s:11:"store_email";s:15:"admin@email.com";s:9:"completed";b:1;s:23:"is_plugins_page_skipped";b:1;}', 'yes'),
(363, 'woocommerce_free_shipping_1_settings', 'a:4:{s:5:"title";s:13:"Free shipping";s:8:"requires";s:0:"";s:10:"min_amount";s:1:"0";s:16:"ignore_discounts";s:2:"no";}', 'yes'),
(364, 'woocommerce_admin_created_default_shipping_zones', 'yes', 'yes'),
(365, 'woocommerce_task_list_tracked_completed_tasks', 'a:4:{i:0;s:8:"shipping";i:1;s:10:"appearance";i:2;s:8:"payments";i:3;s:8:"products";}', 'yes'),
(366, 'woocommerce_task_list_prompt_shown', '1', 'yes'),
(367, 'woocommerce_task_list_tracked_completed_actions', 'a:1:{i:0;s:10:"appearance";}', 'yes'),
(369, 'woocommerce_custom_orders_table_data_sync_enabled', 'no', 'yes'),
(370, 'woocommerce_cheque_settings', 'a:4:{s:7:"enabled";s:3:"yes";s:5:"title";s:14:"Check payments";s:11:"description";s:98:"Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.";s:12:"instructions";s:0:"";}', 'yes'),
(371, 'woocommerce_gateway_order', 'a:3:{s:4:"bacs";i:0;s:6:"cheque";i:1;s:3:"cod";i:2;}', 'yes'),
(372, 'advanced_options', '', 'yes'),
(373, 'woo_variation_swatches', 'a:5:{s:17:"clear_on_reselect";s:3:"yes";s:27:"hide_out_of_stock_variation";s:3:"yes";s:32:"clickable_out_of_stock_variation";s:2:"no";s:18:"attribute_behavior";s:4:"blur";s:20:"attribute_image_size";s:29:"variation_swatches_image_size";}', 'yes'),
(381, 'pa_brand_children', 'a:0:{}', 'yes'),
(384, 'product_cat_children', 'a:2:{i:19;a:2:{i:0;i:20;i:1;i:21;}i:32;a:2:{i:0;i:33;i:1;i:34;}}', 'yes'),
(385, 'woocommerce_task_list_reminder_bar_hidden', 'yes', 'yes'),
(387, 'ep_feature_settings_draft', 'a:12:{s:6:"search";a:7:{s:6:"active";b:1;s:14:"force_inactive";b:0;s:16:"decaying_enabled";s:1:"0";s:20:"synonyms_editor_mode";s:6:"simple";s:17:"highlight_enabled";s:1:"1";s:17:"highlight_excerpt";s:1:"1";s:13:"highlight_tag";s:4:"mark";}s:6:"facets";a:3:{s:6:"active";b:1;s:14:"force_inactive";b:0;s:10:"match_type";s:3:"all";}s:13:"related_posts";a:2:{s:6:"active";b:0;s:14:"force_inactive";b:1;}s:14:"searchordering";a:2:{s:6:"active";b:0;s:14:"force_inactive";b:1;}s:15:"instant-results";a:8:{s:6:"active";b:0;s:14:"force_inactive";b:0;s:13:"highlight_tag";s:4:"mark";s:6:"facets";s:35:"post_type,tax-category,tax-post_tag";s:10:"match_type";s:3:"all";s:10:"term_count";s:1:"1";s:8:"per_page";s:2:"10";s:15:"search_behavior";s:1:"0";}s:11:"autosuggest";a:5:{s:6:"active";b:0;s:14:"force_inactive";b:0;s:12:"endpoint_url";s:0:"";s:20:"autosuggest_selector";s:0:"";s:16:"trigger_ga_event";s:1:"0";}s:12:"did-you-mean";a:3:{s:6:"active";b:0;s:14:"force_inactive";b:0;s:15:"search_behavior";s:1:"0";}s:11:"woocommerce";a:3:{s:6:"active";b:1;s:14:"force_inactive";b:0;s:6:"orders";s:1:"0";}s:17:"protected_content";a:2:{s:6:"active";b:0;s:14:"force_inactive";b:0;}s:9:"documents";a:2:{s:6:"active";b:0;s:14:"force_inactive";b:0;}s:8:"comments";a:2:{s:6:"active";b:0;s:14:"force_inactive";b:0;}s:5:"terms";a:2:{s:6:"active";b:0;s:14:"force_inactive";b:0;}}', 'yes'),
(388, '_wp_suggested_policy_text_has_changed', 'changed', 'yes'),
(631, 'site_logo', '59', 'yes'),
(752, 'wpmdb_folder_transfers_media_files_9a1b5410-af23-4e00-b46c-b7e7f1411a47', 'a:8:{s:27:"woocommerce-placeholder.png";a:10:{s:9:"nice_name";s:7:"uploads";s:13:"relative_path";s:28:"/woocommerce-placeholder.png";s:6:"is_dir";b:0;s:13:"absolute_path";s:32:"/var/www/html/wp-content/uploads";s:9:"item_size";i:102644;s:4:"size";i:9489356;s:10:"batch_size";i:102644;s:18:"folder_transferred";i:102644;s:26:"folder_percent_transferred";d:0.010816750894370493;s:17:"total_transferred";i:9489356;}s:35:"woocommerce-placeholder-768x768.png";a:10:{s:9:"nice_name";s:7:"uploads";s:13:"relative_path";s:36:"/woocommerce-placeholder-768x768.png";s:6:"is_dir";b:0;s:13:"absolute_path";s:32:"/var/www/html/wp-content/uploads";s:9:"item_size";i:48652;s:4:"size";i:9489356;s:10:"batch_size";i:48652;s:18:"folder_transferred";i:48652;s:26:"folder_percent_transferred";d:0.005127007565107685;s:17:"total_transferred";i:9489356;}s:35:"woocommerce-placeholder-300x300.png";a:10:{s:9:"nice_name";s:7:"uploads";s:13:"relative_path";s:36:"/woocommerce-placeholder-300x300.png";s:6:"is_dir";b:0;s:13:"absolute_path";s:32:"/var/www/html/wp-content/uploads";s:9:"item_size";i:10659;s:4:"size";i:9489356;s:10:"batch_size";i:10659;s:18:"folder_transferred";i:10659;s:26:"folder_percent_transferred";d:0.0011232585224961525;s:17:"total_transferred";i:9489356;}s:35:"woocommerce-placeholder-150x150.png";a:10:{s:9:"nice_name";s:7:"uploads";s:13:"relative_path";s:36:"/woocommerce-placeholder-150x150.png";s:6:"is_dir";b:0;s:13:"absolute_path";s:32:"/var/www/html/wp-content/uploads";s:9:"item_size";i:3738;s:4:"size";i:9489356;s:10:"batch_size";i:3738;s:18:"folder_transferred";i:3738;s:26:"folder_percent_transferred";d:0.000393915034908586;s:17:"total_transferred";i:9489356;}s:37:"woocommerce-placeholder-1024x1024.png";a:10:{s:9:"nice_name";s:7:"uploads";s:13:"relative_path";s:38:"/woocommerce-placeholder-1024x1024.png";s:6:"is_dir";b:0;s:13:"absolute_path";s:32:"/var/www/html/wp-content/uploads";s:9:"item_size";i:80210;s:4:"size";i:9489356;s:10:"batch_size";i:80210;s:18:"folder_transferred";i:80210;s:26:"folder_percent_transferred";d:0.008452628397543521;s:17:"total_transferred";i:9489356;}s:19:"woocommerce_uploads";a:10:{s:9:"nice_name";s:7:"uploads";s:13:"relative_path";s:20:"/woocommerce_uploads";s:6:"is_dir";b:1;s:13:"absolute_path";s:32:"/var/www/html/wp-content/uploads";s:9:"item_size";i:13;s:4:"size";i:9489356;s:10:"batch_size";i:13;s:18:"folder_transferred";i:13;s:26:"folder_percent_transferred";d:1.3699559801529208E-6;s:17:"total_transferred";i:9489356;}s:7:"wc-logs";a:10:{s:9:"nice_name";s:7:"uploads";s:13:"relative_path";s:8:"/wc-logs";s:6:"is_dir";b:1;s:13:"absolute_path";s:32:"/var/www/html/wp-content/uploads";s:9:"item_size";i:13;s:4:"size";i:9489356;s:10:"batch_size";i:13;s:18:"folder_transferred";i:13;s:26:"folder_percent_transferred";d:1.3699559801529208E-6;s:17:"total_transferred";i:9489356;}i:2024;a:10:{s:9:"nice_name";s:7:"uploads";s:13:"relative_path";s:5:"/2024";s:6:"is_dir";b:1;s:13:"absolute_path";s:32:"/var/www/html/wp-content/uploads";s:9:"item_size";i:2822;s:4:"size";i:9489356;s:10:"batch_size";i:9243427;s:18:"folder_transferred";i:9243427;s:26:"folder_percent_transferred";d:0.9740836996736133;s:17:"total_transferred";i:9489356;}}', 'no'),
(756, 'ep_feature_auto_activated_sync', 'woocommerce', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2182 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(9, 2, '_edit_lock', '1709956085:1'),
(10, 10, '_wp_attached_file', 'woocommerce-placeholder.png'),
(11, 10, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1200;s:6:"height";i:1200;s:4:"file";s:27:"woocommerce-placeholder.png";s:8:"filesize";i:102644;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:35:"woocommerce-placeholder-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:10659;}s:5:"large";a:5:{s:4:"file";s:37:"woocommerce-placeholder-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:80210;}s:9:"thumbnail";a:5:{s:4:"file";s:35:"woocommerce-placeholder-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3738;}s:12:"medium_large";a:5:{s:4:"file";s:35:"woocommerce-placeholder-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:48652;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(12, 16, 'origin', 'plugin'),
(13, 17, 'origin', 'plugin'),
(14, 1, '_edit_lock', '1709902519:1'),
(15, 18, '_wp_attached_file', '2024/03/Divi-Engine-WooCommerce-Sample-Products.csv'),
(16, 18, '_wp_attachment_context', 'import'),
(17, 19, '_wp_attached_file', '2024/03/Divi-Engine-WooCommerce-Sample-Products-1.csv'),
(18, 19, '_wp_attachment_context', 'import'),
(19, 20, 'total_sales', '0'),
(20, 20, '_tax_status', 'taxable'),
(21, 20, '_tax_class', ''),
(22, 20, '_manage_stock', 'no'),
(23, 20, '_backorders', 'no'),
(24, 20, '_sold_individually', 'no'),
(25, 20, '_virtual', 'no'),
(26, 20, '_downloadable', 'no'),
(27, 20, '_download_limit', '0'),
(28, 20, '_download_expiry', '0'),
(29, 20, '_stock', NULL),
(30, 20, '_stock_status', 'instock'),
(31, 20, '_wc_average_rating', '0'),
(32, 20, '_wc_review_count', '0'),
(33, 20, '_product_version', '8.6.1'),
(35, 21, 'total_sales', '0'),
(36, 21, '_tax_status', 'taxable'),
(37, 21, '_tax_class', ''),
(38, 21, '_manage_stock', 'no'),
(39, 21, '_backorders', 'no'),
(40, 21, '_sold_individually', 'no'),
(41, 21, '_virtual', 'no'),
(42, 21, '_downloadable', 'no'),
(43, 21, '_download_limit', '0'),
(44, 21, '_download_expiry', '0'),
(45, 21, '_stock', NULL),
(46, 21, '_stock_status', 'instock'),
(47, 21, '_wc_average_rating', '0'),
(48, 21, '_wc_review_count', '0'),
(49, 21, '_product_version', '8.6.1'),
(51, 22, 'total_sales', '0'),
(52, 22, '_tax_status', 'taxable'),
(53, 22, '_tax_class', ''),
(54, 22, '_manage_stock', 'no'),
(55, 22, '_backorders', 'no'),
(56, 22, '_sold_individually', 'no'),
(57, 22, '_virtual', 'no'),
(58, 22, '_downloadable', 'no'),
(59, 22, '_download_limit', '0'),
(60, 22, '_download_expiry', '0'),
(61, 22, '_stock', NULL),
(62, 22, '_stock_status', 'instock'),
(63, 22, '_wc_average_rating', '0'),
(64, 22, '_wc_review_count', '0'),
(65, 22, '_product_version', '8.6.1'),
(67, 23, 'total_sales', '0'),
(68, 23, '_tax_status', 'taxable'),
(69, 23, '_tax_class', 'parent'),
(70, 23, '_manage_stock', 'no'),
(71, 23, '_backorders', 'no'),
(72, 23, '_sold_individually', 'no'),
(73, 23, '_virtual', 'no'),
(74, 23, '_downloadable', 'no'),
(75, 23, '_download_limit', '0'),
(76, 23, '_download_expiry', '0'),
(77, 23, '_stock', NULL),
(78, 23, '_stock_status', 'instock'),
(79, 23, '_wc_average_rating', '0'),
(80, 23, '_wc_review_count', '0'),
(81, 23, '_product_version', '8.6.1'),
(83, 24, 'total_sales', '0'),
(84, 24, '_tax_status', 'taxable'),
(85, 24, '_tax_class', 'parent'),
(86, 24, '_manage_stock', 'no'),
(87, 24, '_backorders', 'no'),
(88, 24, '_sold_individually', 'no'),
(89, 24, '_virtual', 'no'),
(90, 24, '_downloadable', 'no'),
(91, 24, '_download_limit', '0'),
(92, 24, '_download_expiry', '0'),
(93, 24, '_stock', NULL),
(94, 24, '_stock_status', 'instock'),
(95, 24, '_wc_average_rating', '0'),
(96, 24, '_wc_review_count', '0'),
(97, 24, '_product_version', '8.6.1'),
(99, 25, 'total_sales', '0'),
(100, 25, '_tax_status', 'taxable'),
(101, 25, '_tax_class', 'parent'),
(102, 25, '_manage_stock', 'no'),
(103, 25, '_backorders', 'no'),
(104, 25, '_sold_individually', 'no'),
(105, 25, '_virtual', 'no'),
(106, 25, '_downloadable', 'no'),
(107, 25, '_download_limit', '0'),
(108, 25, '_download_expiry', '0'),
(109, 25, '_stock', NULL),
(110, 25, '_stock_status', 'instock'),
(111, 25, '_wc_average_rating', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(112, 25, '_wc_review_count', '0'),
(113, 25, '_product_version', '8.6.1'),
(115, 26, 'total_sales', '0'),
(116, 26, '_tax_status', 'taxable'),
(117, 26, '_tax_class', 'parent'),
(118, 26, '_manage_stock', 'no'),
(119, 26, '_backorders', 'no'),
(120, 26, '_sold_individually', 'no'),
(121, 26, '_virtual', 'no'),
(122, 26, '_downloadable', 'no'),
(123, 26, '_download_limit', '0'),
(124, 26, '_download_expiry', '0'),
(125, 26, '_stock', NULL),
(126, 26, '_stock_status', 'instock'),
(127, 26, '_wc_average_rating', '0'),
(128, 26, '_wc_review_count', '0'),
(129, 26, '_product_version', '8.6.1'),
(131, 27, 'total_sales', '0'),
(132, 27, '_tax_status', 'taxable'),
(133, 27, '_tax_class', ''),
(134, 27, '_manage_stock', 'no'),
(135, 27, '_backorders', 'no'),
(136, 27, '_sold_individually', 'no'),
(137, 27, '_virtual', 'no'),
(138, 27, '_downloadable', 'no'),
(139, 27, '_download_limit', '0'),
(140, 27, '_download_expiry', '0'),
(141, 27, '_stock', NULL),
(142, 27, '_stock_status', 'instock'),
(143, 27, '_wc_average_rating', '0'),
(144, 27, '_wc_review_count', '0'),
(145, 27, '_product_version', '8.6.1'),
(147, 28, 'total_sales', '0'),
(148, 28, '_tax_status', 'taxable'),
(149, 28, '_tax_class', ''),
(150, 28, '_manage_stock', 'no'),
(151, 28, '_backorders', 'no'),
(152, 28, '_sold_individually', 'no'),
(153, 28, '_virtual', 'no'),
(154, 28, '_downloadable', 'no'),
(155, 28, '_download_limit', '0'),
(156, 28, '_download_expiry', '0'),
(157, 28, '_stock', NULL),
(158, 28, '_stock_status', 'instock'),
(159, 28, '_wc_average_rating', '0'),
(160, 28, '_wc_review_count', '0'),
(161, 28, '_product_version', '8.6.1'),
(163, 29, 'total_sales', '0'),
(164, 29, '_tax_status', 'taxable'),
(165, 29, '_tax_class', 'parent'),
(166, 29, '_manage_stock', 'no'),
(167, 29, '_backorders', 'no'),
(168, 29, '_sold_individually', 'no'),
(169, 29, '_virtual', 'no'),
(170, 29, '_downloadable', 'no'),
(171, 29, '_download_limit', '0'),
(172, 29, '_download_expiry', '0'),
(173, 29, '_stock', NULL),
(174, 29, '_stock_status', 'instock'),
(175, 29, '_wc_average_rating', '0'),
(176, 29, '_wc_review_count', '0'),
(177, 29, '_product_version', '8.6.1'),
(179, 30, 'total_sales', '0'),
(180, 30, '_tax_status', 'taxable'),
(181, 30, '_tax_class', 'parent'),
(182, 30, '_manage_stock', 'no'),
(183, 30, '_backorders', 'no'),
(184, 30, '_sold_individually', 'no'),
(185, 30, '_virtual', 'no'),
(186, 30, '_downloadable', 'no'),
(187, 30, '_download_limit', '0'),
(188, 30, '_download_expiry', '0'),
(189, 30, '_stock', NULL),
(190, 30, '_stock_status', 'instock'),
(191, 30, '_wc_average_rating', '0'),
(192, 30, '_wc_review_count', '0'),
(193, 30, '_product_version', '8.6.1'),
(195, 31, 'total_sales', '0'),
(196, 31, '_tax_status', 'taxable'),
(197, 31, '_tax_class', 'parent'),
(198, 31, '_manage_stock', 'no'),
(199, 31, '_backorders', 'no'),
(200, 31, '_sold_individually', 'no'),
(201, 31, '_virtual', 'no'),
(202, 31, '_downloadable', 'no'),
(203, 31, '_download_limit', '0'),
(204, 31, '_download_expiry', '0'),
(205, 31, '_stock', NULL),
(206, 31, '_stock_status', 'instock'),
(207, 31, '_wc_average_rating', '0'),
(208, 31, '_wc_review_count', '0'),
(209, 31, '_product_version', '8.6.1'),
(211, 32, 'total_sales', '0'),
(212, 32, '_tax_status', 'taxable'),
(213, 32, '_tax_class', 'parent'),
(214, 32, '_manage_stock', 'no'),
(215, 32, '_backorders', 'no'),
(216, 32, '_sold_individually', 'no'),
(217, 32, '_virtual', 'no'),
(218, 32, '_downloadable', 'no') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(219, 32, '_download_limit', '0'),
(220, 32, '_download_expiry', '0'),
(221, 32, '_stock', NULL),
(222, 32, '_stock_status', 'instock'),
(223, 32, '_wc_average_rating', '0'),
(224, 32, '_wc_review_count', '0'),
(225, 32, '_product_version', '8.6.1'),
(227, 33, 'total_sales', '0'),
(228, 33, '_tax_status', 'taxable'),
(229, 33, '_tax_class', 'parent'),
(230, 33, '_manage_stock', 'no'),
(231, 33, '_backorders', 'no'),
(232, 33, '_sold_individually', 'no'),
(233, 33, '_virtual', 'no'),
(234, 33, '_downloadable', 'no'),
(235, 33, '_download_limit', '0'),
(236, 33, '_download_expiry', '0'),
(237, 33, '_stock', NULL),
(238, 33, '_stock_status', 'instock'),
(239, 33, '_wc_average_rating', '0'),
(240, 33, '_wc_review_count', '0'),
(241, 33, '_product_version', '8.6.1'),
(243, 34, 'total_sales', '0'),
(244, 34, '_tax_status', 'taxable'),
(245, 34, '_tax_class', 'parent'),
(246, 34, '_manage_stock', 'no'),
(247, 34, '_backorders', 'no'),
(248, 34, '_sold_individually', 'no'),
(249, 34, '_virtual', 'no'),
(250, 34, '_downloadable', 'no'),
(251, 34, '_download_limit', '0'),
(252, 34, '_download_expiry', '0'),
(253, 34, '_stock', NULL),
(254, 34, '_stock_status', 'instock'),
(255, 34, '_wc_average_rating', '0'),
(256, 34, '_wc_review_count', '0'),
(257, 34, '_product_version', '8.6.1'),
(259, 35, 'total_sales', '0'),
(260, 35, '_tax_status', 'taxable'),
(261, 35, '_tax_class', 'parent'),
(262, 35, '_manage_stock', 'no'),
(263, 35, '_backorders', 'no'),
(264, 35, '_sold_individually', 'no'),
(265, 35, '_virtual', 'no'),
(266, 35, '_downloadable', 'no'),
(267, 35, '_download_limit', '0'),
(268, 35, '_download_expiry', '0'),
(269, 35, '_stock', NULL),
(270, 35, '_stock_status', 'instock'),
(271, 35, '_wc_average_rating', '0'),
(272, 35, '_wc_review_count', '0'),
(273, 35, '_product_version', '8.6.1'),
(275, 36, 'total_sales', '0'),
(276, 36, '_tax_status', 'taxable'),
(277, 36, '_tax_class', 'parent'),
(278, 36, '_manage_stock', 'no'),
(279, 36, '_backorders', 'no'),
(280, 36, '_sold_individually', 'no'),
(281, 36, '_virtual', 'no'),
(282, 36, '_downloadable', 'no'),
(283, 36, '_download_limit', '0'),
(284, 36, '_download_expiry', '0'),
(285, 36, '_stock', NULL),
(286, 36, '_stock_status', 'instock'),
(287, 36, '_wc_average_rating', '0'),
(288, 36, '_wc_review_count', '0'),
(289, 36, '_product_version', '8.6.1'),
(291, 37, 'total_sales', '0'),
(292, 37, '_tax_status', 'taxable'),
(293, 37, '_tax_class', 'parent'),
(294, 37, '_manage_stock', 'no'),
(295, 37, '_backorders', 'no'),
(296, 37, '_sold_individually', 'no'),
(297, 37, '_virtual', 'no'),
(298, 37, '_downloadable', 'no'),
(299, 37, '_download_limit', '0'),
(300, 37, '_download_expiry', '0'),
(301, 37, '_stock', NULL),
(302, 37, '_stock_status', 'instock'),
(303, 37, '_wc_average_rating', '0'),
(304, 37, '_wc_review_count', '0'),
(305, 37, '_product_version', '8.6.1'),
(307, 38, 'total_sales', '0'),
(308, 38, '_tax_status', 'taxable'),
(309, 38, '_tax_class', ''),
(310, 38, '_manage_stock', 'no'),
(311, 38, '_backorders', 'no'),
(312, 38, '_sold_individually', 'no'),
(313, 38, '_virtual', 'no'),
(314, 38, '_downloadable', 'no'),
(315, 38, '_download_limit', '0'),
(316, 38, '_download_expiry', '0'),
(317, 38, '_stock', NULL),
(318, 38, '_stock_status', 'instock'),
(319, 38, '_wc_average_rating', '0'),
(320, 38, '_wc_review_count', '0'),
(321, 38, '_product_version', '8.6.1'),
(323, 39, 'total_sales', '0'),
(324, 39, '_tax_status', 'taxable'),
(325, 39, '_tax_class', 'parent') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(326, 39, '_manage_stock', 'no'),
(327, 39, '_backorders', 'no'),
(328, 39, '_sold_individually', 'no'),
(329, 39, '_virtual', 'no'),
(330, 39, '_downloadable', 'no'),
(331, 39, '_download_limit', '0'),
(332, 39, '_download_expiry', '0'),
(333, 39, '_stock', NULL),
(334, 39, '_stock_status', 'instock'),
(335, 39, '_wc_average_rating', '0'),
(336, 39, '_wc_review_count', '0'),
(337, 39, '_product_version', '8.6.1'),
(339, 40, 'total_sales', '0'),
(340, 40, '_tax_status', 'taxable'),
(341, 40, '_tax_class', 'parent'),
(342, 40, '_manage_stock', 'no'),
(343, 40, '_backorders', 'no'),
(344, 40, '_sold_individually', 'no'),
(345, 40, '_virtual', 'no'),
(346, 40, '_downloadable', 'no'),
(347, 40, '_download_limit', '0'),
(348, 40, '_download_expiry', '0'),
(349, 40, '_stock', NULL),
(350, 40, '_stock_status', 'instock'),
(351, 40, '_wc_average_rating', '0'),
(352, 40, '_wc_review_count', '0'),
(353, 40, '_product_version', '8.6.1'),
(355, 41, 'total_sales', '0'),
(356, 41, '_tax_status', 'taxable'),
(357, 41, '_tax_class', 'parent'),
(358, 41, '_manage_stock', 'no'),
(359, 41, '_backorders', 'no'),
(360, 41, '_sold_individually', 'no'),
(361, 41, '_virtual', 'no'),
(362, 41, '_downloadable', 'no'),
(363, 41, '_download_limit', '0'),
(364, 41, '_download_expiry', '0'),
(365, 41, '_stock', NULL),
(366, 41, '_stock_status', 'instock'),
(367, 41, '_wc_average_rating', '0'),
(368, 41, '_wc_review_count', '0'),
(369, 41, '_product_version', '8.6.1'),
(371, 42, 'total_sales', '0'),
(372, 42, '_tax_status', 'taxable'),
(373, 42, '_tax_class', ''),
(374, 42, '_manage_stock', 'no'),
(375, 42, '_backorders', 'no'),
(376, 42, '_sold_individually', 'no'),
(377, 42, '_virtual', 'no'),
(378, 42, '_downloadable', 'no'),
(379, 42, '_download_limit', '0'),
(380, 42, '_download_expiry', '0'),
(381, 42, '_stock', NULL),
(382, 42, '_stock_status', 'instock'),
(383, 42, '_wc_average_rating', '0'),
(384, 42, '_wc_review_count', '0'),
(385, 42, '_product_version', '8.6.1'),
(387, 43, 'total_sales', '0'),
(388, 43, '_tax_status', 'taxable'),
(389, 43, '_tax_class', 'parent'),
(390, 43, '_manage_stock', 'no'),
(391, 43, '_backorders', 'no'),
(392, 43, '_sold_individually', 'no'),
(393, 43, '_virtual', 'no'),
(394, 43, '_downloadable', 'no'),
(395, 43, '_download_limit', '0'),
(396, 43, '_download_expiry', '0'),
(397, 43, '_stock', NULL),
(398, 43, '_stock_status', 'instock'),
(399, 43, '_wc_average_rating', '0'),
(400, 43, '_wc_review_count', '0'),
(401, 43, '_product_version', '8.6.1'),
(403, 44, 'total_sales', '0'),
(404, 44, '_tax_status', 'taxable'),
(405, 44, '_tax_class', 'parent'),
(406, 44, '_manage_stock', 'no'),
(407, 44, '_backorders', 'no'),
(408, 44, '_sold_individually', 'no'),
(409, 44, '_virtual', 'no'),
(410, 44, '_downloadable', 'no'),
(411, 44, '_download_limit', '0'),
(412, 44, '_download_expiry', '0'),
(413, 44, '_stock', NULL),
(414, 44, '_stock_status', 'instock'),
(415, 44, '_wc_average_rating', '0'),
(416, 44, '_wc_review_count', '0'),
(417, 44, '_product_version', '8.6.1'),
(419, 45, 'total_sales', '0'),
(420, 45, '_tax_status', 'taxable'),
(421, 45, '_tax_class', 'parent'),
(422, 45, '_manage_stock', 'no'),
(423, 45, '_backorders', 'no'),
(424, 45, '_sold_individually', 'no'),
(425, 45, '_virtual', 'no'),
(426, 45, '_downloadable', 'no'),
(427, 45, '_download_limit', '0'),
(428, 45, '_download_expiry', '0'),
(429, 45, '_stock', NULL),
(430, 45, '_stock_status', 'instock'),
(431, 45, '_wc_average_rating', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(432, 45, '_wc_review_count', '0'),
(433, 45, '_product_version', '8.6.1'),
(435, 46, 'total_sales', '0'),
(436, 46, '_tax_status', 'taxable'),
(437, 46, '_tax_class', ''),
(438, 46, '_manage_stock', 'no'),
(439, 46, '_backorders', 'no'),
(440, 46, '_sold_individually', 'no'),
(441, 46, '_virtual', 'no'),
(442, 46, '_downloadable', 'no'),
(443, 46, '_download_limit', '0'),
(444, 46, '_download_expiry', '0'),
(445, 46, '_stock', NULL),
(446, 46, '_stock_status', 'outofstock'),
(447, 46, '_wc_average_rating', '0'),
(448, 46, '_wc_review_count', '0'),
(449, 46, '_product_version', '8.6.1'),
(451, 47, 'total_sales', '0'),
(452, 47, '_tax_status', 'taxable'),
(453, 47, '_tax_class', 'parent'),
(454, 47, '_manage_stock', 'no'),
(455, 47, '_backorders', 'no'),
(456, 47, '_sold_individually', 'no'),
(457, 47, '_virtual', 'no'),
(458, 47, '_downloadable', 'no'),
(459, 47, '_download_limit', '0'),
(460, 47, '_download_expiry', '0'),
(461, 47, '_stock', NULL),
(462, 47, '_stock_status', 'outofstock'),
(463, 47, '_wc_average_rating', '0'),
(464, 47, '_wc_review_count', '0'),
(465, 47, '_product_version', '8.6.1'),
(467, 48, 'total_sales', '0'),
(468, 48, '_tax_status', 'taxable'),
(469, 48, '_tax_class', 'parent'),
(470, 48, '_manage_stock', 'no'),
(471, 48, '_backorders', 'no'),
(472, 48, '_sold_individually', 'no'),
(473, 48, '_virtual', 'no'),
(474, 48, '_downloadable', 'no'),
(475, 48, '_download_limit', '0'),
(476, 48, '_download_expiry', '0'),
(477, 48, '_stock', NULL),
(478, 48, '_stock_status', 'outofstock'),
(479, 48, '_wc_average_rating', '0'),
(480, 48, '_wc_review_count', '0'),
(481, 48, '_product_version', '8.6.1'),
(483, 49, 'total_sales', '0'),
(484, 49, '_tax_status', 'taxable'),
(485, 49, '_tax_class', 'parent'),
(486, 49, '_manage_stock', 'no'),
(487, 49, '_backorders', 'no'),
(488, 49, '_sold_individually', 'no'),
(489, 49, '_virtual', 'no'),
(490, 49, '_downloadable', 'no'),
(491, 49, '_download_limit', '0'),
(492, 49, '_download_expiry', '0'),
(493, 49, '_stock', NULL),
(494, 49, '_stock_status', 'outofstock'),
(495, 49, '_wc_average_rating', '0'),
(496, 49, '_wc_review_count', '0'),
(497, 49, '_product_version', '8.6.1'),
(499, 50, '_wp_attached_file', '2024/03/Bag1.jpg'),
(500, 50, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1262;s:4:"file";s:16:"2024/03/Bag1.jpg";s:8:"filesize";i:138802;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:16:"Bag1-300x197.jpg";s:5:"width";i:300;s:6:"height";i:197;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7885;}s:5:"large";a:5:{s:4:"file";s:17:"Bag1-1024x673.jpg";s:5:"width";i:1024;s:6:"height";i:673;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:47074;}s:9:"thumbnail";a:5:{s:4:"file";s:16:"Bag1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5154;}s:12:"medium_large";a:5:{s:4:"file";s:16:"Bag1-768x505.jpg";s:5:"width";i:768;s:6:"height";i:505;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:30707;}s:9:"1536x1536";a:5:{s:4:"file";s:18:"Bag1-1536x1010.jpg";s:5:"width";i:1536;s:6:"height";i:1010;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:87040;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:16:"Bag1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13606;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:16:"Bag1-600x394.jpg";s:5:"width";i:600;s:6:"height";i:394;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21390;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:16:"Bag1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2872;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:14:"Bag1-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1169;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:16:"Bag1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2872;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(501, 50, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Bag1.jpg'),
(502, 20, '_wp_old_slug', 'import-placeholder-for-66'),
(503, 20, '_regular_price', '19.99'),
(504, 20, '_thumbnail_id', '50'),
(505, 20, '_product_attributes', 'a:1:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}}'),
(506, 20, '_price', '19.99'),
(507, 51, '_wp_attached_file', '2024/03/Bag1-1.jpg'),
(508, 51, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1262;s:4:"file";s:18:"2024/03/Bag1-1.jpg";s:8:"filesize";i:126798;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:18:"Bag1-1-300x197.jpg";s:5:"width";i:300;s:6:"height";i:197;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7647;}s:5:"large";a:5:{s:4:"file";s:19:"Bag1-1-1024x673.jpg";s:5:"width";i:1024;s:6:"height";i:673;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:52417;}s:9:"thumbnail";a:5:{s:4:"file";s:18:"Bag1-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5011;}s:12:"medium_large";a:5:{s:4:"file";s:18:"Bag1-1-768x505.jpg";s:5:"width";i:768;s:6:"height";i:505;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:32777;}s:9:"1536x1536";a:5:{s:4:"file";s:20:"Bag1-1-1536x1010.jpg";s:5:"width";i:1536;s:6:"height";i:1010;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:98624;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:18:"Bag1-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13990;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:18:"Bag1-1-600x394.jpg";s:5:"width";i:600;s:6:"height";i:394;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22167;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:18:"Bag1-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2822;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:16:"Bag1-1-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1208;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:18:"Bag1-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2822;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(509, 51, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Bag1-1.jpg'),
(510, 52, '_wp_attached_file', '2024/03/Bag1-2.jpg'),
(511, 52, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1262;s:4:"file";s:18:"2024/03/Bag1-2.jpg";s:8:"filesize";i:80013;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:18:"Bag1-2-300x197.jpg";s:5:"width";i:300;s:6:"height";i:197;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4805;}s:5:"large";a:5:{s:4:"file";s:19:"Bag1-2-1024x673.jpg";s:5:"width";i:1024;s:6:"height";i:673;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:28467;}s:9:"thumbnail";a:5:{s:4:"file";s:18:"Bag1-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3182;}s:12:"medium_large";a:5:{s:4:"file";s:18:"Bag1-2-768x505.jpg";s:5:"width";i:768;s:6:"height";i:505;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18490;}s:9:"1536x1536";a:5:{s:4:"file";s:20:"Bag1-2-1536x1010.jpg";s:5:"width";i:1536;s:6:"height";i:1010;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:53373;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:18:"Bag1-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8318;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:18:"Bag1-2-600x394.jpg";s:5:"width";i:600;s:6:"height";i:394;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12872;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:18:"Bag1-2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1862;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:16:"Bag1-2-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:901;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:18:"Bag1-2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1862;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(512, 52, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Bag1-2.jpg'),
(513, 20, '_et_pb_post_hide_nav', 'default'),
(514, 20, '_et_pb_page_layout', 'et_right_sidebar'),
(515, 20, '_et_pb_side_nav', 'off'),
(516, 20, '_et_pb_use_builder', ''),
(517, 20, '_et_pb_first_image', ''),
(518, 20, '_et_pb_truncate_post', ''),
(519, 20, '_et_pb_truncate_post_date', ''),
(520, 20, '_et_pb_old_content', ''),
(521, 20, '_product_image_gallery', '51,52'),
(522, 53, '_wp_attached_file', '2024/03/Bag2.jpg'),
(523, 53, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1262;s:4:"file";s:16:"2024/03/Bag2.jpg";s:8:"filesize";i:127403;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:16:"Bag2-300x197.jpg";s:5:"width";i:300;s:6:"height";i:197;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10886;}s:5:"large";a:5:{s:4:"file";s:17:"Bag2-1024x673.jpg";s:5:"width";i:1024;s:6:"height";i:673;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:64582;}s:9:"thumbnail";a:5:{s:4:"file";s:16:"Bag2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6852;}s:12:"medium_large";a:5:{s:4:"file";s:16:"Bag2-768x505.jpg";s:5:"width";i:768;s:6:"height";i:505;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:42666;}s:9:"1536x1536";a:5:{s:4:"file";s:18:"Bag2-1536x1010.jpg";s:5:"width";i:1536;s:6:"height";i:1010;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:113719;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:16:"Bag2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19413;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:16:"Bag2-600x394.jpg";s:5:"width";i:600;s:6:"height";i:394;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:30234;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:16:"Bag2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3670;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:14:"Bag2-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1314;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:16:"Bag2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3670;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(524, 53, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Bag2.jpg'),
(525, 21, '_wp_old_slug', 'import-placeholder-for-70'),
(526, 21, '_regular_price', '19.99'),
(527, 21, '_thumbnail_id', '53'),
(528, 21, '_product_attributes', 'a:1:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}}'),
(529, 21, '_price', '19.99'),
(530, 54, '_wp_attached_file', '2024/03/Bag2-1.jpg'),
(531, 54, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1262;s:4:"file";s:18:"2024/03/Bag2-1.jpg";s:8:"filesize";i:127386;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:18:"Bag2-1-300x197.jpg";s:5:"width";i:300;s:6:"height";i:197;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9332;}s:5:"large";a:5:{s:4:"file";s:19:"Bag2-1-1024x673.jpg";s:5:"width";i:1024;s:6:"height";i:673;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:64056;}s:9:"thumbnail";a:5:{s:4:"file";s:18:"Bag2-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5960;}s:12:"medium_large";a:5:{s:4:"file";s:18:"Bag2-1-768x505.jpg";s:5:"width";i:768;s:6:"height";i:505;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:40707;}s:9:"1536x1536";a:5:{s:4:"file";s:20:"Bag2-1-1536x1010.jpg";s:5:"width";i:1536;s:6:"height";i:1010;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:117454;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:18:"Bag2-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17462;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:18:"Bag2-1-600x394.jpg";s:5:"width";i:600;s:6:"height";i:394;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:27795;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:18:"Bag2-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3172;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:16:"Bag2-1-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1256;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:18:"Bag2-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3172;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(532, 54, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Bag2-1.jpg'),
(533, 55, '_wp_attached_file', '2024/03/Bag2-2.jpg'),
(534, 55, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1262;s:4:"file";s:18:"2024/03/Bag2-2.jpg";s:8:"filesize";i:90611;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:18:"Bag2-2-300x197.jpg";s:5:"width";i:300;s:6:"height";i:197;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6836;}s:5:"large";a:5:{s:4:"file";s:19:"Bag2-2-1024x673.jpg";s:5:"width";i:1024;s:6:"height";i:673;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:42062;}s:9:"thumbnail";a:5:{s:4:"file";s:18:"Bag2-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4360;}s:12:"medium_large";a:5:{s:4:"file";s:18:"Bag2-2-768x505.jpg";s:5:"width";i:768;s:6:"height";i:505;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:27472;}s:9:"1536x1536";a:5:{s:4:"file";s:20:"Bag2-2-1536x1010.jpg";s:5:"width";i:1536;s:6:"height";i:1010;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:73249;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:18:"Bag2-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12405;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:18:"Bag2-2-600x394.jpg";s:5:"width";i:600;s:6:"height";i:394;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19375;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:18:"Bag2-2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2403;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:16:"Bag2-2-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:998;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:18:"Bag2-2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2403;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(535, 55, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Bag2-2.jpg'),
(536, 21, '_et_pb_post_hide_nav', 'default') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(537, 21, '_et_pb_page_layout', 'et_right_sidebar'),
(538, 21, '_et_pb_side_nav', 'off'),
(539, 21, '_et_pb_use_builder', ''),
(540, 21, '_et_pb_first_image', ''),
(541, 21, '_et_pb_truncate_post', ''),
(542, 21, '_et_pb_truncate_post_date', ''),
(543, 21, '_et_pb_old_content', ''),
(544, 21, '_product_image_gallery', '54,55'),
(545, 56, '_wp_attached_file', '2024/03/DE-Pins-4.jpg'),
(546, 56, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1280;s:4:"file";s:21:"2024/03/DE-Pins-4.jpg";s:8:"filesize";i:99240;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:21:"DE-Pins-4-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5760;}s:5:"large";a:5:{s:4:"file";s:22:"DE-Pins-4-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:33688;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"DE-Pins-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3873;}s:12:"medium_large";a:5:{s:4:"file";s:21:"DE-Pins-4-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21440;}s:9:"1536x1536";a:5:{s:4:"file";s:23:"DE-Pins-4-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:63402;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:21:"DE-Pins-4-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9529;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:21:"DE-Pins-4-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14955;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:21:"DE-Pins-4-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2340;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:19:"DE-Pins-4-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1094;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:21:"DE-Pins-4-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2340;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(547, 56, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/DE-Pins-4.jpg'),
(548, 22, '_wp_old_slug', 'import-placeholder-for-74'),
(549, 22, '_default_attributes', 'a:1:{s:8:"pa_brand";s:11:"divi-engine";}'),
(550, 22, '_thumbnail_id', '56'),
(551, 22, '_product_attributes', 'a:1:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(552, 22, '_et_pb_post_hide_nav', 'default'),
(553, 22, '_et_pb_page_layout', 'et_right_sidebar'),
(554, 22, '_et_pb_side_nav', 'off'),
(555, 22, '_et_pb_use_builder', ''),
(556, 22, '_et_pb_first_image', ''),
(557, 22, '_et_pb_truncate_post', ''),
(558, 22, '_et_pb_truncate_post_date', ''),
(559, 22, '_et_pb_old_content', ''),
(560, 57, '_wp_attached_file', '2024/03/DE-Pins-1.jpg'),
(561, 57, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1280;s:4:"file";s:21:"2024/03/DE-Pins-1.jpg";s:8:"filesize";i:100127;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:21:"DE-Pins-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6313;}s:5:"large";a:5:{s:4:"file";s:22:"DE-Pins-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:34822;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"DE-Pins-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4123;}s:12:"medium_large";a:5:{s:4:"file";s:21:"DE-Pins-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22774;}s:9:"1536x1536";a:5:{s:4:"file";s:23:"DE-Pins-1-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:64274;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:21:"DE-Pins-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10557;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:21:"DE-Pins-1-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16203;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:21:"DE-Pins-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2452;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:19:"DE-Pins-1-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1127;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:21:"DE-Pins-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2452;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(562, 57, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/DE-Pins-1.jpg'),
(563, 23, '_wp_old_slug', 'import-placeholder-for-75'),
(564, 23, '_variation_description', 'Rep your love for Divi!'),
(565, 23, '_regular_price', '9.99'),
(566, 23, '_thumbnail_id', '57'),
(567, 23, 'attribute_pa_brand', 'divi'),
(568, 23, '_price', '9.99'),
(569, 23, '_et_pb_post_hide_nav', ''),
(570, 23, '_et_pb_page_layout', ''),
(571, 23, '_et_pb_side_nav', ''),
(572, 23, '_et_pb_use_builder', ''),
(573, 23, '_et_pb_first_image', ''),
(574, 23, '_et_pb_truncate_post', ''),
(575, 23, '_et_pb_truncate_post_date', ''),
(576, 23, '_et_pb_old_content', ''),
(577, 24, '_wp_old_slug', 'import-placeholder-for-76'),
(578, 24, '_variation_description', 'Rep your love for Divi Engine!'),
(579, 24, '_regular_price', '9.99'),
(580, 24, '_thumbnail_id', '56'),
(581, 24, 'attribute_pa_brand', 'divi-engine'),
(582, 24, '_price', '9.99'),
(583, 24, '_et_pb_post_hide_nav', ''),
(584, 24, '_et_pb_page_layout', ''),
(585, 24, '_et_pb_side_nav', ''),
(586, 24, '_et_pb_use_builder', ''),
(587, 24, '_et_pb_first_image', ''),
(588, 24, '_et_pb_truncate_post', ''),
(589, 24, '_et_pb_truncate_post_date', ''),
(590, 24, '_et_pb_old_content', ''),
(591, 58, '_wp_attached_file', '2024/03/DE-Pins-2.jpg'),
(592, 58, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1280;s:4:"file";s:21:"2024/03/DE-Pins-2.jpg";s:8:"filesize";i:97565;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:21:"DE-Pins-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5931;}s:5:"large";a:5:{s:4:"file";s:22:"DE-Pins-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:35734;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"DE-Pins-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3848;}s:12:"medium_large";a:5:{s:4:"file";s:21:"DE-Pins-2-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:23331;}s:9:"1536x1536";a:5:{s:4:"file";s:23:"DE-Pins-2-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:65640;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:21:"DE-Pins-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10148;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:21:"DE-Pins-2-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16104;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:21:"DE-Pins-2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2261;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:19:"DE-Pins-2-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1033;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:21:"DE-Pins-2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2261;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(593, 58, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/DE-Pins-2.jpg'),
(594, 25, '_wp_old_slug', 'import-placeholder-for-77'),
(595, 25, '_variation_description', 'Rep your love for WooCommerce!'),
(596, 25, '_regular_price', '9.99'),
(597, 25, '_thumbnail_id', '58'),
(598, 25, 'attribute_pa_brand', 'woocommerce'),
(599, 25, '_price', '9.99'),
(600, 25, '_et_pb_post_hide_nav', ''),
(601, 25, '_et_pb_page_layout', ''),
(602, 25, '_et_pb_side_nav', ''),
(603, 25, '_et_pb_use_builder', ''),
(604, 25, '_et_pb_first_image', ''),
(605, 25, '_et_pb_truncate_post', ''),
(606, 25, '_et_pb_truncate_post_date', ''),
(607, 25, '_et_pb_old_content', ''),
(608, 59, '_wp_attached_file', '2024/03/DE-Pins-3.jpg'),
(609, 59, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1280;s:4:"file";s:21:"2024/03/DE-Pins-3.jpg";s:8:"filesize";i:118676;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:21:"DE-Pins-3-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6844;}s:5:"large";a:5:{s:4:"file";s:22:"DE-Pins-3-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:41425;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"DE-Pins-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4452;}s:12:"medium_large";a:5:{s:4:"file";s:21:"DE-Pins-3-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:26935;}s:9:"1536x1536";a:5:{s:4:"file";s:23:"DE-Pins-3-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:75876;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:21:"DE-Pins-3-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11785;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:21:"DE-Pins-3-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18961;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:21:"DE-Pins-3-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2550;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:19:"DE-Pins-3-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1140;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:21:"DE-Pins-3-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2550;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(610, 59, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/DE-Pins-3.jpg'),
(611, 26, '_wp_old_slug', 'import-placeholder-for-78'),
(612, 26, '_variation_description', 'Rep your love for WordPress!'),
(613, 26, '_regular_price', '9.99'),
(614, 26, '_thumbnail_id', '59'),
(615, 26, 'attribute_pa_brand', 'wordpress'),
(616, 26, '_price', '9.99'),
(617, 26, '_et_pb_post_hide_nav', ''),
(618, 26, '_et_pb_page_layout', ''),
(619, 26, '_et_pb_side_nav', ''),
(620, 26, '_et_pb_use_builder', ''),
(621, 26, '_et_pb_first_image', ''),
(622, 26, '_et_pb_truncate_post', ''),
(623, 26, '_et_pb_truncate_post_date', ''),
(624, 26, '_et_pb_old_content', ''),
(625, 60, '_wp_attached_file', '2024/03/Lanyard1.jpg'),
(626, 60, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1262;s:4:"file";s:20:"2024/03/Lanyard1.jpg";s:8:"filesize";i:38551;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:20:"Lanyard1-300x197.jpg";s:5:"width";i:300;s:6:"height";i:197;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3475;}s:5:"large";a:5:{s:4:"file";s:21:"Lanyard1-1024x673.jpg";s:5:"width";i:1024;s:6:"height";i:673;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21440;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"Lanyard1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2351;}s:12:"medium_large";a:5:{s:4:"file";s:20:"Lanyard1-768x505.jpg";s:5:"width";i:768;s:6:"height";i:505;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13691;}s:9:"1536x1536";a:5:{s:4:"file";s:22:"Lanyard1-1536x1010.jpg";s:5:"width";i:1536;s:6:"height";i:1010;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:41188;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:20:"Lanyard1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5884;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:20:"Lanyard1-600x394.jpg";s:5:"width";i:600;s:6:"height";i:394;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9364;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:20:"Lanyard1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1502;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:18:"Lanyard1-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:806;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:20:"Lanyard1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1502;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(627, 60, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Lanyard1.jpg'),
(628, 27, '_wp_old_slug', 'import-placeholder-for-83'),
(629, 27, '_regular_price', '9.99'),
(630, 27, '_sale_price', '7.99'),
(631, 27, '_thumbnail_id', '60'),
(632, 27, '_product_attributes', 'a:1:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}}'),
(633, 27, '_price', '7.99'),
(634, 27, '_et_pb_post_hide_nav', 'default'),
(635, 27, '_et_pb_page_layout', 'et_right_sidebar'),
(636, 27, '_et_pb_side_nav', 'off') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(637, 27, '_et_pb_use_builder', ''),
(638, 27, '_et_pb_first_image', ''),
(639, 27, '_et_pb_truncate_post', ''),
(640, 27, '_et_pb_truncate_post_date', ''),
(641, 27, '_et_pb_old_content', ''),
(642, 61, '_wp_attached_file', '2024/03/Shirt-3-yellow-front.jpg'),
(643, 61, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1360;s:4:"file";s:32:"2024/03/Shirt-3-yellow-front.jpg";s:8:"filesize";i:144777;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:32:"Shirt-3-yellow-front-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4615;}s:5:"large";a:5:{s:4:"file";s:33:"Shirt-3-yellow-front-1024x725.jpg";s:5:"width";i:1024;s:6:"height";i:725;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:30037;}s:9:"thumbnail";a:5:{s:4:"file";s:32:"Shirt-3-yellow-front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2861;}s:12:"medium_large";a:5:{s:4:"file";s:32:"Shirt-3-yellow-front-768x544.jpg";s:5:"width";i:768;s:6:"height";i:544;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17564;}s:9:"1536x1536";a:5:{s:4:"file";s:34:"Shirt-3-yellow-front-1536x1088.jpg";s:5:"width";i:1536;s:6:"height";i:1088;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:72803;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:32:"Shirt-3-yellow-front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6958;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:32:"Shirt-3-yellow-front-600x425.jpg";s:5:"width";i:600;s:6:"height";i:425;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11935;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:32:"Shirt-3-yellow-front-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1910;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:30:"Shirt-3-yellow-front-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:995;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:32:"Shirt-3-yellow-front-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1910;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(644, 61, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Shirt-3-yellow-front.jpg'),
(645, 28, '_wp_old_slug', 'import-placeholder-for-89'),
(646, 28, '_default_attributes', 'a:2:{s:8:"pa_color";s:6:"yellow";s:7:"pa_size";s:5:"large";}'),
(647, 28, '_thumbnail_id', '61'),
(648, 28, '_product_attributes', 'a:3:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:8:"pa_color";a:6:{s:4:"name";s:8:"pa_color";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:2;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(649, 62, '_wp_attached_file', '2024/03/Shirt-3-blue-front.jpg'),
(650, 62, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1360;s:4:"file";s:30:"2024/03/Shirt-3-blue-front.jpg";s:8:"filesize";i:133307;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:30:"Shirt-3-blue-front-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4054;}s:5:"large";a:5:{s:4:"file";s:31:"Shirt-3-blue-front-1024x725.jpg";s:5:"width";i:1024;s:6:"height";i:725;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:27114;}s:9:"thumbnail";a:5:{s:4:"file";s:30:"Shirt-3-blue-front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2523;}s:12:"medium_large";a:5:{s:4:"file";s:30:"Shirt-3-blue-front-768x544.jpg";s:5:"width";i:768;s:6:"height";i:544;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15784;}s:9:"1536x1536";a:5:{s:4:"file";s:32:"Shirt-3-blue-front-1536x1088.jpg";s:5:"width";i:1536;s:6:"height";i:1088;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:66502;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:30:"Shirt-3-blue-front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6156;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:30:"Shirt-3-blue-front-600x425.jpg";s:5:"width";i:600;s:6:"height";i:425;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10673;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:30:"Shirt-3-blue-front-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1678;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:28:"Shirt-3-blue-front-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:886;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:30:"Shirt-3-blue-front-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1678;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(651, 62, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Shirt-3-blue-front.jpg'),
(652, 63, '_wp_attached_file', '2024/03/Shirt-3-white-front.jpg'),
(653, 63, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1360;s:4:"file";s:31:"2024/03/Shirt-3-white-front.jpg";s:8:"filesize";i:142381;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:31:"Shirt-3-white-front-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4445;}s:5:"large";a:5:{s:4:"file";s:32:"Shirt-3-white-front-1024x725.jpg";s:5:"width";i:1024;s:6:"height";i:725;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:29298;}s:9:"thumbnail";a:5:{s:4:"file";s:31:"Shirt-3-white-front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2766;}s:12:"medium_large";a:5:{s:4:"file";s:31:"Shirt-3-white-front-768x544.jpg";s:5:"width";i:768;s:6:"height";i:544;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17058;}s:9:"1536x1536";a:5:{s:4:"file";s:33:"Shirt-3-white-front-1536x1088.jpg";s:5:"width";i:1536;s:6:"height";i:1088;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:71454;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:31:"Shirt-3-white-front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6755;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:31:"Shirt-3-white-front-600x425.jpg";s:5:"width";i:600;s:6:"height";i:425;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11613;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:31:"Shirt-3-white-front-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1840;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:29:"Shirt-3-white-front-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:979;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:31:"Shirt-3-white-front-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1840;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(654, 63, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Shirt-3-white-front.jpg'),
(655, 28, '_et_pb_post_hide_nav', 'default'),
(656, 28, '_et_pb_page_layout', 'et_right_sidebar'),
(657, 28, '_et_pb_side_nav', 'off'),
(658, 28, '_et_pb_use_builder', ''),
(659, 28, '_et_pb_first_image', ''),
(660, 28, '_et_pb_truncate_post', ''),
(661, 28, '_et_pb_truncate_post_date', ''),
(662, 28, '_et_pb_old_content', ''),
(663, 28, '_product_image_gallery', '62,63'),
(664, 22, '_price', '9.99'),
(665, 64, 'total_sales', '0'),
(666, 64, '_tax_status', 'taxable'),
(667, 64, '_tax_class', ''),
(668, 64, '_manage_stock', 'no'),
(669, 64, '_backorders', 'no'),
(670, 64, '_sold_individually', 'no'),
(671, 64, '_virtual', 'no'),
(672, 64, '_downloadable', 'no'),
(673, 64, '_download_limit', '0'),
(674, 64, '_download_expiry', '0'),
(675, 64, '_stock', NULL),
(676, 64, '_stock_status', 'instock'),
(677, 64, '_wc_average_rating', '0'),
(678, 64, '_wc_review_count', '0'),
(679, 64, '_product_version', '8.6.1'),
(681, 65, 'total_sales', '0'),
(682, 65, '_tax_status', 'taxable'),
(683, 65, '_tax_class', 'parent'),
(684, 65, '_manage_stock', 'yes'),
(685, 65, '_backorders', 'no'),
(686, 65, '_sold_individually', 'no'),
(687, 65, '_virtual', 'no'),
(688, 65, '_downloadable', 'no'),
(689, 65, '_download_limit', '0'),
(690, 65, '_download_expiry', '0'),
(691, 65, '_stock', '100'),
(692, 65, '_stock_status', 'instock'),
(693, 65, '_wc_average_rating', '0'),
(694, 65, '_wc_review_count', '0'),
(695, 65, '_product_version', '8.6.1'),
(697, 66, 'total_sales', '0'),
(698, 66, '_tax_status', 'taxable'),
(699, 66, '_tax_class', 'parent'),
(700, 66, '_manage_stock', 'yes'),
(701, 66, '_backorders', 'no'),
(702, 66, '_sold_individually', 'no'),
(703, 66, '_virtual', 'no'),
(704, 66, '_downloadable', 'no'),
(705, 66, '_download_limit', '0'),
(706, 66, '_download_expiry', '0'),
(707, 66, '_stock', '2'),
(708, 66, '_stock_status', 'instock'),
(709, 66, '_wc_average_rating', '0'),
(710, 66, '_wc_review_count', '0'),
(711, 66, '_product_version', '8.6.1'),
(713, 67, 'total_sales', '0'),
(714, 67, '_tax_status', 'taxable'),
(715, 67, '_tax_class', 'parent'),
(716, 67, '_manage_stock', 'yes'),
(717, 67, '_backorders', 'no'),
(718, 67, '_sold_individually', 'no'),
(719, 67, '_virtual', 'no'),
(720, 67, '_downloadable', 'no'),
(721, 67, '_download_limit', '0'),
(722, 67, '_download_expiry', '0'),
(723, 67, '_stock', '33'),
(724, 67, '_stock_status', 'instock'),
(725, 67, '_wc_average_rating', '0'),
(726, 67, '_wc_review_count', '0'),
(727, 67, '_product_version', '8.6.1'),
(729, 68, 'total_sales', '0'),
(730, 68, '_tax_status', 'taxable'),
(731, 68, '_tax_class', ''),
(732, 68, '_manage_stock', 'no'),
(733, 68, '_backorders', 'no'),
(734, 68, '_sold_individually', 'no'),
(735, 68, '_virtual', 'no'),
(736, 68, '_downloadable', 'no'),
(737, 68, '_download_limit', '0'),
(738, 68, '_download_expiry', '0'),
(739, 68, '_stock', NULL),
(740, 68, '_stock_status', 'instock') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(741, 68, '_wc_average_rating', '0'),
(742, 68, '_wc_review_count', '0'),
(743, 68, '_product_version', '8.6.1'),
(745, 69, 'total_sales', '0'),
(746, 69, '_tax_status', 'taxable'),
(747, 69, '_tax_class', 'parent'),
(748, 69, '_manage_stock', 'no'),
(749, 69, '_backorders', 'no'),
(750, 69, '_sold_individually', 'no'),
(751, 69, '_virtual', 'no'),
(752, 69, '_downloadable', 'no'),
(753, 69, '_download_limit', '0'),
(754, 69, '_download_expiry', '0'),
(755, 69, '_stock', NULL),
(756, 69, '_stock_status', 'instock'),
(757, 69, '_wc_average_rating', '0'),
(758, 69, '_wc_review_count', '0'),
(759, 69, '_product_version', '8.6.1'),
(761, 70, 'total_sales', '0'),
(762, 70, '_tax_status', 'taxable'),
(763, 70, '_tax_class', 'parent'),
(764, 70, '_manage_stock', 'no'),
(765, 70, '_backorders', 'no'),
(766, 70, '_sold_individually', 'no'),
(767, 70, '_virtual', 'no'),
(768, 70, '_downloadable', 'no'),
(769, 70, '_download_limit', '0'),
(770, 70, '_download_expiry', '0'),
(771, 70, '_stock', NULL),
(772, 70, '_stock_status', 'instock'),
(773, 70, '_wc_average_rating', '0'),
(774, 70, '_wc_review_count', '0'),
(775, 70, '_product_version', '8.6.1'),
(777, 71, 'total_sales', '0'),
(778, 71, '_tax_status', 'taxable'),
(779, 71, '_tax_class', 'parent'),
(780, 71, '_manage_stock', 'no'),
(781, 71, '_backorders', 'no'),
(782, 71, '_sold_individually', 'no'),
(783, 71, '_virtual', 'no'),
(784, 71, '_downloadable', 'no'),
(785, 71, '_download_limit', '0'),
(786, 71, '_download_expiry', '0'),
(787, 71, '_stock', NULL),
(788, 71, '_stock_status', 'instock'),
(789, 71, '_wc_average_rating', '0'),
(790, 71, '_wc_review_count', '0'),
(791, 71, '_product_version', '8.6.1'),
(793, 72, 'total_sales', '0'),
(794, 72, '_tax_status', 'taxable'),
(795, 72, '_tax_class', ''),
(796, 72, '_manage_stock', 'no'),
(797, 72, '_backorders', 'no'),
(798, 72, '_sold_individually', 'no'),
(799, 72, '_virtual', 'no'),
(800, 72, '_downloadable', 'no'),
(801, 72, '_download_limit', '0'),
(802, 72, '_download_expiry', '0'),
(803, 72, '_stock', NULL),
(804, 72, '_stock_status', 'instock'),
(805, 72, '_wc_average_rating', '0'),
(806, 72, '_wc_review_count', '0'),
(807, 72, '_product_version', '8.6.1'),
(809, 29, '_wp_old_slug', 'import-placeholder-for-93'),
(810, 29, '_variation_description', ''),
(811, 29, '_regular_price', '14.99'),
(812, 29, '_thumbnail_id', '62'),
(813, 29, 'attribute_pa_color', 'blue'),
(814, 29, 'attribute_pa_size', 'large'),
(815, 29, '_price', '14.99'),
(816, 29, '_et_pb_post_hide_nav', ''),
(817, 29, '_et_pb_page_layout', ''),
(818, 29, '_et_pb_side_nav', ''),
(819, 29, '_et_pb_use_builder', ''),
(820, 29, '_et_pb_first_image', ''),
(821, 29, '_et_pb_truncate_post', ''),
(822, 29, '_et_pb_truncate_post_date', ''),
(823, 29, '_et_pb_old_content', ''),
(824, 30, '_wp_old_slug', 'import-placeholder-for-94'),
(825, 30, '_variation_description', ''),
(826, 30, '_regular_price', '14.99'),
(827, 30, '_thumbnail_id', '63'),
(828, 30, 'attribute_pa_color', 'white'),
(829, 30, 'attribute_pa_size', 'large'),
(830, 30, '_price', '14.99'),
(831, 30, '_et_pb_post_hide_nav', ''),
(832, 30, '_et_pb_page_layout', ''),
(833, 30, '_et_pb_side_nav', ''),
(834, 30, '_et_pb_use_builder', ''),
(835, 30, '_et_pb_first_image', ''),
(836, 30, '_et_pb_truncate_post', ''),
(837, 30, '_et_pb_truncate_post_date', ''),
(838, 30, '_et_pb_old_content', ''),
(839, 31, '_wp_old_slug', 'import-placeholder-for-95'),
(840, 31, '_variation_description', ''),
(841, 31, '_regular_price', '14.99'),
(842, 31, '_thumbnail_id', '61'),
(843, 31, 'attribute_pa_color', 'yellow'),
(844, 31, 'attribute_pa_size', 'large'),
(845, 31, '_price', '14.99') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(846, 31, '_et_pb_post_hide_nav', ''),
(847, 31, '_et_pb_page_layout', ''),
(848, 31, '_et_pb_side_nav', ''),
(849, 31, '_et_pb_use_builder', ''),
(850, 31, '_et_pb_first_image', ''),
(851, 31, '_et_pb_truncate_post', ''),
(852, 31, '_et_pb_truncate_post_date', ''),
(853, 31, '_et_pb_old_content', ''),
(854, 32, '_wp_old_slug', 'import-placeholder-for-96'),
(855, 32, '_variation_description', ''),
(856, 32, '_regular_price', '14.99'),
(857, 32, '_thumbnail_id', '62'),
(858, 32, 'attribute_pa_color', 'blue'),
(859, 32, 'attribute_pa_size', 'medium'),
(860, 32, '_price', '14.99'),
(861, 32, '_et_pb_post_hide_nav', ''),
(862, 32, '_et_pb_page_layout', ''),
(863, 32, '_et_pb_side_nav', ''),
(864, 32, '_et_pb_use_builder', ''),
(865, 32, '_et_pb_first_image', ''),
(866, 32, '_et_pb_truncate_post', ''),
(867, 32, '_et_pb_truncate_post_date', ''),
(868, 32, '_et_pb_old_content', ''),
(869, 33, '_wp_old_slug', 'import-placeholder-for-97'),
(870, 33, '_variation_description', ''),
(871, 33, '_regular_price', '14.99'),
(872, 33, '_thumbnail_id', '63'),
(873, 33, 'attribute_pa_color', 'white'),
(874, 33, 'attribute_pa_size', 'medium'),
(875, 33, '_price', '14.99'),
(876, 33, '_et_pb_post_hide_nav', ''),
(877, 33, '_et_pb_page_layout', ''),
(878, 33, '_et_pb_side_nav', ''),
(879, 33, '_et_pb_use_builder', ''),
(880, 33, '_et_pb_first_image', ''),
(881, 33, '_et_pb_truncate_post', ''),
(882, 33, '_et_pb_truncate_post_date', ''),
(883, 33, '_et_pb_old_content', ''),
(884, 34, '_wp_old_slug', 'import-placeholder-for-98'),
(885, 34, '_variation_description', ''),
(886, 34, '_regular_price', '14.99'),
(887, 34, '_thumbnail_id', '61'),
(888, 34, 'attribute_pa_color', 'yellow'),
(889, 34, 'attribute_pa_size', 'medium'),
(890, 34, '_price', '14.99'),
(891, 34, '_et_pb_post_hide_nav', ''),
(892, 34, '_et_pb_page_layout', ''),
(893, 34, '_et_pb_side_nav', ''),
(894, 34, '_et_pb_use_builder', ''),
(895, 34, '_et_pb_first_image', ''),
(896, 34, '_et_pb_truncate_post', ''),
(897, 34, '_et_pb_truncate_post_date', ''),
(898, 34, '_et_pb_old_content', ''),
(899, 35, '_wp_old_slug', 'import-placeholder-for-99'),
(900, 35, '_variation_description', ''),
(901, 35, '_regular_price', '14.99'),
(902, 35, '_thumbnail_id', '62'),
(903, 35, 'attribute_pa_color', 'blue'),
(904, 35, 'attribute_pa_size', 'small'),
(905, 35, '_price', '14.99'),
(906, 35, '_et_pb_post_hide_nav', ''),
(907, 35, '_et_pb_page_layout', ''),
(908, 35, '_et_pb_side_nav', ''),
(909, 35, '_et_pb_use_builder', ''),
(910, 35, '_et_pb_first_image', ''),
(911, 35, '_et_pb_truncate_post', ''),
(912, 35, '_et_pb_truncate_post_date', ''),
(913, 35, '_et_pb_old_content', ''),
(914, 36, '_wp_old_slug', 'import-placeholder-for-100'),
(915, 36, '_variation_description', ''),
(916, 36, '_regular_price', '14.99'),
(917, 36, '_thumbnail_id', '63'),
(918, 36, 'attribute_pa_color', 'white'),
(919, 36, 'attribute_pa_size', 'small'),
(920, 36, '_price', '14.99'),
(921, 36, '_et_pb_post_hide_nav', ''),
(922, 36, '_et_pb_page_layout', ''),
(923, 36, '_et_pb_side_nav', ''),
(924, 36, '_et_pb_use_builder', ''),
(925, 36, '_et_pb_first_image', ''),
(926, 36, '_et_pb_truncate_post', ''),
(927, 36, '_et_pb_truncate_post_date', ''),
(928, 36, '_et_pb_old_content', ''),
(929, 37, '_wp_old_slug', 'import-placeholder-for-101'),
(930, 37, '_variation_description', ''),
(931, 37, '_regular_price', '14.99'),
(932, 37, '_thumbnail_id', '61'),
(933, 37, 'attribute_pa_color', 'yellow'),
(934, 37, 'attribute_pa_size', 'small'),
(935, 37, '_price', '14.99'),
(936, 37, '_et_pb_post_hide_nav', ''),
(937, 37, '_et_pb_page_layout', ''),
(938, 37, '_et_pb_side_nav', ''),
(939, 37, '_et_pb_use_builder', ''),
(940, 37, '_et_pb_first_image', ''),
(941, 37, '_et_pb_truncate_post', ''),
(942, 37, '_et_pb_truncate_post_date', ''),
(943, 37, '_et_pb_old_content', ''),
(944, 73, '_wp_attached_file', '2024/03/Shirt-2-front.jpg'),
(945, 73, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1360;s:4:"file";s:25:"2024/03/Shirt-2-front.jpg";s:8:"filesize";i:140361;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:25:"Shirt-2-front-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4734;}s:5:"large";a:5:{s:4:"file";s:26:"Shirt-2-front-1024x725.jpg";s:5:"width";i:1024;s:6:"height";i:725;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:29705;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"Shirt-2-front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2964;}s:12:"medium_large";a:5:{s:4:"file";s:25:"Shirt-2-front-768x544.jpg";s:5:"width";i:768;s:6:"height";i:544;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17630;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"Shirt-2-front-1536x1088.jpg";s:5:"width";i:1536;s:6:"height";i:1088;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:70827;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:25:"Shirt-2-front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7181;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:25:"Shirt-2-front-600x425.jpg";s:5:"width";i:600;s:6:"height";i:425;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12097;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:25:"Shirt-2-front-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1962;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:23:"Shirt-2-front-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1017;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:25:"Shirt-2-front-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1962;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(946, 73, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Shirt-2---front.jpg'),
(947, 38, '_wp_old_slug', 'import-placeholder-for-105'),
(948, 38, '_default_attributes', 'a:1:{s:7:"pa_size";s:5:"large";}'),
(949, 38, '_thumbnail_id', '73'),
(950, 38, '_product_attributes', 'a:2:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(951, 74, '_wp_attached_file', '2024/03/Shirt-2-back.jpg'),
(952, 74, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1360;s:4:"file";s:24:"2024/03/Shirt-2-back.jpg";s:8:"filesize";i:138132;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:24:"Shirt-2-back-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4569;}s:5:"large";a:5:{s:4:"file";s:25:"Shirt-2-back-1024x725.jpg";s:5:"width";i:1024;s:6:"height";i:725;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:28663;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"Shirt-2-back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2867;}s:12:"medium_large";a:5:{s:4:"file";s:24:"Shirt-2-back-768x544.jpg";s:5:"width";i:768;s:6:"height";i:544;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17018;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"Shirt-2-back-1536x1088.jpg";s:5:"width";i:1536;s:6:"height";i:1088;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:68889;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:24:"Shirt-2-back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6761;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:24:"Shirt-2-back-600x425.jpg";s:5:"width";i:600;s:6:"height";i:425;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11567;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:24:"Shirt-2-back-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1937;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:22:"Shirt-2-back-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1024;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:24:"Shirt-2-back-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1937;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(953, 74, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Shirt-2---back.jpg'),
(954, 38, '_et_pb_post_hide_nav', 'default'),
(955, 38, '_et_pb_page_layout', 'et_right_sidebar'),
(956, 38, '_et_pb_side_nav', 'off'),
(957, 38, '_et_pb_use_builder', ''),
(958, 38, '_et_pb_first_image', ''),
(959, 38, '_et_pb_truncate_post', ''),
(960, 38, '_et_pb_truncate_post_date', ''),
(961, 38, '_et_pb_old_content', ''),
(962, 38, '_product_image_gallery', '74'),
(963, 39, '_et_pb_post_hide_nav', ''),
(964, 39, '_et_pb_page_layout', ''),
(965, 39, '_et_pb_side_nav', ''),
(966, 39, '_et_pb_use_builder', ''),
(967, 39, '_et_pb_first_image', ''),
(968, 39, '_et_pb_truncate_post', ''),
(969, 39, '_et_pb_truncate_post_date', ''),
(970, 39, '_et_pb_old_content', ''),
(971, 39, '_wp_old_slug', 'import-placeholder-for-106'),
(972, 39, '_variation_description', ''),
(973, 39, '_regular_price', '14.99'),
(974, 39, '_sale_price', '12.99'),
(975, 39, '_thumbnail_id', '0'),
(976, 39, 'attribute_pa_size', 'large'),
(977, 39, '_price', '12.99'),
(978, 40, '_et_pb_post_hide_nav', ''),
(979, 40, '_et_pb_page_layout', ''),
(980, 40, '_et_pb_side_nav', ''),
(981, 40, '_et_pb_use_builder', ''),
(982, 40, '_et_pb_first_image', ''),
(983, 40, '_et_pb_truncate_post', ''),
(984, 40, '_et_pb_truncate_post_date', ''),
(985, 40, '_et_pb_old_content', ''),
(986, 40, '_wp_old_slug', 'import-placeholder-for-107'),
(987, 40, '_variation_description', ''),
(988, 40, '_regular_price', '14.99'),
(989, 40, '_sale_price', '12.99'),
(990, 40, '_thumbnail_id', '0'),
(991, 40, 'attribute_pa_size', 'medium'),
(992, 40, '_price', '12.99'),
(993, 41, '_et_pb_post_hide_nav', ''),
(994, 41, '_et_pb_page_layout', ''),
(995, 41, '_et_pb_side_nav', ''),
(996, 41, '_et_pb_use_builder', ''),
(997, 41, '_et_pb_first_image', ''),
(998, 41, '_et_pb_truncate_post', ''),
(999, 41, '_et_pb_truncate_post_date', ''),
(1000, 41, '_et_pb_old_content', ''),
(1001, 41, '_wp_old_slug', 'import-placeholder-for-108'),
(1002, 41, '_variation_description', ''),
(1003, 41, '_regular_price', '14.99'),
(1004, 41, '_sale_price', '12.99'),
(1005, 41, '_thumbnail_id', '0'),
(1006, 41, 'attribute_pa_size', 'small'),
(1007, 41, '_price', '12.99'),
(1008, 75, '_wp_attached_file', '2024/03/Shirt-1-front.jpg'),
(1009, 75, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1360;s:4:"file";s:25:"2024/03/Shirt-1-front.jpg";s:8:"filesize";i:142544;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:25:"Shirt-1-front-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5309;}s:5:"large";a:5:{s:4:"file";s:26:"Shirt-1-front-1024x725.jpg";s:5:"width";i:1024;s:6:"height";i:725;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:32151;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"Shirt-1-front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3317;}s:12:"medium_large";a:5:{s:4:"file";s:25:"Shirt-1-front-768x544.jpg";s:5:"width";i:768;s:6:"height";i:544;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19562;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"Shirt-1-front-1536x1088.jpg";s:5:"width";i:1536;s:6:"height";i:1088;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:73558;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:25:"Shirt-1-front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8009;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:25:"Shirt-1-front-600x425.jpg";s:5:"width";i:600;s:6:"height";i:425;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13538;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:25:"Shirt-1-front-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2068;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:23:"Shirt-1-front-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1042;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:25:"Shirt-1-front-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2068;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1010, 75, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Shirt-1---front.jpg'),
(1011, 42, '_wp_old_slug', 'import-placeholder-for-111'),
(1012, 42, '_default_attributes', 'a:1:{s:7:"pa_size";s:5:"large";}'),
(1013, 42, '_thumbnail_id', '75'),
(1014, 42, '_product_attributes', 'a:2:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(1015, 76, '_wp_attached_file', '2024/03/Shirt-1-back.jpg'),
(1016, 76, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1360;s:4:"file";s:24:"2024/03/Shirt-1-back.jpg";s:8:"filesize";i:141417;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:24:"Shirt-1-back-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5034;}s:5:"large";a:5:{s:4:"file";s:25:"Shirt-1-back-1024x725.jpg";s:5:"width";i:1024;s:6:"height";i:725;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:31190;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"Shirt-1-back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3216;}s:12:"medium_large";a:5:{s:4:"file";s:24:"Shirt-1-back-768x544.jpg";s:5:"width";i:768;s:6:"height";i:544;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18875;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"Shirt-1-back-1536x1088.jpg";s:5:"width";i:1536;s:6:"height";i:1088;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:72008;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:24:"Shirt-1-back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7647;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:24:"Shirt-1-back-600x425.jpg";s:5:"width";i:600;s:6:"height";i:425;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13055;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:24:"Shirt-1-back-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2044;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:22:"Shirt-1-back-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1048;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:24:"Shirt-1-back-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2044;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1017, 76, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Shirt-1---back.jpg'),
(1018, 42, '_et_pb_post_hide_nav', 'default'),
(1019, 42, '_et_pb_page_layout', 'et_right_sidebar'),
(1020, 42, '_et_pb_side_nav', 'off'),
(1021, 42, '_et_pb_use_builder', ''),
(1022, 42, '_et_pb_first_image', ''),
(1023, 42, '_et_pb_truncate_post', ''),
(1024, 42, '_et_pb_truncate_post_date', ''),
(1025, 42, '_et_pb_old_content', ''),
(1026, 42, '_product_image_gallery', '76'),
(1027, 43, '_et_pb_post_hide_nav', ''),
(1028, 43, '_et_pb_page_layout', ''),
(1029, 43, '_et_pb_side_nav', ''),
(1030, 43, '_et_pb_use_builder', ''),
(1031, 43, '_et_pb_first_image', ''),
(1032, 43, '_et_pb_truncate_post', ''),
(1033, 43, '_et_pb_truncate_post_date', ''),
(1034, 43, '_et_pb_old_content', ''),
(1035, 43, '_wp_old_slug', 'import-placeholder-for-112'),
(1036, 43, '_variation_description', ''),
(1037, 43, '_regular_price', '14.99'),
(1038, 43, '_sale_price', '12.99'),
(1039, 43, '_thumbnail_id', '0'),
(1040, 43, 'attribute_pa_size', 'large'),
(1041, 43, '_price', '12.99'),
(1042, 44, '_et_pb_post_hide_nav', ''),
(1043, 44, '_et_pb_page_layout', ''),
(1044, 44, '_et_pb_side_nav', ''),
(1045, 44, '_et_pb_use_builder', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1046, 44, '_et_pb_first_image', ''),
(1047, 44, '_et_pb_truncate_post', ''),
(1048, 44, '_et_pb_truncate_post_date', ''),
(1049, 44, '_et_pb_old_content', ''),
(1050, 44, '_wp_old_slug', 'import-placeholder-for-113'),
(1051, 44, '_variation_description', ''),
(1052, 44, '_regular_price', '14.99'),
(1053, 44, '_sale_price', '12.99'),
(1054, 44, '_thumbnail_id', '0'),
(1055, 44, 'attribute_pa_size', 'medium'),
(1056, 44, '_price', '12.99'),
(1057, 45, '_et_pb_post_hide_nav', ''),
(1058, 45, '_et_pb_page_layout', ''),
(1059, 45, '_et_pb_side_nav', ''),
(1060, 45, '_et_pb_use_builder', ''),
(1061, 45, '_et_pb_first_image', ''),
(1062, 45, '_et_pb_truncate_post', ''),
(1063, 45, '_et_pb_truncate_post_date', ''),
(1064, 45, '_et_pb_old_content', ''),
(1065, 45, '_wp_old_slug', 'import-placeholder-for-114'),
(1066, 45, '_variation_description', ''),
(1067, 45, '_regular_price', '14.99'),
(1068, 45, '_sale_price', '12.99'),
(1069, 45, '_thumbnail_id', '0'),
(1070, 45, 'attribute_pa_size', 'small'),
(1071, 45, '_price', '12.99'),
(1072, 77, '_wp_attached_file', '2024/03/Hoodie-2.jpg'),
(1073, 77, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1360;s:4:"file";s:20:"2024/03/Hoodie-2.jpg";s:8:"filesize";i:153642;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:20:"Hoodie-2-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5541;}s:5:"large";a:5:{s:4:"file";s:21:"Hoodie-2-1024x725.jpg";s:5:"width";i:1024;s:6:"height";i:725;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:34197;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"Hoodie-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3304;}s:12:"medium_large";a:5:{s:4:"file";s:20:"Hoodie-2-768x544.jpg";s:5:"width";i:768;s:6:"height";i:544;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20943;}s:9:"1536x1536";a:5:{s:4:"file";s:22:"Hoodie-2-1536x1088.jpg";s:5:"width";i:1536;s:6:"height";i:1088;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:75544;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:20:"Hoodie-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8374;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:20:"Hoodie-2-600x425.jpg";s:5:"width";i:600;s:6:"height";i:425;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14515;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:20:"Hoodie-2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2069;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:18:"Hoodie-2-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1013;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:20:"Hoodie-2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2069;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1074, 77, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Hoodie-2.jpg'),
(1075, 46, '_wp_old_slug', 'import-placeholder-for-117'),
(1076, 46, '_default_attributes', 'a:1:{s:7:"pa_size";s:5:"large";}'),
(1077, 46, '_thumbnail_id', '77'),
(1078, 46, '_product_attributes', 'a:2:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(1079, 46, '_et_pb_post_hide_nav', 'default'),
(1080, 46, '_et_pb_page_layout', 'et_right_sidebar'),
(1081, 46, '_et_pb_side_nav', 'off'),
(1082, 46, '_et_pb_use_builder', ''),
(1083, 46, '_et_pb_first_image', ''),
(1084, 46, '_et_pb_truncate_post', ''),
(1085, 46, '_et_pb_truncate_post_date', ''),
(1086, 46, '_et_pb_old_content', ''),
(1087, 47, '_et_pb_post_hide_nav', ''),
(1088, 47, '_et_pb_page_layout', ''),
(1089, 47, '_et_pb_side_nav', ''),
(1090, 47, '_et_pb_use_builder', ''),
(1091, 47, '_et_pb_first_image', ''),
(1092, 47, '_et_pb_truncate_post', ''),
(1093, 47, '_et_pb_truncate_post_date', ''),
(1094, 47, '_et_pb_old_content', ''),
(1095, 47, '_wp_old_slug', 'import-placeholder-for-119'),
(1096, 47, '_variation_description', ''),
(1097, 47, '_regular_price', '39.99'),
(1098, 47, '_thumbnail_id', '0'),
(1099, 47, 'attribute_pa_size', 'large'),
(1100, 47, '_price', '39.99'),
(1101, 48, '_et_pb_post_hide_nav', ''),
(1102, 48, '_et_pb_page_layout', ''),
(1103, 48, '_et_pb_side_nav', ''),
(1104, 48, '_et_pb_use_builder', ''),
(1105, 48, '_et_pb_first_image', ''),
(1106, 48, '_et_pb_truncate_post', ''),
(1107, 48, '_et_pb_truncate_post_date', ''),
(1108, 48, '_et_pb_old_content', ''),
(1109, 48, '_wp_old_slug', 'import-placeholder-for-120'),
(1110, 48, '_variation_description', ''),
(1111, 48, '_regular_price', '34.99'),
(1112, 48, '_thumbnail_id', '0'),
(1113, 48, 'attribute_pa_size', 'medium'),
(1114, 48, '_price', '34.99'),
(1115, 49, '_et_pb_post_hide_nav', ''),
(1116, 49, '_et_pb_page_layout', ''),
(1117, 49, '_et_pb_side_nav', ''),
(1118, 49, '_et_pb_use_builder', ''),
(1119, 49, '_et_pb_first_image', ''),
(1120, 49, '_et_pb_truncate_post', ''),
(1121, 49, '_et_pb_truncate_post_date', ''),
(1122, 49, '_et_pb_old_content', ''),
(1123, 49, '_wp_old_slug', 'import-placeholder-for-121'),
(1124, 49, '_variation_description', ''),
(1125, 49, '_regular_price', '34.99'),
(1126, 49, '_thumbnail_id', '0'),
(1127, 49, 'attribute_pa_size', 'small'),
(1128, 49, '_price', '34.99'),
(1129, 78, '_wp_attached_file', '2024/03/Hoodie-1.jpg'),
(1130, 78, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1360;s:4:"file";s:20:"2024/03/Hoodie-1.jpg";s:8:"filesize";i:180095;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:20:"Hoodie-1-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6104;}s:5:"large";a:5:{s:4:"file";s:21:"Hoodie-1-1024x725.jpg";s:5:"width";i:1024;s:6:"height";i:725;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:38476;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"Hoodie-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3597;}s:12:"medium_large";a:5:{s:4:"file";s:20:"Hoodie-1-768x544.jpg";s:5:"width";i:768;s:6:"height";i:544;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:23321;}s:9:"1536x1536";a:5:{s:4:"file";s:22:"Hoodie-1-1536x1088.jpg";s:5:"width";i:1536;s:6:"height";i:1088;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:88343;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:20:"Hoodie-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9449;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:20:"Hoodie-1-600x425.jpg";s:5:"width";i:600;s:6:"height";i:425;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16117;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:20:"Hoodie-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2187;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:18:"Hoodie-1-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1021;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:20:"Hoodie-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2187;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1131, 78, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Hoodie-1.jpg'),
(1132, 64, '_wp_old_slug', 'import-placeholder-for-122'),
(1133, 64, '_default_attributes', 'a:1:{s:7:"pa_size";s:5:"large";}'),
(1134, 64, '_thumbnail_id', '78'),
(1135, 64, '_product_attributes', 'a:2:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(1136, 64, '_et_pb_post_hide_nav', 'default'),
(1137, 64, '_et_pb_page_layout', 'et_right_sidebar'),
(1138, 64, '_et_pb_side_nav', 'off'),
(1139, 64, '_et_pb_use_builder', ''),
(1140, 64, '_et_pb_first_image', ''),
(1141, 64, '_et_pb_truncate_post', ''),
(1142, 64, '_et_pb_truncate_post_date', ''),
(1143, 64, '_et_pb_old_content', ''),
(1144, 65, '_et_pb_post_hide_nav', ''),
(1145, 65, '_et_pb_page_layout', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1146, 65, '_et_pb_side_nav', ''),
(1147, 65, '_et_pb_use_builder', ''),
(1148, 65, '_et_pb_first_image', ''),
(1149, 65, '_et_pb_truncate_post', ''),
(1150, 65, '_et_pb_truncate_post_date', ''),
(1151, 65, '_et_pb_old_content', ''),
(1152, 65, '_wp_old_slug', 'import-placeholder-for-123'),
(1153, 65, '_variation_description', ''),
(1154, 65, '_regular_price', '44.99'),
(1155, 65, '_thumbnail_id', '0'),
(1156, 65, 'attribute_pa_size', 'large'),
(1157, 65, '_price', '44.99'),
(1158, 66, '_et_pb_post_hide_nav', ''),
(1159, 66, '_et_pb_page_layout', ''),
(1160, 66, '_et_pb_side_nav', ''),
(1161, 66, '_et_pb_use_builder', ''),
(1162, 66, '_et_pb_first_image', ''),
(1163, 66, '_et_pb_truncate_post', ''),
(1164, 66, '_et_pb_truncate_post_date', ''),
(1165, 66, '_et_pb_old_content', ''),
(1166, 66, '_wp_old_slug', 'import-placeholder-for-124'),
(1167, 66, '_variation_description', ''),
(1168, 66, '_regular_price', '44.99'),
(1169, 66, '_low_stock_amount', '10'),
(1170, 66, '_thumbnail_id', '0'),
(1171, 66, 'attribute_pa_size', 'medium'),
(1172, 66, '_price', '44.99'),
(1173, 67, '_et_pb_post_hide_nav', ''),
(1174, 67, '_et_pb_page_layout', ''),
(1175, 67, '_et_pb_side_nav', ''),
(1176, 67, '_et_pb_use_builder', ''),
(1177, 67, '_et_pb_first_image', ''),
(1178, 67, '_et_pb_truncate_post', ''),
(1179, 67, '_et_pb_truncate_post_date', ''),
(1180, 67, '_et_pb_old_content', ''),
(1181, 67, '_wp_old_slug', 'import-placeholder-for-125'),
(1182, 67, '_variation_description', ''),
(1183, 67, '_regular_price', '44.99'),
(1184, 67, '_thumbnail_id', '0'),
(1185, 67, 'attribute_pa_size', 'small'),
(1186, 67, '_price', '44.99'),
(1187, 79, '_wp_attached_file', '2024/03/Hoodie-3.jpg'),
(1188, 79, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1360;s:4:"file";s:20:"2024/03/Hoodie-3.jpg";s:8:"filesize";i:170800;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:20:"Hoodie-3-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5430;}s:5:"large";a:5:{s:4:"file";s:21:"Hoodie-3-1024x725.jpg";s:5:"width";i:1024;s:6:"height";i:725;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:34797;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"Hoodie-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3250;}s:12:"medium_large";a:5:{s:4:"file";s:20:"Hoodie-3-768x544.jpg";s:5:"width";i:768;s:6:"height";i:544;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20846;}s:9:"1536x1536";a:5:{s:4:"file";s:22:"Hoodie-3-1536x1088.jpg";s:5:"width";i:1536;s:6:"height";i:1088;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:81856;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:20:"Hoodie-3-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8306;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:20:"Hoodie-3-600x425.jpg";s:5:"width";i:600;s:6:"height";i:425;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14341;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:20:"Hoodie-3-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2035;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:18:"Hoodie-3-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:973;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:20:"Hoodie-3-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2035;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1189, 79, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Hoodie-3.jpg'),
(1190, 68, '_wp_old_slug', 'import-placeholder-for-127'),
(1191, 68, '_default_attributes', 'a:1:{s:7:"pa_size";s:5:"large";}'),
(1192, 68, '_thumbnail_id', '79'),
(1193, 68, '_product_attributes', 'a:2:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(1194, 68, '_et_pb_post_hide_nav', 'default'),
(1195, 68, '_et_pb_page_layout', 'et_right_sidebar'),
(1196, 68, '_et_pb_side_nav', 'off'),
(1197, 68, '_et_pb_use_builder', ''),
(1198, 68, '_et_pb_first_image', ''),
(1199, 68, '_et_pb_truncate_post', ''),
(1200, 68, '_et_pb_truncate_post_date', ''),
(1201, 68, '_et_pb_old_content', ''),
(1202, 69, '_et_pb_post_hide_nav', ''),
(1203, 69, '_et_pb_page_layout', ''),
(1204, 69, '_et_pb_side_nav', ''),
(1205, 69, '_et_pb_use_builder', ''),
(1206, 69, '_et_pb_first_image', ''),
(1207, 69, '_et_pb_truncate_post', ''),
(1208, 69, '_et_pb_truncate_post_date', ''),
(1209, 69, '_et_pb_old_content', ''),
(1210, 69, '_wp_old_slug', 'import-placeholder-for-128'),
(1211, 69, '_variation_description', ''),
(1212, 69, '_regular_price', '34.99'),
(1213, 69, '_thumbnail_id', '0'),
(1214, 69, 'attribute_pa_size', 'large'),
(1215, 69, '_price', '34.99'),
(1216, 70, '_et_pb_post_hide_nav', ''),
(1217, 70, '_et_pb_page_layout', ''),
(1218, 70, '_et_pb_side_nav', ''),
(1219, 70, '_et_pb_use_builder', ''),
(1220, 70, '_et_pb_first_image', ''),
(1221, 70, '_et_pb_truncate_post', ''),
(1222, 70, '_et_pb_truncate_post_date', ''),
(1223, 70, '_et_pb_old_content', ''),
(1224, 70, '_wp_old_slug', 'import-placeholder-for-129'),
(1225, 70, '_variation_description', ''),
(1226, 70, '_regular_price', '34.99'),
(1227, 70, '_thumbnail_id', '0'),
(1228, 70, 'attribute_pa_size', 'medium'),
(1229, 70, '_price', '34.99'),
(1230, 71, '_et_pb_post_hide_nav', ''),
(1231, 71, '_et_pb_page_layout', ''),
(1232, 71, '_et_pb_side_nav', ''),
(1233, 71, '_et_pb_use_builder', ''),
(1234, 71, '_et_pb_first_image', ''),
(1235, 71, '_et_pb_truncate_post', ''),
(1236, 71, '_et_pb_truncate_post_date', ''),
(1237, 71, '_et_pb_old_content', ''),
(1238, 71, '_wp_old_slug', 'import-placeholder-for-130'),
(1239, 71, '_variation_description', ''),
(1240, 71, '_regular_price', '34.99'),
(1241, 71, '_thumbnail_id', '0'),
(1242, 71, 'attribute_pa_size', 'small'),
(1243, 71, '_price', '34.99'),
(1244, 80, '_wp_attached_file', '2024/03/Hoodie-Women-1.jpg'),
(1245, 80, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1360;s:4:"file";s:26:"2024/03/Hoodie-Women-1.jpg";s:8:"filesize";i:197236;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:26:"Hoodie-Women-1-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9061;}s:5:"large";a:5:{s:4:"file";s:27:"Hoodie-Women-1-1024x725.jpg";s:5:"width";i:1024;s:6:"height";i:725;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:54943;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"Hoodie-Women-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5331;}s:12:"medium_large";a:5:{s:4:"file";s:26:"Hoodie-Women-1-768x544.jpg";s:5:"width";i:768;s:6:"height";i:544;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:35295;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"Hoodie-Women-1-1536x1088.jpg";s:5:"width";i:1536;s:6:"height";i:1088;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:109795;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:26:"Hoodie-Women-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14627;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:26:"Hoodie-Women-1-600x425.jpg";s:5:"width";i:600;s:6:"height";i:425;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:24863;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:26:"Hoodie-Women-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2868;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:24:"Hoodie-Women-1-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1175;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:26:"Hoodie-Women-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2868;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1246, 80, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Hoodie-Women-1.jpg'),
(1247, 72, '_wp_old_slug', 'import-placeholder-for-132'),
(1248, 72, '_default_attributes', 'a:1:{s:7:"pa_size";s:6:"medium";}'),
(1249, 72, '_thumbnail_id', '80'),
(1250, 72, '_product_attributes', 'a:2:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(1251, 72, '_et_pb_post_hide_nav', 'default'),
(1252, 72, '_et_pb_page_layout', 'et_right_sidebar'),
(1253, 72, '_et_pb_side_nav', 'off'),
(1254, 72, '_et_pb_use_builder', ''),
(1255, 72, '_et_pb_first_image', ''),
(1256, 72, '_et_pb_truncate_post', ''),
(1257, 72, '_et_pb_truncate_post_date', ''),
(1258, 72, '_et_pb_old_content', ''),
(1259, 28, '_price', '14.99'),
(1260, 38, '_price', '12.99'),
(1261, 42, '_price', '12.99'),
(1262, 46, '_price', '34.99'),
(1263, 46, '_price', '39.99'),
(1264, 64, '_price', '44.99'),
(1265, 68, '_price', '34.99'),
(1266, 81, 'total_sales', '0'),
(1267, 81, '_tax_status', 'taxable'),
(1268, 81, '_tax_class', 'parent'),
(1269, 81, '_manage_stock', 'no'),
(1270, 81, '_backorders', 'no'),
(1271, 81, '_sold_individually', 'no'),
(1272, 81, '_virtual', 'no'),
(1273, 81, '_downloadable', 'no'),
(1274, 81, '_download_limit', '0'),
(1275, 81, '_download_expiry', '0'),
(1276, 81, '_stock', NULL),
(1277, 81, '_stock_status', 'instock'),
(1278, 81, '_wc_average_rating', '0'),
(1279, 81, '_wc_review_count', '0'),
(1280, 81, '_product_version', '8.6.1'),
(1282, 82, 'total_sales', '0'),
(1283, 82, '_tax_status', 'taxable'),
(1284, 82, '_tax_class', 'parent'),
(1285, 82, '_manage_stock', 'no'),
(1286, 82, '_backorders', 'no'),
(1287, 82, '_sold_individually', 'no'),
(1288, 82, '_virtual', 'no'),
(1289, 82, '_downloadable', 'no'),
(1290, 82, '_download_limit', '0'),
(1291, 82, '_download_expiry', '0'),
(1292, 82, '_stock', NULL),
(1293, 82, '_stock_status', 'instock'),
(1294, 82, '_wc_average_rating', '0'),
(1295, 82, '_wc_review_count', '0'),
(1296, 82, '_product_version', '8.6.1'),
(1298, 83, 'total_sales', '0'),
(1299, 83, '_tax_status', 'taxable'),
(1300, 83, '_tax_class', 'parent'),
(1301, 83, '_manage_stock', 'no'),
(1302, 83, '_backorders', 'no'),
(1303, 83, '_sold_individually', 'no'),
(1304, 83, '_virtual', 'no'),
(1305, 83, '_downloadable', 'no'),
(1306, 83, '_download_limit', '0'),
(1307, 83, '_download_expiry', '0'),
(1308, 83, '_stock', NULL),
(1309, 83, '_stock_status', 'instock'),
(1310, 83, '_wc_average_rating', '0'),
(1311, 83, '_wc_review_count', '0'),
(1312, 83, '_product_version', '8.6.1'),
(1314, 84, 'total_sales', '0'),
(1315, 84, '_tax_status', 'taxable'),
(1316, 84, '_tax_class', ''),
(1317, 84, '_manage_stock', 'no'),
(1318, 84, '_backorders', 'no'),
(1319, 84, '_sold_individually', 'no'),
(1320, 84, '_virtual', 'no'),
(1321, 84, '_downloadable', 'no'),
(1322, 84, '_download_limit', '0'),
(1323, 84, '_download_expiry', '0'),
(1324, 84, '_stock', NULL),
(1325, 84, '_stock_status', 'instock'),
(1326, 84, '_wc_average_rating', '0'),
(1327, 84, '_wc_review_count', '0'),
(1328, 84, '_product_version', '8.6.1'),
(1330, 85, 'total_sales', '0'),
(1331, 85, '_tax_status', 'taxable'),
(1332, 85, '_tax_class', 'parent'),
(1333, 85, '_manage_stock', 'no'),
(1334, 85, '_backorders', 'no'),
(1335, 85, '_sold_individually', 'no'),
(1336, 85, '_virtual', 'no'),
(1337, 85, '_downloadable', 'no'),
(1338, 85, '_download_limit', '0'),
(1339, 85, '_download_expiry', '0'),
(1340, 85, '_stock', NULL),
(1341, 85, '_stock_status', 'instock'),
(1342, 85, '_wc_average_rating', '0'),
(1343, 85, '_wc_review_count', '0'),
(1344, 85, '_product_version', '8.6.1'),
(1346, 86, 'total_sales', '0'),
(1347, 86, '_tax_status', 'taxable'),
(1348, 86, '_tax_class', 'parent'),
(1349, 86, '_manage_stock', 'no'),
(1350, 86, '_backorders', 'no') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1351, 86, '_sold_individually', 'no'),
(1352, 86, '_virtual', 'no'),
(1353, 86, '_downloadable', 'no'),
(1354, 86, '_download_limit', '0'),
(1355, 86, '_download_expiry', '0'),
(1356, 86, '_stock', NULL),
(1357, 86, '_stock_status', 'instock'),
(1358, 86, '_wc_average_rating', '0'),
(1359, 86, '_wc_review_count', '0'),
(1360, 86, '_product_version', '8.6.1'),
(1362, 87, 'total_sales', '0'),
(1363, 87, '_tax_status', 'taxable'),
(1364, 87, '_tax_class', 'parent'),
(1365, 87, '_manage_stock', 'no'),
(1366, 87, '_backorders', 'no'),
(1367, 87, '_sold_individually', 'no'),
(1368, 87, '_virtual', 'no'),
(1369, 87, '_downloadable', 'no'),
(1370, 87, '_download_limit', '0'),
(1371, 87, '_download_expiry', '0'),
(1372, 87, '_stock', NULL),
(1373, 87, '_stock_status', 'instock'),
(1374, 87, '_wc_average_rating', '0'),
(1375, 87, '_wc_review_count', '0'),
(1376, 87, '_product_version', '8.6.1'),
(1378, 88, 'total_sales', '0'),
(1379, 88, '_tax_status', 'taxable'),
(1380, 88, '_tax_class', ''),
(1381, 88, '_manage_stock', 'no'),
(1382, 88, '_backorders', 'no'),
(1383, 88, '_sold_individually', 'no'),
(1384, 88, '_virtual', 'no'),
(1385, 88, '_downloadable', 'no'),
(1386, 88, '_download_limit', '0'),
(1387, 88, '_download_expiry', '0'),
(1388, 88, '_stock', NULL),
(1389, 88, '_stock_status', 'instock'),
(1390, 88, '_wc_average_rating', '0'),
(1391, 88, '_wc_review_count', '0'),
(1392, 88, '_product_version', '8.6.1'),
(1394, 89, 'total_sales', '0'),
(1395, 89, '_tax_status', 'taxable'),
(1396, 89, '_tax_class', 'parent'),
(1397, 89, '_manage_stock', 'no'),
(1398, 89, '_backorders', 'no'),
(1399, 89, '_sold_individually', 'no'),
(1400, 89, '_virtual', 'no'),
(1401, 89, '_downloadable', 'no'),
(1402, 89, '_download_limit', '0'),
(1403, 89, '_download_expiry', '0'),
(1404, 89, '_stock', NULL),
(1405, 89, '_stock_status', 'instock'),
(1406, 89, '_wc_average_rating', '0'),
(1407, 89, '_wc_review_count', '0'),
(1408, 89, '_product_version', '8.6.1'),
(1410, 90, 'total_sales', '0'),
(1411, 90, '_tax_status', 'taxable'),
(1412, 90, '_tax_class', 'parent'),
(1413, 90, '_manage_stock', 'no'),
(1414, 90, '_backorders', 'no'),
(1415, 90, '_sold_individually', 'no'),
(1416, 90, '_virtual', 'no'),
(1417, 90, '_downloadable', 'no'),
(1418, 90, '_download_limit', '0'),
(1419, 90, '_download_expiry', '0'),
(1420, 90, '_stock', NULL),
(1421, 90, '_stock_status', 'instock'),
(1422, 90, '_wc_average_rating', '0'),
(1423, 90, '_wc_review_count', '0'),
(1424, 90, '_product_version', '8.6.1'),
(1426, 91, 'total_sales', '0'),
(1427, 91, '_tax_status', 'taxable'),
(1428, 91, '_tax_class', 'parent'),
(1429, 91, '_manage_stock', 'no'),
(1430, 91, '_backorders', 'no'),
(1431, 91, '_sold_individually', 'no'),
(1432, 91, '_virtual', 'no'),
(1433, 91, '_downloadable', 'no'),
(1434, 91, '_download_limit', '0'),
(1435, 91, '_download_expiry', '0'),
(1436, 91, '_stock', NULL),
(1437, 91, '_stock_status', 'instock'),
(1438, 91, '_wc_average_rating', '0'),
(1439, 91, '_wc_review_count', '0'),
(1440, 91, '_product_version', '8.6.1'),
(1442, 92, 'total_sales', '0'),
(1443, 92, '_tax_status', 'taxable'),
(1444, 92, '_tax_class', ''),
(1445, 92, '_manage_stock', 'no'),
(1446, 92, '_backorders', 'no'),
(1447, 92, '_sold_individually', 'no'),
(1448, 92, '_virtual', 'no'),
(1449, 92, '_downloadable', 'no'),
(1450, 92, '_download_limit', '0'),
(1451, 92, '_download_expiry', '0'),
(1452, 92, '_stock', NULL),
(1453, 92, '_stock_status', 'onbackorder'),
(1454, 92, '_wc_average_rating', '0'),
(1455, 92, '_wc_review_count', '0'),
(1456, 92, '_product_version', '8.6.1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1458, 93, 'total_sales', '0'),
(1459, 93, '_tax_status', 'taxable'),
(1460, 93, '_tax_class', 'parent'),
(1461, 93, '_manage_stock', 'no'),
(1462, 93, '_backorders', 'no'),
(1463, 93, '_sold_individually', 'no'),
(1464, 93, '_virtual', 'no'),
(1465, 93, '_downloadable', 'no'),
(1466, 93, '_download_limit', '0'),
(1467, 93, '_download_expiry', '0'),
(1468, 93, '_stock', NULL),
(1469, 93, '_stock_status', 'onbackorder'),
(1470, 93, '_wc_average_rating', '0'),
(1471, 93, '_wc_review_count', '0'),
(1472, 93, '_product_version', '8.6.1'),
(1474, 94, 'total_sales', '0'),
(1475, 94, '_tax_status', 'taxable'),
(1476, 94, '_tax_class', 'parent'),
(1477, 94, '_manage_stock', 'no'),
(1478, 94, '_backorders', 'no'),
(1479, 94, '_sold_individually', 'no'),
(1480, 94, '_virtual', 'no'),
(1481, 94, '_downloadable', 'no'),
(1482, 94, '_download_limit', '0'),
(1483, 94, '_download_expiry', '0'),
(1484, 94, '_stock', NULL),
(1485, 94, '_stock_status', 'onbackorder'),
(1486, 94, '_wc_average_rating', '0'),
(1487, 94, '_wc_review_count', '0'),
(1488, 94, '_product_version', '8.6.1'),
(1490, 95, 'total_sales', '0'),
(1491, 95, '_tax_status', 'taxable'),
(1492, 95, '_tax_class', 'parent'),
(1493, 95, '_manage_stock', 'no'),
(1494, 95, '_backorders', 'no'),
(1495, 95, '_sold_individually', 'no'),
(1496, 95, '_virtual', 'no'),
(1497, 95, '_downloadable', 'no'),
(1498, 95, '_download_limit', '0'),
(1499, 95, '_download_expiry', '0'),
(1500, 95, '_stock', NULL),
(1501, 95, '_stock_status', 'onbackorder'),
(1502, 95, '_wc_average_rating', '0'),
(1503, 95, '_wc_review_count', '0'),
(1504, 95, '_product_version', '8.6.1'),
(1506, 96, 'total_sales', '0'),
(1507, 96, '_tax_status', 'taxable'),
(1508, 96, '_tax_class', ''),
(1509, 96, '_manage_stock', 'no'),
(1510, 96, '_backorders', 'no'),
(1511, 96, '_sold_individually', 'no'),
(1512, 96, '_virtual', 'no'),
(1513, 96, '_downloadable', 'no'),
(1514, 96, '_download_limit', '0'),
(1515, 96, '_download_expiry', '0'),
(1516, 96, '_stock', NULL),
(1517, 96, '_stock_status', 'instock'),
(1518, 96, '_wc_average_rating', '0'),
(1519, 96, '_wc_review_count', '0'),
(1520, 96, '_product_version', '8.6.1'),
(1522, 97, 'total_sales', '0'),
(1523, 97, '_tax_status', 'taxable'),
(1524, 97, '_tax_class', ''),
(1525, 97, '_manage_stock', 'no'),
(1526, 97, '_backorders', 'no'),
(1527, 97, '_sold_individually', 'no'),
(1528, 97, '_virtual', 'no'),
(1529, 97, '_downloadable', 'no'),
(1530, 97, '_download_limit', '0'),
(1531, 97, '_download_expiry', '0'),
(1532, 97, '_stock', NULL),
(1533, 97, '_stock_status', 'instock'),
(1534, 97, '_wc_average_rating', '0'),
(1535, 97, '_wc_review_count', '0'),
(1536, 97, '_product_version', '8.6.1'),
(1538, 98, 'total_sales', '0'),
(1539, 98, '_tax_status', 'taxable'),
(1540, 98, '_tax_class', 'parent'),
(1541, 98, '_manage_stock', 'no'),
(1542, 98, '_backorders', 'no'),
(1543, 98, '_sold_individually', 'no'),
(1544, 98, '_virtual', 'no'),
(1545, 98, '_downloadable', 'no'),
(1546, 98, '_download_limit', '0'),
(1547, 98, '_download_expiry', '0'),
(1548, 98, '_stock', NULL),
(1549, 98, '_stock_status', 'instock'),
(1550, 98, '_wc_average_rating', '0'),
(1551, 98, '_wc_review_count', '0'),
(1552, 98, '_product_version', '8.6.1'),
(1554, 99, 'total_sales', '0'),
(1555, 99, '_tax_status', 'taxable'),
(1556, 99, '_tax_class', 'parent'),
(1557, 99, '_manage_stock', 'no'),
(1558, 99, '_backorders', 'no'),
(1559, 99, '_sold_individually', 'no'),
(1560, 99, '_virtual', 'no'),
(1561, 99, '_downloadable', 'no'),
(1562, 99, '_download_limit', '0'),
(1563, 99, '_download_expiry', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1564, 99, '_stock', NULL),
(1565, 99, '_stock_status', 'instock'),
(1566, 99, '_wc_average_rating', '0'),
(1567, 99, '_wc_review_count', '0'),
(1568, 99, '_product_version', '8.6.1'),
(1570, 100, 'total_sales', '0'),
(1571, 100, '_tax_status', 'taxable'),
(1572, 100, '_tax_class', 'parent'),
(1573, 100, '_manage_stock', 'no'),
(1574, 100, '_backorders', 'no'),
(1575, 100, '_sold_individually', 'no'),
(1576, 100, '_virtual', 'no'),
(1577, 100, '_downloadable', 'no'),
(1578, 100, '_download_limit', '0'),
(1579, 100, '_download_expiry', '0'),
(1580, 100, '_stock', NULL),
(1581, 100, '_stock_status', 'instock'),
(1582, 100, '_wc_average_rating', '0'),
(1583, 100, '_wc_review_count', '0'),
(1584, 100, '_product_version', '8.6.1'),
(1586, 101, 'total_sales', '0'),
(1587, 101, '_tax_status', 'taxable'),
(1588, 101, '_tax_class', 'parent'),
(1589, 101, '_manage_stock', 'no'),
(1590, 101, '_backorders', 'no'),
(1591, 101, '_sold_individually', 'no'),
(1592, 101, '_virtual', 'no'),
(1593, 101, '_downloadable', 'no'),
(1594, 101, '_download_limit', '0'),
(1595, 101, '_download_expiry', '0'),
(1596, 101, '_stock', NULL),
(1597, 101, '_stock_status', 'instock'),
(1598, 101, '_wc_average_rating', '0'),
(1599, 101, '_wc_review_count', '0'),
(1600, 101, '_product_version', '8.6.1'),
(1602, 102, 'total_sales', '0'),
(1603, 102, '_tax_status', 'taxable'),
(1604, 102, '_tax_class', 'parent'),
(1605, 102, '_manage_stock', 'no'),
(1606, 102, '_backorders', 'no'),
(1607, 102, '_sold_individually', 'no'),
(1608, 102, '_virtual', 'no'),
(1609, 102, '_downloadable', 'no'),
(1610, 102, '_download_limit', '0'),
(1611, 102, '_download_expiry', '0'),
(1612, 102, '_stock', NULL),
(1613, 102, '_stock_status', 'instock'),
(1614, 102, '_wc_average_rating', '0'),
(1615, 102, '_wc_review_count', '0'),
(1616, 102, '_product_version', '8.6.1'),
(1618, 103, 'total_sales', '0'),
(1619, 103, '_tax_status', 'taxable'),
(1620, 103, '_tax_class', 'parent'),
(1621, 103, '_manage_stock', 'no'),
(1622, 103, '_backorders', 'no'),
(1623, 103, '_sold_individually', 'no'),
(1624, 103, '_virtual', 'no'),
(1625, 103, '_downloadable', 'no'),
(1626, 103, '_download_limit', '0'),
(1627, 103, '_download_expiry', '0'),
(1628, 103, '_stock', NULL),
(1629, 103, '_stock_status', 'instock'),
(1630, 103, '_wc_average_rating', '0'),
(1631, 103, '_wc_review_count', '0'),
(1632, 103, '_product_version', '8.6.1'),
(1634, 104, 'total_sales', '0'),
(1635, 104, '_tax_status', 'taxable'),
(1636, 104, '_tax_class', 'parent'),
(1637, 104, '_manage_stock', 'no'),
(1638, 104, '_backorders', 'no'),
(1639, 104, '_sold_individually', 'no'),
(1640, 104, '_virtual', 'no'),
(1641, 104, '_downloadable', 'no'),
(1642, 104, '_download_limit', '0'),
(1643, 104, '_download_expiry', '0'),
(1644, 104, '_stock', NULL),
(1645, 104, '_stock_status', 'instock'),
(1646, 104, '_wc_average_rating', '0'),
(1647, 104, '_wc_review_count', '0'),
(1648, 104, '_product_version', '8.6.1'),
(1650, 105, 'total_sales', '0'),
(1651, 105, '_tax_status', 'taxable'),
(1652, 105, '_tax_class', 'parent'),
(1653, 105, '_manage_stock', 'no'),
(1654, 105, '_backorders', 'no'),
(1655, 105, '_sold_individually', 'no'),
(1656, 105, '_virtual', 'no'),
(1657, 105, '_downloadable', 'no'),
(1658, 105, '_download_limit', '0'),
(1659, 105, '_download_expiry', '0'),
(1660, 105, '_stock', NULL),
(1661, 105, '_stock_status', 'instock'),
(1662, 105, '_wc_average_rating', '0'),
(1663, 105, '_wc_review_count', '0'),
(1664, 105, '_product_version', '8.6.1'),
(1666, 106, 'total_sales', '0'),
(1667, 106, '_tax_status', 'taxable'),
(1668, 106, '_tax_class', 'parent'),
(1669, 106, '_manage_stock', 'no'),
(1670, 106, '_backorders', 'no') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1671, 106, '_sold_individually', 'no'),
(1672, 106, '_virtual', 'no'),
(1673, 106, '_downloadable', 'no'),
(1674, 106, '_download_limit', '0'),
(1675, 106, '_download_expiry', '0'),
(1676, 106, '_stock', NULL),
(1677, 106, '_stock_status', 'instock'),
(1678, 106, '_wc_average_rating', '0'),
(1679, 106, '_wc_review_count', '0'),
(1680, 106, '_product_version', '8.6.1'),
(1682, 107, 'total_sales', '0'),
(1683, 107, '_tax_status', 'taxable'),
(1684, 107, '_tax_class', 'parent'),
(1685, 107, '_manage_stock', 'no'),
(1686, 107, '_backorders', 'no'),
(1687, 107, '_sold_individually', 'no'),
(1688, 107, '_virtual', 'no'),
(1689, 107, '_downloadable', 'no'),
(1690, 107, '_download_limit', '0'),
(1691, 107, '_download_expiry', '0'),
(1692, 107, '_stock', NULL),
(1693, 107, '_stock_status', 'instock'),
(1694, 107, '_wc_average_rating', '0'),
(1695, 107, '_wc_review_count', '0'),
(1696, 107, '_product_version', '8.6.1'),
(1698, 108, 'total_sales', '0'),
(1699, 108, '_tax_status', 'taxable'),
(1700, 108, '_tax_class', 'parent'),
(1701, 108, '_manage_stock', 'no'),
(1702, 108, '_backorders', 'no'),
(1703, 108, '_sold_individually', 'no'),
(1704, 108, '_virtual', 'no'),
(1705, 108, '_downloadable', 'no'),
(1706, 108, '_download_limit', '0'),
(1707, 108, '_download_expiry', '0'),
(1708, 108, '_stock', NULL),
(1709, 108, '_stock_status', 'instock'),
(1710, 108, '_wc_average_rating', '0'),
(1711, 108, '_wc_review_count', '0'),
(1712, 108, '_product_version', '8.6.1'),
(1714, 109, 'total_sales', '0'),
(1715, 109, '_tax_status', 'taxable'),
(1716, 109, '_tax_class', 'parent'),
(1717, 109, '_manage_stock', 'no'),
(1718, 109, '_backorders', 'no'),
(1719, 109, '_sold_individually', 'no'),
(1720, 109, '_virtual', 'no'),
(1721, 109, '_downloadable', 'no'),
(1722, 109, '_download_limit', '0'),
(1723, 109, '_download_expiry', '0'),
(1724, 109, '_stock', NULL),
(1725, 109, '_stock_status', 'instock'),
(1726, 109, '_wc_average_rating', '0'),
(1727, 109, '_wc_review_count', '0'),
(1728, 109, '_product_version', '8.6.1'),
(1730, 81, '_et_pb_post_hide_nav', ''),
(1731, 81, '_et_pb_page_layout', ''),
(1732, 81, '_et_pb_side_nav', ''),
(1733, 81, '_et_pb_use_builder', ''),
(1734, 81, '_et_pb_first_image', ''),
(1735, 81, '_et_pb_truncate_post', ''),
(1736, 81, '_et_pb_truncate_post_date', ''),
(1737, 81, '_et_pb_old_content', ''),
(1738, 81, '_wp_old_slug', 'import-placeholder-for-133'),
(1739, 81, '_variation_description', ''),
(1740, 81, '_regular_price', '29.99'),
(1741, 81, '_thumbnail_id', '0'),
(1742, 81, 'attribute_pa_size', 'large'),
(1743, 81, '_price', '29.99'),
(1744, 82, '_et_pb_post_hide_nav', ''),
(1745, 82, '_et_pb_page_layout', ''),
(1746, 82, '_et_pb_side_nav', ''),
(1747, 82, '_et_pb_use_builder', ''),
(1748, 82, '_et_pb_first_image', ''),
(1749, 82, '_et_pb_truncate_post', ''),
(1750, 82, '_et_pb_truncate_post_date', ''),
(1751, 82, '_et_pb_old_content', ''),
(1752, 82, '_wp_old_slug', 'import-placeholder-for-134'),
(1753, 82, '_variation_description', ''),
(1754, 82, '_regular_price', '29.99'),
(1755, 82, '_thumbnail_id', '0'),
(1756, 82, 'attribute_pa_size', 'medium'),
(1757, 82, '_price', '29.99'),
(1758, 83, '_et_pb_post_hide_nav', ''),
(1759, 83, '_et_pb_page_layout', ''),
(1760, 83, '_et_pb_side_nav', ''),
(1761, 83, '_et_pb_use_builder', ''),
(1762, 83, '_et_pb_first_image', ''),
(1763, 83, '_et_pb_truncate_post', ''),
(1764, 83, '_et_pb_truncate_post_date', ''),
(1765, 83, '_et_pb_old_content', ''),
(1766, 83, '_wp_old_slug', 'import-placeholder-for-135'),
(1767, 83, '_variation_description', ''),
(1768, 83, '_regular_price', '29.99'),
(1769, 83, '_thumbnail_id', '0'),
(1770, 83, 'attribute_pa_size', 'small'),
(1771, 83, '_price', '29.99'),
(1772, 110, '_wp_attached_file', '2024/03/Hoodie-Women-2.jpg'),
(1773, 110, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1360;s:4:"file";s:26:"2024/03/Hoodie-Women-2.jpg";s:8:"filesize";i:178241;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:26:"Hoodie-Women-2-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6929;}s:5:"large";a:5:{s:4:"file";s:27:"Hoodie-Women-2-1024x725.jpg";s:5:"width";i:1024;s:6:"height";i:725;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:45762;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"Hoodie-Women-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4053;}s:12:"medium_large";a:5:{s:4:"file";s:26:"Hoodie-Women-2-768x544.jpg";s:5:"width";i:768;s:6:"height";i:544;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:28926;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"Hoodie-Women-2-1536x1088.jpg";s:5:"width";i:1536;s:6:"height";i:1088;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:97033;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:26:"Hoodie-Women-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11352;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:26:"Hoodie-Women-2-600x425.jpg";s:5:"width";i:600;s:6:"height";i:425;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19789;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:26:"Hoodie-Women-2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2258;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:24:"Hoodie-Women-2-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1042;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:26:"Hoodie-Women-2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2258;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1774, 110, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Hoodie-Women-2.jpg') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1775, 84, '_wp_old_slug', 'import-placeholder-for-137'),
(1776, 84, '_default_attributes', 'a:1:{s:7:"pa_size";s:6:"medium";}'),
(1777, 84, '_thumbnail_id', '110'),
(1778, 84, '_product_attributes', 'a:2:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(1779, 84, '_et_pb_post_hide_nav', 'default'),
(1780, 84, '_et_pb_page_layout', 'et_right_sidebar'),
(1781, 84, '_et_pb_side_nav', 'off'),
(1782, 84, '_et_pb_use_builder', ''),
(1783, 84, '_et_pb_first_image', ''),
(1784, 84, '_et_pb_truncate_post', ''),
(1785, 84, '_et_pb_truncate_post_date', ''),
(1786, 84, '_et_pb_old_content', ''),
(1787, 85, '_et_pb_post_hide_nav', ''),
(1788, 85, '_et_pb_page_layout', ''),
(1789, 85, '_et_pb_side_nav', ''),
(1790, 85, '_et_pb_use_builder', ''),
(1791, 85, '_et_pb_first_image', ''),
(1792, 85, '_et_pb_truncate_post', ''),
(1793, 85, '_et_pb_truncate_post_date', ''),
(1794, 85, '_et_pb_old_content', ''),
(1795, 85, '_wp_old_slug', 'import-placeholder-for-138'),
(1796, 85, '_variation_description', ''),
(1797, 85, '_regular_price', '29.99'),
(1798, 85, '_sale_price', '27.99'),
(1799, 85, '_thumbnail_id', '0'),
(1800, 85, 'attribute_pa_size', 'large'),
(1801, 85, '_price', '27.99'),
(1802, 86, '_et_pb_post_hide_nav', ''),
(1803, 86, '_et_pb_page_layout', ''),
(1804, 86, '_et_pb_side_nav', ''),
(1805, 86, '_et_pb_use_builder', ''),
(1806, 86, '_et_pb_first_image', ''),
(1807, 86, '_et_pb_truncate_post', ''),
(1808, 86, '_et_pb_truncate_post_date', ''),
(1809, 86, '_et_pb_old_content', ''),
(1810, 86, '_wp_old_slug', 'import-placeholder-for-139'),
(1811, 86, '_variation_description', ''),
(1812, 86, '_regular_price', '29.99'),
(1813, 86, '_sale_price', '27.99'),
(1814, 86, '_thumbnail_id', '0'),
(1815, 86, 'attribute_pa_size', 'medium'),
(1816, 86, '_price', '27.99'),
(1817, 87, '_et_pb_post_hide_nav', ''),
(1818, 87, '_et_pb_page_layout', ''),
(1819, 87, '_et_pb_side_nav', ''),
(1820, 87, '_et_pb_use_builder', ''),
(1821, 87, '_et_pb_first_image', ''),
(1822, 87, '_et_pb_truncate_post', ''),
(1823, 87, '_et_pb_truncate_post_date', ''),
(1824, 87, '_et_pb_old_content', ''),
(1825, 87, '_wp_old_slug', 'import-placeholder-for-140'),
(1826, 87, '_variation_description', ''),
(1827, 87, '_regular_price', '29.99'),
(1828, 87, '_sale_price', '27.99'),
(1829, 87, '_thumbnail_id', '0'),
(1830, 87, 'attribute_pa_size', 'small'),
(1831, 87, '_price', '27.99'),
(1832, 111, '_wp_attached_file', '2024/03/Hoodie-Women-3.jpg'),
(1833, 111, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1360;s:4:"file";s:26:"2024/03/Hoodie-Women-3.jpg";s:8:"filesize";i:147565;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:26:"Hoodie-Women-3-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6096;}s:5:"large";a:5:{s:4:"file";s:27:"Hoodie-Women-3-1024x725.jpg";s:5:"width";i:1024;s:6:"height";i:725;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:37408;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"Hoodie-Women-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3701;}s:12:"medium_large";a:5:{s:4:"file";s:26:"Hoodie-Women-3-768x544.jpg";s:5:"width";i:768;s:6:"height";i:544;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:23252;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"Hoodie-Women-3-1536x1088.jpg";s:5:"width";i:1536;s:6:"height";i:1088;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:81286;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:26:"Hoodie-Women-3-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9414;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:26:"Hoodie-Women-3-600x425.jpg";s:5:"width";i:600;s:6:"height";i:425;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16080;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:26:"Hoodie-Women-3-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2156;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:24:"Hoodie-Women-3-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:993;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:26:"Hoodie-Women-3-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2156;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1834, 111, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Hoodie-Women-3.jpg'),
(1835, 88, '_wp_old_slug', 'import-placeholder-for-142'),
(1836, 88, '_default_attributes', 'a:1:{s:7:"pa_size";s:6:"medium";}'),
(1837, 88, '_thumbnail_id', '111'),
(1838, 88, '_product_attributes', 'a:2:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(1839, 88, '_et_pb_post_hide_nav', 'default'),
(1840, 88, '_et_pb_page_layout', 'et_right_sidebar'),
(1841, 88, '_et_pb_side_nav', 'off'),
(1842, 88, '_et_pb_use_builder', ''),
(1843, 88, '_et_pb_first_image', ''),
(1844, 88, '_et_pb_truncate_post', ''),
(1845, 88, '_et_pb_truncate_post_date', ''),
(1846, 88, '_et_pb_old_content', ''),
(1847, 89, '_et_pb_post_hide_nav', ''),
(1848, 89, '_et_pb_page_layout', ''),
(1849, 89, '_et_pb_side_nav', ''),
(1850, 89, '_et_pb_use_builder', ''),
(1851, 89, '_et_pb_first_image', ''),
(1852, 89, '_et_pb_truncate_post', ''),
(1853, 89, '_et_pb_truncate_post_date', ''),
(1854, 89, '_et_pb_old_content', ''),
(1855, 89, '_wp_old_slug', 'import-placeholder-for-143'),
(1856, 89, '_variation_description', ''),
(1857, 89, '_regular_price', '29.99'),
(1858, 89, '_sale_price', '27.99'),
(1859, 89, '_thumbnail_id', '0'),
(1860, 89, 'attribute_pa_size', 'large'),
(1861, 89, '_price', '27.99'),
(1862, 90, '_et_pb_post_hide_nav', ''),
(1863, 90, '_et_pb_page_layout', ''),
(1864, 90, '_et_pb_side_nav', ''),
(1865, 90, '_et_pb_use_builder', ''),
(1866, 90, '_et_pb_first_image', ''),
(1867, 90, '_et_pb_truncate_post', ''),
(1868, 90, '_et_pb_truncate_post_date', ''),
(1869, 90, '_et_pb_old_content', ''),
(1870, 90, '_wp_old_slug', 'import-placeholder-for-144'),
(1871, 90, '_variation_description', ''),
(1872, 90, '_regular_price', '29.99'),
(1873, 90, '_sale_price', '27.99'),
(1874, 90, '_thumbnail_id', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1875, 90, 'attribute_pa_size', 'medium'),
(1876, 90, '_price', '27.99'),
(1877, 91, '_et_pb_post_hide_nav', ''),
(1878, 91, '_et_pb_page_layout', ''),
(1879, 91, '_et_pb_side_nav', ''),
(1880, 91, '_et_pb_use_builder', ''),
(1881, 91, '_et_pb_first_image', ''),
(1882, 91, '_et_pb_truncate_post', ''),
(1883, 91, '_et_pb_truncate_post_date', ''),
(1884, 91, '_et_pb_old_content', ''),
(1885, 91, '_wp_old_slug', 'import-placeholder-for-145'),
(1886, 91, '_variation_description', ''),
(1887, 91, '_regular_price', '29.99'),
(1888, 91, '_sale_price', '27.99'),
(1889, 91, '_thumbnail_id', '0'),
(1890, 91, 'attribute_pa_size', 'small'),
(1891, 91, '_price', '27.99'),
(1892, 112, '_wp_attached_file', '2024/03/Divi-Ninja.jpg'),
(1893, 112, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1440;s:4:"file";s:22:"2024/03/Divi-Ninja.jpg";s:8:"filesize";i:42675;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:22:"Divi-Ninja-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3865;}s:5:"large";a:5:{s:4:"file";s:23:"Divi-Ninja-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20508;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"Divi-Ninja-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2250;}s:12:"medium_large";a:5:{s:4:"file";s:22:"Divi-Ninja-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13675;}s:9:"1536x1536";a:5:{s:4:"file";s:24:"Divi-Ninja-1536x1152.jpg";s:5:"width";i:1536;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:37064;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"Divi-Ninja-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5400;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"Divi-Ninja-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9803;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"Divi-Ninja-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1512;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:20:"Divi-Ninja-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:815;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:22:"Divi-Ninja-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1512;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1894, 112, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Divi-Ninja.jpg'),
(1895, 92, '_wp_old_slug', 'import-placeholder-for-147'),
(1896, 92, '_default_attributes', 'a:1:{s:7:"pa_size";s:5:"large";}'),
(1897, 92, '_thumbnail_id', '112'),
(1898, 92, '_product_attributes', 'a:2:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(1899, 92, '_et_pb_post_hide_nav', 'default'),
(1900, 92, '_et_pb_page_layout', 'et_right_sidebar'),
(1901, 92, '_et_pb_side_nav', 'off'),
(1902, 92, '_et_pb_use_builder', ''),
(1903, 92, '_et_pb_first_image', ''),
(1904, 92, '_et_pb_truncate_post', ''),
(1905, 92, '_et_pb_truncate_post_date', ''),
(1906, 92, '_et_pb_old_content', ''),
(1907, 93, '_et_pb_post_hide_nav', ''),
(1908, 93, '_et_pb_page_layout', ''),
(1909, 93, '_et_pb_side_nav', ''),
(1910, 93, '_et_pb_use_builder', ''),
(1911, 93, '_et_pb_first_image', ''),
(1912, 93, '_et_pb_truncate_post', ''),
(1913, 93, '_et_pb_truncate_post_date', ''),
(1914, 93, '_et_pb_old_content', ''),
(1915, 93, '_wp_old_slug', 'import-placeholder-for-148'),
(1916, 93, '_variation_description', ''),
(1917, 93, '_regular_price', '12.99'),
(1918, 93, '_thumbnail_id', '0'),
(1919, 93, 'attribute_pa_size', 'large'),
(1920, 93, '_price', '12.99'),
(1921, 94, '_et_pb_post_hide_nav', ''),
(1922, 94, '_et_pb_page_layout', ''),
(1923, 94, '_et_pb_side_nav', ''),
(1924, 94, '_et_pb_use_builder', ''),
(1925, 94, '_et_pb_first_image', ''),
(1926, 94, '_et_pb_truncate_post', ''),
(1927, 94, '_et_pb_truncate_post_date', ''),
(1928, 94, '_et_pb_old_content', ''),
(1929, 94, '_wp_old_slug', 'import-placeholder-for-149'),
(1930, 94, '_variation_description', ''),
(1931, 94, '_regular_price', '12.99'),
(1932, 94, '_thumbnail_id', '0'),
(1933, 94, 'attribute_pa_size', 'medium'),
(1934, 94, '_price', '12.99'),
(1935, 95, '_et_pb_post_hide_nav', ''),
(1936, 95, '_et_pb_page_layout', ''),
(1937, 95, '_et_pb_side_nav', ''),
(1938, 95, '_et_pb_use_builder', ''),
(1939, 95, '_et_pb_first_image', ''),
(1940, 95, '_et_pb_truncate_post', ''),
(1941, 95, '_et_pb_truncate_post_date', ''),
(1942, 95, '_et_pb_old_content', ''),
(1943, 95, '_wp_old_slug', 'import-placeholder-for-150'),
(1944, 95, '_variation_description', ''),
(1945, 95, '_regular_price', '12.99'),
(1946, 95, '_thumbnail_id', '0'),
(1947, 95, 'attribute_pa_size', 'small'),
(1948, 95, '_price', '12.99'),
(1949, 113, '_wp_attached_file', '2024/03/divi-Simplified-croptop-white.jpg'),
(1950, 113, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1262;s:4:"file";s:41:"2024/03/divi-Simplified-croptop-white.jpg";s:8:"filesize";i:111698;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:41:"divi-Simplified-croptop-white-300x197.jpg";s:5:"width";i:300;s:6:"height";i:197;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6309;}s:5:"large";a:5:{s:4:"file";s:42:"divi-Simplified-croptop-white-1024x673.jpg";s:5:"width";i:1024;s:6:"height";i:673;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:39403;}s:9:"thumbnail";a:5:{s:4:"file";s:41:"divi-Simplified-croptop-white-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4196;}s:12:"medium_large";a:5:{s:4:"file";s:41:"divi-Simplified-croptop-white-768x505.jpg";s:5:"width";i:768;s:6:"height";i:505;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:25333;}s:9:"1536x1536";a:5:{s:4:"file";s:43:"divi-Simplified-croptop-white-1536x1010.jpg";s:5:"width";i:1536;s:6:"height";i:1010;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:73308;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:41:"divi-Simplified-croptop-white-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11227;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:41:"divi-Simplified-croptop-white-600x394.jpg";s:5:"width";i:600;s:6:"height";i:394;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17644;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:41:"divi-Simplified-croptop-white-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2386;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:39:"divi-Simplified-croptop-white-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1039;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:41:"divi-Simplified-croptop-white-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2386;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1951, 113, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/divi-Simplified-croptop-white.jpg'),
(1952, 96, '_wp_old_slug', 'import-placeholder-for-151'),
(1953, 96, '_default_attributes', 'a:2:{s:7:"pa_size";s:5:"large";s:8:"pa_color";s:5:"white";}'),
(1954, 96, '_thumbnail_id', '113'),
(1955, 96, '_product_attributes', 'a:3:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}s:8:"pa_color";a:6:{s:4:"name";s:8:"pa_color";s:5:"value";s:0:"";s:8:"position";i:2;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(1956, 114, '_wp_attached_file', '2024/03/divi-Simplified-croptop-blue-scaled.jpg'),
(1957, 114, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1682;s:4:"file";s:47:"2024/03/divi-Simplified-croptop-blue-scaled.jpg";s:8:"filesize";i:176067;s:5:"sizes";a:11:{s:6:"medium";a:5:{s:4:"file";s:40:"divi-Simplified-croptop-blue-300x197.jpg";s:5:"width";i:300;s:6:"height";i:197;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6407;}s:5:"large";a:5:{s:4:"file";s:41:"divi-Simplified-croptop-blue-1024x673.jpg";s:5:"width";i:1024;s:6:"height";i:673;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:41311;}s:9:"thumbnail";a:5:{s:4:"file";s:40:"divi-Simplified-croptop-blue-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4213;}s:12:"medium_large";a:5:{s:4:"file";s:40:"divi-Simplified-croptop-blue-768x505.jpg";s:5:"width";i:768;s:6:"height";i:505;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:26534;}s:9:"1536x1536";a:5:{s:4:"file";s:42:"divi-Simplified-croptop-blue-1536x1009.jpg";s:5:"width";i:1536;s:6:"height";i:1009;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:77424;}s:9:"2048x2048";a:5:{s:4:"file";s:42:"divi-Simplified-croptop-blue-2048x1346.jpg";s:5:"width";i:2048;s:6:"height";i:1346;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:123253;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:40:"divi-Simplified-croptop-blue-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11626;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:40:"divi-Simplified-croptop-blue-600x394.jpg";s:5:"width";i:600;s:6:"height";i:394;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18320;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:40:"divi-Simplified-croptop-blue-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2333;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:38:"divi-Simplified-croptop-blue-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:996;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:40:"divi-Simplified-croptop-blue-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2333;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:32:"divi-Simplified-croptop-blue.jpg";}'),
(1958, 114, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/divi-Simplified-croptop-blue.jpg'),
(1959, 115, '_wp_attached_file', '2024/03/divi-Simplified-croptop-yellow.jpg'),
(1960, 115, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1262;s:4:"file";s:42:"2024/03/divi-Simplified-croptop-yellow.jpg";s:8:"filesize";i:117836;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:42:"divi-Simplified-croptop-yellow-300x197.jpg";s:5:"width";i:300;s:6:"height";i:197;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6672;}s:5:"large";a:5:{s:4:"file";s:43:"divi-Simplified-croptop-yellow-1024x673.jpg";s:5:"width";i:1024;s:6:"height";i:673;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:41182;}s:9:"thumbnail";a:5:{s:4:"file";s:42:"divi-Simplified-croptop-yellow-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4445;}s:12:"medium_large";a:5:{s:4:"file";s:42:"divi-Simplified-croptop-yellow-768x505.jpg";s:5:"width";i:768;s:6:"height";i:505;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:26634;}s:9:"1536x1536";a:5:{s:4:"file";s:44:"divi-Simplified-croptop-yellow-1536x1010.jpg";s:5:"width";i:1536;s:6:"height";i:1010;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:75423;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:42:"divi-Simplified-croptop-yellow-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11889;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:42:"divi-Simplified-croptop-yellow-600x394.jpg";s:5:"width";i:600;s:6:"height";i:394;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18535;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:42:"divi-Simplified-croptop-yellow-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2493;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:40:"divi-Simplified-croptop-yellow-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1088;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:42:"divi-Simplified-croptop-yellow-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2493;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1961, 115, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/divi-Simplified-croptop-yellow.jpg'),
(1962, 96, '_et_pb_post_hide_nav', 'default'),
(1963, 96, '_et_pb_page_layout', 'et_right_sidebar'),
(1964, 96, '_et_pb_side_nav', 'off'),
(1965, 96, '_et_pb_use_builder', ''),
(1966, 96, '_et_pb_first_image', ''),
(1967, 96, '_et_pb_truncate_post', ''),
(1968, 96, '_et_pb_truncate_post_date', ''),
(1969, 96, '_et_pb_old_content', ''),
(1970, 96, '_product_image_gallery', '114,115'),
(1971, 116, '_wp_attached_file', '2024/03/Dat-Divi_Life.jpg'),
(1972, 116, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1262;s:4:"file";s:25:"2024/03/Dat-Divi_Life.jpg";s:8:"filesize";i:102600;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:25:"Dat-Divi_Life-300x197.jpg";s:5:"width";i:300;s:6:"height";i:197;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6244;}s:5:"large";a:5:{s:4:"file";s:26:"Dat-Divi_Life-1024x673.jpg";s:5:"width";i:1024;s:6:"height";i:673;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:35963;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"Dat-Divi_Life-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4245;}s:12:"medium_large";a:5:{s:4:"file";s:25:"Dat-Divi_Life-768x505.jpg";s:5:"width";i:768;s:6:"height";i:505;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:23352;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"Dat-Divi_Life-1536x1010.jpg";s:5:"width";i:1536;s:6:"height";i:1010;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:67100;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:25:"Dat-Divi_Life-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10547;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:25:"Dat-Divi_Life-600x394.jpg";s:5:"width";i:600;s:6:"height";i:394;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16259;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:25:"Dat-Divi_Life-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2468;}s:29:"variation_swatches_image_size";a:5:{s:4:"file";s:23:"Dat-Divi_Life-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1125;}s:31:"variation_swatches_tooltip_size";a:5:{s:4:"file";s:25:"Dat-Divi_Life-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2468;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1973, 116, '_wc_attachment_source', 'https://ajax-filters-bc.diviengine.com/sampledata/images/Dat-Divi_Life.jpg'),
(1974, 97, '_wp_old_slug', 'import-placeholder-for-155') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1975, 97, '_default_attributes', 'a:1:{s:7:"pa_size";s:5:"large";}'),
(1976, 97, '_thumbnail_id', '116'),
(1977, 97, '_product_attributes', 'a:2:{s:8:"pa_brand";a:6:{s:4:"name";s:8:"pa_brand";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(1978, 97, '_et_pb_post_hide_nav', 'default'),
(1979, 97, '_et_pb_page_layout', 'et_right_sidebar'),
(1980, 97, '_et_pb_side_nav', 'off'),
(1981, 97, '_et_pb_use_builder', ''),
(1982, 97, '_et_pb_first_image', ''),
(1983, 97, '_et_pb_truncate_post', ''),
(1984, 97, '_et_pb_truncate_post_date', ''),
(1985, 97, '_et_pb_old_content', ''),
(1986, 98, '_et_pb_post_hide_nav', ''),
(1987, 98, '_et_pb_page_layout', ''),
(1988, 98, '_et_pb_side_nav', ''),
(1989, 98, '_et_pb_use_builder', ''),
(1990, 98, '_et_pb_first_image', ''),
(1991, 98, '_et_pb_truncate_post', ''),
(1992, 98, '_et_pb_truncate_post_date', ''),
(1993, 98, '_et_pb_old_content', ''),
(1994, 98, '_wp_old_slug', 'import-placeholder-for-156'),
(1995, 98, '_variation_description', ''),
(1996, 98, '_regular_price', '14.99'),
(1997, 98, '_thumbnail_id', '0'),
(1998, 98, 'attribute_pa_size', 'large'),
(1999, 98, '_price', '14.99'),
(2000, 99, '_et_pb_post_hide_nav', ''),
(2001, 99, '_et_pb_page_layout', ''),
(2002, 99, '_et_pb_side_nav', ''),
(2003, 99, '_et_pb_use_builder', ''),
(2004, 99, '_et_pb_first_image', ''),
(2005, 99, '_et_pb_truncate_post', ''),
(2006, 99, '_et_pb_truncate_post_date', ''),
(2007, 99, '_et_pb_old_content', ''),
(2008, 99, '_wp_old_slug', 'import-placeholder-for-157'),
(2009, 99, '_variation_description', ''),
(2010, 99, '_regular_price', '12.99'),
(2011, 99, '_thumbnail_id', '0'),
(2012, 99, 'attribute_pa_size', 'medium'),
(2013, 99, '_price', '12.99'),
(2014, 100, '_et_pb_post_hide_nav', ''),
(2015, 100, '_et_pb_page_layout', ''),
(2016, 100, '_et_pb_side_nav', ''),
(2017, 100, '_et_pb_use_builder', ''),
(2018, 100, '_et_pb_first_image', ''),
(2019, 100, '_et_pb_truncate_post', ''),
(2020, 100, '_et_pb_truncate_post_date', ''),
(2021, 100, '_et_pb_old_content', ''),
(2022, 100, '_wp_old_slug', 'import-placeholder-for-158'),
(2023, 100, '_variation_description', ''),
(2024, 100, '_regular_price', '12.99'),
(2025, 100, '_thumbnail_id', '0'),
(2026, 100, 'attribute_pa_size', 'small'),
(2027, 100, '_price', '12.99'),
(2028, 101, '_wp_old_slug', 'import-placeholder-for-163'),
(2029, 101, '_variation_description', ''),
(2030, 101, '_regular_price', '12.99'),
(2031, 101, '_thumbnail_id', '114'),
(2032, 101, 'attribute_pa_size', 'large'),
(2033, 101, 'attribute_pa_color', 'blue'),
(2034, 101, '_price', '12.99'),
(2035, 101, '_et_pb_post_hide_nav', ''),
(2036, 101, '_et_pb_page_layout', ''),
(2037, 101, '_et_pb_side_nav', ''),
(2038, 101, '_et_pb_use_builder', ''),
(2039, 101, '_et_pb_first_image', ''),
(2040, 101, '_et_pb_truncate_post', ''),
(2041, 101, '_et_pb_truncate_post_date', ''),
(2042, 101, '_et_pb_old_content', ''),
(2043, 102, '_wp_old_slug', 'import-placeholder-for-164'),
(2044, 102, '_variation_description', ''),
(2045, 102, '_regular_price', '12.99'),
(2046, 102, '_thumbnail_id', '113'),
(2047, 102, 'attribute_pa_size', 'large'),
(2048, 102, 'attribute_pa_color', 'white'),
(2049, 102, '_price', '12.99'),
(2050, 102, '_et_pb_post_hide_nav', ''),
(2051, 102, '_et_pb_page_layout', ''),
(2052, 102, '_et_pb_side_nav', ''),
(2053, 102, '_et_pb_use_builder', ''),
(2054, 102, '_et_pb_first_image', ''),
(2055, 102, '_et_pb_truncate_post', ''),
(2056, 102, '_et_pb_truncate_post_date', ''),
(2057, 102, '_et_pb_old_content', ''),
(2058, 103, '_wp_old_slug', 'import-placeholder-for-165'),
(2059, 103, '_variation_description', ''),
(2060, 103, '_regular_price', '12.99'),
(2061, 103, '_thumbnail_id', '115'),
(2062, 103, 'attribute_pa_size', 'large'),
(2063, 103, 'attribute_pa_color', 'yellow'),
(2064, 103, '_price', '12.99'),
(2065, 103, '_et_pb_post_hide_nav', ''),
(2066, 103, '_et_pb_page_layout', ''),
(2067, 103, '_et_pb_side_nav', ''),
(2068, 103, '_et_pb_use_builder', ''),
(2069, 103, '_et_pb_first_image', ''),
(2070, 103, '_et_pb_truncate_post', ''),
(2071, 103, '_et_pb_truncate_post_date', ''),
(2072, 103, '_et_pb_old_content', ''),
(2073, 104, '_wp_old_slug', 'import-placeholder-for-166'),
(2074, 104, '_variation_description', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2075, 104, '_regular_price', '12.99'),
(2076, 104, '_thumbnail_id', '114'),
(2077, 104, 'attribute_pa_size', 'medium'),
(2078, 104, 'attribute_pa_color', 'blue'),
(2079, 104, '_price', '12.99'),
(2080, 104, '_et_pb_post_hide_nav', ''),
(2081, 104, '_et_pb_page_layout', ''),
(2082, 104, '_et_pb_side_nav', ''),
(2083, 104, '_et_pb_use_builder', ''),
(2084, 104, '_et_pb_first_image', ''),
(2085, 104, '_et_pb_truncate_post', ''),
(2086, 104, '_et_pb_truncate_post_date', ''),
(2087, 104, '_et_pb_old_content', ''),
(2088, 105, '_wp_old_slug', 'import-placeholder-for-167'),
(2089, 105, '_variation_description', ''),
(2090, 105, '_regular_price', '12.99'),
(2091, 105, '_thumbnail_id', '113'),
(2092, 105, 'attribute_pa_size', 'medium'),
(2093, 105, 'attribute_pa_color', 'white'),
(2094, 105, '_price', '12.99'),
(2095, 105, '_et_pb_post_hide_nav', ''),
(2096, 105, '_et_pb_page_layout', ''),
(2097, 105, '_et_pb_side_nav', ''),
(2098, 105, '_et_pb_use_builder', ''),
(2099, 105, '_et_pb_first_image', ''),
(2100, 105, '_et_pb_truncate_post', ''),
(2101, 105, '_et_pb_truncate_post_date', ''),
(2102, 105, '_et_pb_old_content', ''),
(2103, 106, '_wp_old_slug', 'import-placeholder-for-168'),
(2104, 106, '_variation_description', ''),
(2105, 106, '_regular_price', '12.99'),
(2106, 106, '_thumbnail_id', '115'),
(2107, 106, 'attribute_pa_size', 'medium'),
(2108, 106, 'attribute_pa_color', 'yellow'),
(2109, 106, '_price', '12.99'),
(2110, 106, '_et_pb_post_hide_nav', ''),
(2111, 106, '_et_pb_page_layout', ''),
(2112, 106, '_et_pb_side_nav', ''),
(2113, 106, '_et_pb_use_builder', ''),
(2114, 106, '_et_pb_first_image', ''),
(2115, 106, '_et_pb_truncate_post', ''),
(2116, 106, '_et_pb_truncate_post_date', ''),
(2117, 106, '_et_pb_old_content', ''),
(2118, 107, '_wp_old_slug', 'import-placeholder-for-169'),
(2119, 107, '_variation_description', ''),
(2120, 107, '_regular_price', '12.99'),
(2121, 107, '_thumbnail_id', '114'),
(2122, 107, 'attribute_pa_size', 'small'),
(2123, 107, 'attribute_pa_color', 'blue'),
(2124, 107, '_price', '12.99'),
(2125, 107, '_et_pb_post_hide_nav', ''),
(2126, 107, '_et_pb_page_layout', ''),
(2127, 107, '_et_pb_side_nav', ''),
(2128, 107, '_et_pb_use_builder', ''),
(2129, 107, '_et_pb_first_image', ''),
(2130, 107, '_et_pb_truncate_post', ''),
(2131, 107, '_et_pb_truncate_post_date', ''),
(2132, 107, '_et_pb_old_content', ''),
(2133, 108, '_wp_old_slug', 'import-placeholder-for-170'),
(2134, 108, '_variation_description', ''),
(2135, 108, '_regular_price', '12.99'),
(2136, 108, '_thumbnail_id', '113'),
(2137, 108, 'attribute_pa_size', 'small'),
(2138, 108, 'attribute_pa_color', 'white'),
(2139, 108, '_price', '12.99'),
(2140, 108, '_et_pb_post_hide_nav', ''),
(2141, 108, '_et_pb_page_layout', ''),
(2142, 108, '_et_pb_side_nav', ''),
(2143, 108, '_et_pb_use_builder', ''),
(2144, 108, '_et_pb_first_image', ''),
(2145, 108, '_et_pb_truncate_post', ''),
(2146, 108, '_et_pb_truncate_post_date', ''),
(2147, 108, '_et_pb_old_content', ''),
(2148, 109, '_wp_old_slug', 'import-placeholder-for-171'),
(2149, 109, '_variation_description', ''),
(2150, 109, '_regular_price', '12.99'),
(2151, 109, '_thumbnail_id', '115'),
(2152, 109, 'attribute_pa_size', 'small'),
(2153, 109, 'attribute_pa_color', 'yellow'),
(2154, 109, '_price', '12.99'),
(2155, 109, '_et_pb_post_hide_nav', ''),
(2156, 109, '_et_pb_page_layout', ''),
(2157, 109, '_et_pb_side_nav', ''),
(2158, 109, '_et_pb_use_builder', ''),
(2159, 109, '_et_pb_first_image', ''),
(2160, 109, '_et_pb_truncate_post', ''),
(2161, 109, '_et_pb_truncate_post_date', ''),
(2162, 109, '_et_pb_old_content', ''),
(2163, 72, '_price', '29.99'),
(2164, 84, '_price', '27.99'),
(2165, 88, '_price', '27.99'),
(2166, 92, '_price', '12.99'),
(2167, 97, '_price', '12.99'),
(2168, 97, '_price', '14.99'),
(2169, 96, '_price', '12.99'),
(2170, 84, '_edit_lock', '1709903816:1'),
(2171, 28, '_edit_lock', '1709910550:1'),
(2173, 117, 'origin', 'theme'),
(2174, 121, 'origin', 'plugin'),
(2175, 124, 'origin', 'theme') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2176, 3, '_wp_suggested_privacy_policy_content', 'a:3:{s:11:"plugin_name";s:9:"WordPress";s:11:"policy_text";s:4238:"<h2>Who we are</h2><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://localhost:82.</p><h2>Comments</h2><p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h2>Media</h2><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h2>Cookies</h2><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h2>Embedded content from other websites</h2><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h2>Who we share your data with</h2><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><h2>How long we retain your data</h2><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where your data is sent</h2><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>";s:5:"added";i:1709912384;}'),
(2177, 3, '_wp_suggested_privacy_policy_content', 'a:3:{s:11:"plugin_name";s:11:"WooCommerce";s:11:"policy_text";s:4106:"<div class="wp-suggested-text"><p class="privacy-policy-tutorial">This sample language includes the basics around what personal data your store may be collecting, storing and sharing, as well as who may have access to that data. Depending on what settings are enabled and which additional plugins are used, the specific information shared by your store will vary. We recommend consulting with a lawyer when deciding what information to disclose on your privacy policy.</p><p>We collect information about you during the checkout process on our store.</p><h2>What we collect and store</h2><p>While you visit our site, we’ll track:</p><ul><li>Products you’ve viewed: we’ll use this to, for example, show you products you’ve recently viewed</li><li>Location, IP address and browser type: we’ll use this for purposes like estimating taxes and shipping</li><li>Shipping address: we’ll ask you to enter this so we can, for instance, estimate shipping before you place an order, and send you the order!</li></ul><p>We’ll also use cookies to keep track of cart contents while you’re browsing our site.</p><p class="privacy-policy-tutorial">Note: you may want to further detail your cookie policy, and link to that section from here.</p><p>When you purchase from us, we’ll ask you to provide information including your name, billing address, shipping address, email address, phone number, credit card/payment details and optional account information like username and password. We’ll use this information for purposes, such as, to:</p><ul><li>Send you information about your account and order</li><li>Respond to your requests, including refunds and complaints</li><li>Process payments and prevent fraud</li><li>Set up your account for our store</li><li>Comply with any legal obligations we have, such as calculating taxes</li><li>Improve our store offerings</li><li>Send you marketing messages, if you choose to receive them</li></ul><p>If you create an account, we will store your name, address, email and phone number, which will be used to populate the checkout for future orders.</p><p>We generally store information about you for as long as we need the information for the purposes for which we collect and use it, and we are not legally required to continue to keep it. For example, we will store order information for XXX years for tax and accounting purposes. This includes your name, email address and billing and shipping addresses.</p><p>We will also store comments or reviews, if you choose to leave them.</p><h2>Who on our team has access</h2><p>Members of our team have access to the information you provide us. For example, both Administrators and Shop Managers can access:</p><ul><li>Order information like what was purchased, when it was purchased and where it should be sent, and</li><li>Customer information like your name, email address, and billing and shipping information.</li></ul><p>Our team members have access to this information to help fulfill orders, process refunds and support you.</p><h2>What we share with others</h2><p class="privacy-policy-tutorial">In this section you should list who you’re sharing data with, and for what purpose. This could include, but may not be limited to, analytics, marketing, payment gateways, shipping providers, and third party embeds.</p><p>We share information with third parties who help us provide our orders and store services to you; for example --</p><h3>Payments</h3><p class="privacy-policy-tutorial">In this subsection you should list which third party payment processors you’re using to take payments on your store since these may handle customer data. We’ve included PayPal as an example, but you should remove this if you’re not using PayPal.</p><p>We accept payments through PayPal. When processing payments, some of your data will be passed to PayPal, including information required to process or support the payment, such as the purchase total and billing information.</p><p>Please see the <a href="https://www.paypal.com/us/webapps/mpp/ua/privacy-full">PayPal Privacy Policy</a> for more details.</p></div>";s:5:"added";i:1709912384;}'),
(2178, 130, 'wp_pattern_sync_status', 'unsynced'),
(2179, 15, '_edit_lock', '1709956067:1'),
(2180, 3, '_edit_lock', '1709956077:1'),
(2181, 144, 'origin', 'theme') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2024-03-08 11:45:30', '2024-03-08 11:45:30', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2024-03-08 11:45:30', '2024-03-08 11:45:30', '', 0, 'http://localhost:82/?p=1', 0, 'post', '', 1),
(2, 1, '2024-03-08 11:45:30', '2024-03-08 11:45:30', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost:82/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2024-03-08 11:45:30', '2024-03-08 11:45:30', '', 0, 'http://localhost:82/?page_id=2', 0, 'page', '', 0),
(3, 1, '2024-03-08 11:45:30', '2024-03-08 11:45:30', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://localhost:82.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'publish', 'closed', 'open', '', 'privacy-policy', '', '', '2024-03-09 03:50:17', '2024-03-09 03:50:17', '', 0, 'http://localhost:82/?page_id=3', 0, 'page', '', 0),
(4, 1, '2024-03-08 11:45:41', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2024-03-08 11:45:41', '0000-00-00 00:00:00', '', 0, 'http://localhost:82/?p=4', 0, 'post', '', 0),
(5, 1, '2024-03-08 11:46:13', '2024-03-08 11:46:13', '<!-- wp:navigation-submenu {"label":"All Collection","type":"page","id":11,"url":"http://localhost:82/shop/","kind":"post-type"} -->\n<!-- wp:navigation-link {"label":"Women","type":"product_cat","id":32,"url":"http://localhost:82/product-category/women/","kind":"taxonomy"} /-->\n\n<!-- wp:navigation-link {"label":"Mens WordPress Hoodie","type":"product","id":68,"url":"http://localhost:82/product/mens-wordpress-hoodie/","kind":"post-type"} /-->\n<!-- /wp:navigation-submenu -->', 'Navigation', '', 'publish', 'closed', 'closed', '', 'navigation', '', '', '2024-03-09 03:47:59', '2024-03-09 03:47:59', '', 0, 'http://localhost:82/navigation/', 0, 'wp_navigation', '', 0),
(9, 1, '2024-03-08 12:18:50', '2024-03-08 12:18:50', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-twentytwentyfour', '', '', '2024-03-08 12:18:50', '2024-03-08 12:18:50', '', 0, 'http://localhost:82/wp-global-styles-twentytwentyfour/', 0, 'wp_global_styles', '', 0),
(10, 1, '2024-03-08 12:21:01', '2024-03-08 12:21:01', '', 'woocommerce-placeholder', '', 'inherit', 'open', 'closed', '', 'woocommerce-placeholder', '', '', '2024-03-08 12:21:01', '2024-03-08 12:21:01', '', 0, 'http://localhost:82/wp-content/uploads/2024/03/woocommerce-placeholder.png', 0, 'attachment', 'image/png', 0),
(11, 1, '2024-03-08 12:21:01', '2024-03-08 12:21:01', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2024-03-08 12:21:01', '2024-03-08 12:21:01', '', 0, 'http://localhost:82/shop/', 0, 'page', '', 0),
(12, 1, '2024-03-08 12:21:01', '2024-03-08 12:21:01', '<!-- wp:woocommerce/cart -->\n<div class="wp-block-woocommerce-cart alignwide is-loading"><!-- wp:woocommerce/filled-cart-block -->\n<div class="wp-block-woocommerce-filled-cart-block"><!-- wp:woocommerce/cart-items-block -->\n<div class="wp-block-woocommerce-cart-items-block"><!-- wp:woocommerce/cart-line-items-block -->\n<div class="wp-block-woocommerce-cart-line-items-block"></div>\n<!-- /wp:woocommerce/cart-line-items-block -->\n\n<!-- wp:woocommerce/cart-cross-sells-block -->\n<div class="wp-block-woocommerce-cart-cross-sells-block"><!-- wp:heading {"fontSize":"large"} -->\n<h2 class="wp-block-heading has-large-font-size">You may be interested in…</h2>\n<!-- /wp:heading -->\n\n<!-- wp:woocommerce/cart-cross-sells-products-block -->\n<div class="wp-block-woocommerce-cart-cross-sells-products-block"></div>\n<!-- /wp:woocommerce/cart-cross-sells-products-block --></div>\n<!-- /wp:woocommerce/cart-cross-sells-block --></div>\n<!-- /wp:woocommerce/cart-items-block -->\n\n<!-- wp:woocommerce/cart-totals-block -->\n<div class="wp-block-woocommerce-cart-totals-block"><!-- wp:woocommerce/cart-order-summary-block -->\n<div class="wp-block-woocommerce-cart-order-summary-block"><!-- wp:woocommerce/cart-order-summary-heading-block -->\n<div class="wp-block-woocommerce-cart-order-summary-heading-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-heading-block -->\n\n<!-- wp:woocommerce/cart-order-summary-coupon-form-block -->\n<div class="wp-block-woocommerce-cart-order-summary-coupon-form-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-coupon-form-block -->\n\n<!-- wp:woocommerce/cart-order-summary-subtotal-block -->\n<div class="wp-block-woocommerce-cart-order-summary-subtotal-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-subtotal-block -->\n\n<!-- wp:woocommerce/cart-order-summary-fee-block -->\n<div class="wp-block-woocommerce-cart-order-summary-fee-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-fee-block -->\n\n<!-- wp:woocommerce/cart-order-summary-discount-block -->\n<div class="wp-block-woocommerce-cart-order-summary-discount-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-discount-block -->\n\n<!-- wp:woocommerce/cart-order-summary-shipping-block -->\n<div class="wp-block-woocommerce-cart-order-summary-shipping-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-shipping-block -->\n\n<!-- wp:woocommerce/cart-order-summary-taxes-block -->\n<div class="wp-block-woocommerce-cart-order-summary-taxes-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-taxes-block --></div>\n<!-- /wp:woocommerce/cart-order-summary-block -->\n\n<!-- wp:woocommerce/cart-express-payment-block -->\n<div class="wp-block-woocommerce-cart-express-payment-block"></div>\n<!-- /wp:woocommerce/cart-express-payment-block -->\n\n<!-- wp:woocommerce/proceed-to-checkout-block -->\n<div class="wp-block-woocommerce-proceed-to-checkout-block"></div>\n<!-- /wp:woocommerce/proceed-to-checkout-block -->\n\n<!-- wp:woocommerce/cart-accepted-payment-methods-block -->\n<div class="wp-block-woocommerce-cart-accepted-payment-methods-block"></div>\n<!-- /wp:woocommerce/cart-accepted-payment-methods-block --></div>\n<!-- /wp:woocommerce/cart-totals-block --></div>\n<!-- /wp:woocommerce/filled-cart-block -->\n\n<!-- wp:woocommerce/empty-cart-block -->\n<div class="wp-block-woocommerce-empty-cart-block"><!-- wp:heading {"textAlign":"center","className":"with-empty-cart-icon wc-block-cart__empty-cart__title"} -->\n<h2 class="wp-block-heading has-text-align-center with-empty-cart-icon wc-block-cart__empty-cart__title">Your cart is currently empty!</h2>\n<!-- /wp:heading -->\n\n<!-- wp:separator {"className":"is-style-dots"} -->\n<hr class="wp-block-separator has-alpha-channel-opacity is-style-dots"/>\n<!-- /wp:separator -->\n\n<!-- wp:heading {"textAlign":"center"} -->\n<h2 class="wp-block-heading has-text-align-center">New in store</h2>\n<!-- /wp:heading -->\n\n<!-- wp:woocommerce/product-new {"columns":4,"rows":1} /--></div>\n<!-- /wp:woocommerce/empty-cart-block --></div>\n<!-- /wp:woocommerce/cart -->', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2024-03-08 12:21:01', '2024-03-08 12:21:01', '', 0, 'http://localhost:82/cart/', 0, 'page', '', 0),
(13, 1, '2024-03-08 12:21:01', '2024-03-08 12:21:01', '<!-- wp:woocommerce/checkout -->\n<div class="wp-block-woocommerce-checkout alignwide wc-block-checkout is-loading"><!-- wp:woocommerce/checkout-fields-block -->\n<div class="wp-block-woocommerce-checkout-fields-block"><!-- wp:woocommerce/checkout-express-payment-block -->\n<div class="wp-block-woocommerce-checkout-express-payment-block"></div>\n<!-- /wp:woocommerce/checkout-express-payment-block -->\n\n<!-- wp:woocommerce/checkout-contact-information-block -->\n<div class="wp-block-woocommerce-checkout-contact-information-block"></div>\n<!-- /wp:woocommerce/checkout-contact-information-block -->\n\n<!-- wp:woocommerce/checkout-shipping-method-block -->\n<div class="wp-block-woocommerce-checkout-shipping-method-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-method-block -->\n\n<!-- wp:woocommerce/checkout-pickup-options-block -->\n<div class="wp-block-woocommerce-checkout-pickup-options-block"></div>\n<!-- /wp:woocommerce/checkout-pickup-options-block -->\n\n<!-- wp:woocommerce/checkout-shipping-address-block -->\n<div class="wp-block-woocommerce-checkout-shipping-address-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-address-block -->\n\n<!-- wp:woocommerce/checkout-billing-address-block -->\n<div class="wp-block-woocommerce-checkout-billing-address-block"></div>\n<!-- /wp:woocommerce/checkout-billing-address-block -->\n\n<!-- wp:woocommerce/checkout-shipping-methods-block -->\n<div class="wp-block-woocommerce-checkout-shipping-methods-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-methods-block -->\n\n<!-- wp:woocommerce/checkout-payment-block -->\n<div class="wp-block-woocommerce-checkout-payment-block"></div>\n<!-- /wp:woocommerce/checkout-payment-block -->\n\n<!-- wp:woocommerce/checkout-additional-information-block -->\n<div class="wp-block-woocommerce-checkout-additional-information-block"></div>\n<!-- /wp:woocommerce/checkout-additional-information-block -->\n\n<!-- wp:woocommerce/checkout-order-note-block -->\n<div class="wp-block-woocommerce-checkout-order-note-block"></div>\n<!-- /wp:woocommerce/checkout-order-note-block -->\n\n<!-- wp:woocommerce/checkout-terms-block -->\n<div class="wp-block-woocommerce-checkout-terms-block"></div>\n<!-- /wp:woocommerce/checkout-terms-block -->\n\n<!-- wp:woocommerce/checkout-actions-block -->\n<div class="wp-block-woocommerce-checkout-actions-block"></div>\n<!-- /wp:woocommerce/checkout-actions-block --></div>\n<!-- /wp:woocommerce/checkout-fields-block -->\n\n<!-- wp:woocommerce/checkout-totals-block -->\n<div class="wp-block-woocommerce-checkout-totals-block"><!-- wp:woocommerce/checkout-order-summary-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-block"><!-- wp:woocommerce/checkout-order-summary-cart-items-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-cart-items-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-cart-items-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-coupon-form-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-coupon-form-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-coupon-form-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-subtotal-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-subtotal-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-subtotal-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-fee-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-fee-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-fee-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-discount-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-discount-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-discount-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-shipping-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-shipping-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-shipping-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-taxes-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-taxes-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-taxes-block --></div>\n<!-- /wp:woocommerce/checkout-order-summary-block --></div>\n<!-- /wp:woocommerce/checkout-totals-block --></div>\n<!-- /wp:woocommerce/checkout -->', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2024-03-08 12:21:01', '2024-03-08 12:21:01', '', 0, 'http://localhost:82/checkout/', 0, 'page', '', 0),
(14, 1, '2024-03-08 12:21:01', '2024-03-08 12:21:01', '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2024-03-08 12:21:01', '2024-03-08 12:21:01', '', 0, 'http://localhost:82/my-account/', 0, 'page', '', 0),
(15, 1, '2024-03-09 03:50:03', '2024-03-09 03:50:03', '<!-- wp:paragraph -->\n<p><b>This is a sample page.</b></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h3>Overview</h3>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our refund and returns policy lasts 30 days. If 30 days have passed since your purchase, we can’t offer you a full refund or exchange.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Several types of goods are exempt from being returned. Perishable goods such as food, flowers, newspapers or magazines cannot be returned. We also do not accept products that are intimate or sanitary goods, hazardous materials, or flammable liquids or gases.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Additional non-returnable items:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Gift cards</li>\n<li>Downloadable software products</li>\n<li>Some health and personal care items</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>To complete your return, we require a receipt or proof of purchase.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Please do not send your purchase back to the manufacturer.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>There are certain situations where only partial refunds are granted:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Book with obvious signs of use</li>\n<li>CD, DVD, VHS tape, software, video game, cassette tape, or vinyl record that has been opened.</li>\n<li>Any item not in its original condition, is damaged or missing parts for reasons not due to our error.</li>\n<li>Any item that is returned more than 30 days after delivery</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<h2>Refunds</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Late or missing refunds</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you haven’t received a refund yet, first check your bank account again.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Then contact your credit card company, it may take some time before your refund is officially posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Next contact your bank. There is often some processing time before a refund is posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you’ve done all of this and you still have not received your refund yet, please contact us at {email address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Sale items</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Only regular priced items may be refunded. Sale items cannot be refunded.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Exchanges</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We only replace items if they are defective or damaged. If you need to exchange it for the same item, send us an email at {email address} and send your item to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Gifts</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item was marked as a gift when purchased and shipped directly to you, you’ll receive a gift credit for the value of your return. Once the returned item is received, a gift certificate will be mailed to you.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item wasn’t marked as a gift when purchased, or the gift giver had the order shipped to themselves to give to you later, we will send a refund to the gift giver and they will find out about your return.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Shipping returns</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To return your product, you should mail your product to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. If you receive a refund, the cost of return shipping will be deducted from your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Depending on where you live, the time it may take for your exchanged product to reach you may vary.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are returning more expensive items, you may consider using a trackable shipping service or purchasing shipping insurance. We don’t guarantee that we will receive your returned item.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Need help?</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Contact us at {email} for questions related to refunds and returns.</p>\n<!-- /wp:paragraph -->', 'Refund and Returns Policy', '', 'publish', 'closed', 'closed', '', 'refund_returns', '', '', '2024-03-09 03:50:03', '2024-03-09 03:50:03', '', 0, 'http://localhost:82/?page_id=15', 0, 'page', '', 0),
(16, 0, '2024-03-08 12:21:02', '2024-03-08 12:21:02', '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"20px","bottom":"20px"}}},"backgroundColor":"base","layout":{"type":"constrained"}} -->\n<div class="wp-block-group alignwide has-base-background-color has-background" style="padding-top:20px;padding-bottom:20px">\n	<!-- wp:group {"align":"wide","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->\n	<div class="wp-block-group alignwide">\n		<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}},"layout":{"type":"flex"}} -->\n		<div class="wp-block-group">\n			<!-- wp:site-logo {"width":60} /-->\n\n			<!-- wp:group {"style":{"spacing":{"blockGap":"0px"}}} -->\n			<div class="wp-block-group">\n				<!-- wp:site-title {"level":0} /-->\n			</div>\n			<!-- /wp:group -->\n		</div>\n		<!-- /wp:group -->\n\n		<!-- wp:navigation {"layout":{"type":"flex","justifyContent":"right","orientation":"horizontal"},"style":{"spacing":{"margin":{"top":"0"},"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}}} /--><!-- wp:woocommerce/mini-cart /-->\n	</div>\n	<!-- /wp:group -->\n</div>\n<!-- /wp:group -->\n			<!-- wp:group {"layout":{"inherit":true,"type":"constrained"}} -->\n				<div class="wp-block-group"><!-- wp:woocommerce/page-content-wrapper {"page":"cart"} -->\n				<!-- wp:post-title {"align":"wide","level":1} /-->\n				<!-- wp:post-content {"align":"wide"} /-->\n				<!-- /wp:woocommerce/page-content-wrapper --></div>\n			<!-- /wp:group -->\n		<!-- wp:pattern {"slug":"twentytwentyfour/footer"} /-->\n', '', '', 'publish', 'closed', 'closed', '', 'page-cart', '', '', '2024-03-08 12:21:02', '2024-03-08 12:21:02', '', 0, 'http://localhost:82/page-cart/', 0, 'wp_template', '', 0),
(17, 0, '2024-03-08 12:21:02', '2024-03-08 12:21:02', '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"20px","bottom":"20px"}}},"backgroundColor":"base","layout":{"type":"constrained"}} -->\n<div class="wp-block-group alignwide has-base-background-color has-background" style="padding-top:20px;padding-bottom:20px">\n	<!-- wp:group {"align":"wide","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->\n	<div class="wp-block-group alignwide">\n		<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}},"layout":{"type":"flex"}} -->\n		<div class="wp-block-group">\n			<!-- wp:site-logo {"width":60} /-->\n\n			<!-- wp:group {"style":{"spacing":{"blockGap":"0px"}}} -->\n			<div class="wp-block-group">\n				<!-- wp:site-title {"level":0} /-->\n			</div>\n			<!-- /wp:group -->\n		</div>\n		<!-- /wp:group -->\n\n		<!-- wp:navigation {"layout":{"type":"flex","justifyContent":"right","orientation":"horizontal"},"style":{"spacing":{"margin":{"top":"0"},"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}}} /--><!-- wp:woocommerce/mini-cart /-->\n	</div>\n	<!-- /wp:group -->\n</div>\n<!-- /wp:group -->\n			<!-- wp:group {"layout":{"inherit":true,"type":"constrained"}} -->\n				<div class="wp-block-group"><!-- wp:woocommerce/page-content-wrapper {"page":"checkout"} -->\n				<!-- wp:post-title {"align":"wide","level":1} /-->\n				<!-- wp:post-content {"align":"wide"} /-->\n				<!-- /wp:woocommerce/page-content-wrapper --></div>\n			<!-- /wp:group -->\n		<!-- wp:pattern {"slug":"twentytwentyfour/footer"} /-->\n', '', '', 'publish', 'closed', 'closed', '', 'page-checkout', '', '', '2024-03-08 12:21:02', '2024-03-08 12:21:02', '', 0, 'http://localhost:82/page-checkout/', 0, 'wp_template', '', 0),
(18, 1, '2024-03-08 13:12:53', '2024-03-08 13:12:53', 'http://localhost:82/wp-content/uploads/2024/03/Divi-Engine-WooCommerce-Sample-Products.csv', 'Divi-Engine-WooCommerce-Sample-Products.csv', '', 'private', 'open', 'closed', '', 'divi-engine-woocommerce-sample-products-csv', '', '', '2024-03-08 13:12:53', '2024-03-08 13:12:53', '', 0, 'http://localhost:82/wp-content/uploads/2024/03/Divi-Engine-WooCommerce-Sample-Products.csv', 0, 'attachment', 'text/csv', 0),
(19, 1, '2024-03-08 13:17:11', '2024-03-08 13:17:11', 'http://localhost:82/wp-content/uploads/2024/03/Divi-Engine-WooCommerce-Sample-Products-1.csv', 'Divi-Engine-WooCommerce-Sample-Products-1.csv', '', 'private', 'open', 'closed', '', 'divi-engine-woocommerce-sample-products-1-csv', '', '', '2024-03-08 13:17:11', '2024-03-08 13:17:11', '', 0, 'http://localhost:82/wp-content/uploads/2024/03/Divi-Engine-WooCommerce-Sample-Products-1.csv', 0, 'attachment', 'text/csv', 0),
(20, 1, '2024-03-08 13:17:31', '2024-03-08 13:17:31', '', 'Divi Engine String Bag (Big Logo)', 'This fashionable string bag is made of 100% cotton. It is the perfect size for carrying your everyday essentials.', 'publish', 'open', 'closed', '', 'divi-engine-string-bag-big-logo', '', '', '2024-03-08 13:17:39', '2024-03-08 13:17:39', '', 0, 'http://localhost:82/?post_type=product&#038;p=20', 0, 'product', '', 0),
(21, 1, '2024-03-08 13:17:31', '2024-03-08 13:17:31', '', 'Divi Engine String Bag (Small Logos)', 'This fashionable string bag is made of 100% cotton. It is the perfect size for carrying your everyday essentials.', 'publish', 'open', 'closed', '', 'divi-engine-string-bag-small-logos', '', '', '2024-03-08 13:17:45', '2024-03-08 13:17:45', '', 0, 'http://localhost:82/?post_type=product&#038;p=21', 0, 'product', '', 0),
(22, 1, '2024-03-08 13:17:31', '2024-03-08 13:17:31', '', 'Brand Buttons', 'Represent your favorite CMS, eCommerce Platform, Website Builder, or Plugin Company in style with a cool pin.', 'publish', 'open', 'closed', '', 'brand-buttons', '', '', '2024-03-08 13:17:58', '2024-03-08 13:17:58', '', 0, 'http://localhost:82/?post_type=product&#038;p=22', 0, 'product', '', 0),
(23, 1, '2024-03-08 13:17:31', '2024-03-08 13:17:31', '', 'Brand Buttons - Divi', 'Brand: Divi', 'publish', 'closed', 'closed', '', 'brand-buttons-divi', '', '', '2024-03-08 13:17:48', '2024-03-08 13:17:48', '', 22, 'http://localhost:82/?post_type=product&#038;p=23', 1, 'product_variation', '', 0),
(24, 1, '2024-03-08 13:17:31', '2024-03-08 13:17:31', '', 'Brand Buttons - Divi Engine', 'Brand: Divi Engine', 'publish', 'closed', 'closed', '', 'brand-buttons-divi-engine', '', '', '2024-03-08 13:17:48', '2024-03-08 13:17:48', '', 22, 'http://localhost:82/?post_type=product&#038;p=24', 2, 'product_variation', '', 0),
(25, 1, '2024-03-08 13:17:32', '2024-03-08 13:17:32', '', 'Brand Buttons - WooCommerce', 'Brand: WooCommerce', 'publish', 'closed', 'closed', '', 'brand-buttons-woocommerce', '', '', '2024-03-08 13:17:49', '2024-03-08 13:17:49', '', 22, 'http://localhost:82/?post_type=product&#038;p=25', 3, 'product_variation', '', 0),
(26, 1, '2024-03-08 13:17:32', '2024-03-08 13:17:32', '', 'Brand Buttons - WordPress', 'Brand: WordPress', 'publish', 'closed', 'closed', '', 'brand-buttons-wordpress', '', '', '2024-03-08 13:17:52', '2024-03-08 13:17:52', '', 22, 'http://localhost:82/?post_type=product&#038;p=26', 4, 'product_variation', '', 0),
(27, 1, '2024-03-08 13:17:32', '2024-03-08 13:17:32', '', 'Lanyard', 'Stop losing your important access keys with a lanyard that is ALMOST as reliable as Divi Engine plugins!', 'publish', 'open', 'closed', '', 'lanyard', '', '', '2024-03-08 13:17:53', '2024-03-08 13:17:53', '', 0, 'http://localhost:82/?post_type=product&#038;p=27', 0, 'product', '', 0),
(28, 1, '2024-03-08 13:17:32', '2024-03-08 13:17:32', '', 'Divi Engine Tee', 'This comfortable cotton t-shirt that features the Divi Engine logo on the front is perfect for any occasion. The shirt is available in three colors.', 'publish', 'open', 'closed', '', 'divi-engine-tee', '', '', '2024-03-08 13:18:19', '2024-03-08 13:18:19', '', 0, 'http://localhost:82/?post_type=product&#038;p=28', 0, 'product', '', 0),
(29, 1, '2024-03-08 13:17:32', '2024-03-08 13:17:32', '', 'Divi Engine Tee - Blue, Large', 'Color: Blue, Size: Large', 'publish', 'closed', 'closed', '', 'divi-engine-tee-blue-large', '', '', '2024-03-08 13:18:03', '2024-03-08 13:18:03', '', 28, 'http://localhost:82/?post_type=product&#038;p=29', 1, 'product_variation', '', 0),
(30, 1, '2024-03-08 13:17:32', '2024-03-08 13:17:32', '', 'Divi Engine Tee - White, Large', 'Color: White, Size: Large', 'publish', 'closed', 'closed', '', 'divi-engine-tee-white-large', '', '', '2024-03-08 13:18:03', '2024-03-08 13:18:03', '', 28, 'http://localhost:82/?post_type=product&#038;p=30', 2, 'product_variation', '', 0),
(31, 1, '2024-03-08 13:17:32', '2024-03-08 13:17:32', '', 'Divi Engine Tee - Yellow, Large', 'Color: Yellow, Size: Large', 'publish', 'closed', 'closed', '', 'divi-engine-tee-yellow-large', '', '', '2024-03-08 13:18:04', '2024-03-08 13:18:04', '', 28, 'http://localhost:82/?post_type=product&#038;p=31', 3, 'product_variation', '', 0),
(32, 1, '2024-03-08 13:17:32', '2024-03-08 13:17:32', '', 'Divi Engine Tee - Blue, Medium', 'Color: Blue, Size: Medium', 'publish', 'closed', 'closed', '', 'divi-engine-tee-blue-medium', '', '', '2024-03-08 13:18:04', '2024-03-08 13:18:04', '', 28, 'http://localhost:82/?post_type=product&#038;p=32', 4, 'product_variation', '', 0),
(33, 1, '2024-03-08 13:17:32', '2024-03-08 13:17:32', '', 'Divi Engine Tee - White, Medium', 'Color: White, Size: Medium', 'publish', 'closed', 'closed', '', 'divi-engine-tee-white-medium', '', '', '2024-03-08 13:18:04', '2024-03-08 13:18:04', '', 28, 'http://localhost:82/?post_type=product&#038;p=33', 5, 'product_variation', '', 0),
(34, 1, '2024-03-08 13:17:33', '2024-03-08 13:17:33', '', 'Divi Engine Tee - Yellow, Medium', 'Color: Yellow, Size: Medium', 'publish', 'closed', 'closed', '', 'divi-engine-tee-yellow-medium', '', '', '2024-03-08 13:18:04', '2024-03-08 13:18:04', '', 28, 'http://localhost:82/?post_type=product&#038;p=34', 6, 'product_variation', '', 0),
(35, 1, '2024-03-08 13:17:33', '2024-03-08 13:17:33', '', 'Divi Engine Tee - Blue, Small', 'Color: Blue, Size: Small', 'publish', 'closed', 'closed', '', 'divi-engine-tee-blue-small', '', '', '2024-03-08 13:18:04', '2024-03-08 13:18:04', '', 28, 'http://localhost:82/?post_type=product&#038;p=35', 7, 'product_variation', '', 0),
(36, 1, '2024-03-08 13:17:33', '2024-03-08 13:17:33', '', 'Divi Engine Tee - White, Small', 'Color: White, Size: Small', 'publish', 'closed', 'closed', '', 'divi-engine-tee-white-small', '', '', '2024-03-08 13:18:04', '2024-03-08 13:18:04', '', 28, 'http://localhost:82/?post_type=product&#038;p=36', 8, 'product_variation', '', 0),
(37, 1, '2024-03-08 13:17:33', '2024-03-08 13:17:33', '', 'Divi Engine Tee - Yellow, Small', 'Color: Yellow, Size: Small', 'publish', 'closed', 'closed', '', 'divi-engine-tee-yellow-small', '', '', '2024-03-08 13:18:04', '2024-03-08 13:18:04', '', 28, 'http://localhost:82/?post_type=product&#038;p=37', 9, 'product_variation', '', 0),
(38, 1, '2024-03-08 13:17:33', '2024-03-08 13:17:33', '', 'Divi Tee', 'This comfortable cotton t-shirt features the Divi logo on the front and back. It is the perfect tee for any occasion.', 'publish', 'open', 'closed', '', 'divi-tee', '', '', '2024-03-08 13:18:19', '2024-03-08 13:18:19', '', 0, 'http://localhost:82/?post_type=product&#038;p=38', 0, 'product', '', 0),
(39, 1, '2024-03-08 13:17:33', '2024-03-08 13:17:33', '', 'Divi Tee - Large', 'Size: Large', 'publish', 'closed', 'closed', '', 'divi-tee-large', '', '', '2024-03-08 13:18:07', '2024-03-08 13:18:07', '', 38, 'http://localhost:82/?post_type=product&#038;p=39', 1, 'product_variation', '', 0),
(40, 1, '2024-03-08 13:17:33', '2024-03-08 13:17:33', '', 'Divi Tee - Medium', 'Size: Medium', 'publish', 'closed', 'closed', '', 'divi-tee-medium', '', '', '2024-03-08 13:18:07', '2024-03-08 13:18:07', '', 38, 'http://localhost:82/?post_type=product&#038;p=40', 2, 'product_variation', '', 0),
(41, 1, '2024-03-08 13:17:33', '2024-03-08 13:17:33', '', 'Divi Tee - Small', 'Size: Small', 'publish', 'closed', 'closed', '', 'divi-tee-small', '', '', '2024-03-08 13:18:08', '2024-03-08 13:18:08', '', 38, 'http://localhost:82/?post_type=product&#038;p=41', 3, 'product_variation', '', 0),
(42, 1, '2024-03-08 13:17:33', '2024-03-08 13:17:33', '', 'WordPress Tee', 'This comfortable cotton t-shirt features the WordPress logo on the front and back. It is the perfect tee for any occasion.', 'publish', 'open', 'closed', '', 'wordpress-tee', '', '', '2024-03-08 13:18:19', '2024-03-08 13:18:19', '', 0, 'http://localhost:82/?post_type=product&#038;p=42', 0, 'product', '', 0),
(43, 1, '2024-03-08 13:17:33', '2024-03-08 13:17:33', '', 'WordPress Tee - Large', 'Size: Large', 'publish', 'closed', 'closed', '', 'wordpress-tee-large', '', '', '2024-03-08 13:18:11', '2024-03-08 13:18:11', '', 42, 'http://localhost:82/?post_type=product&#038;p=43', 1, 'product_variation', '', 0),
(44, 1, '2024-03-08 13:17:34', '2024-03-08 13:17:34', '', 'WordPress Tee - Medium', 'Size: Medium', 'publish', 'closed', 'closed', '', 'wordpress-tee-medium', '', '', '2024-03-08 13:18:11', '2024-03-08 13:18:11', '', 42, 'http://localhost:82/?post_type=product&#038;p=44', 2, 'product_variation', '', 0),
(45, 1, '2024-03-08 13:17:34', '2024-03-08 13:17:34', '', 'WordPress Tee - Small', 'Size: Small', 'publish', 'closed', 'closed', '', 'wordpress-tee-small', '', '', '2024-03-08 13:18:11', '2024-03-08 13:18:11', '', 42, 'http://localhost:82/?post_type=product&#038;p=45', 3, 'product_variation', '', 0),
(46, 1, '2024-03-08 13:17:34', '2024-03-08 13:17:34', '', 'Mens Divi Hoodie', 'This Divi hoodie is a must have for any Divi fan. It is made from a soft, comfortable, and durable cotton blend. The hoodie is a perfect way to stay warm and show your Divi pride.', 'publish', 'open', 'closed', '', 'mens-divi-hoodie', '', '', '2024-03-08 13:18:19', '2024-03-08 13:18:19', '', 0, 'http://localhost:82/?post_type=product&#038;p=46', 0, 'product', '', 0),
(47, 1, '2024-03-08 13:17:34', '2024-03-08 13:17:34', '', 'Mens Divi Hoodie - Large', 'Size: Large', 'publish', 'closed', 'closed', '', 'mens-divi-hoodie-large', '', '', '2024-03-08 13:18:13', '2024-03-08 13:18:13', '', 46, 'http://localhost:82/?post_type=product&#038;p=47', 1, 'product_variation', '', 0),
(48, 1, '2024-03-08 13:17:34', '2024-03-08 13:17:34', '', 'Mens Divi Hoodie - Medium', 'Size: Medium', 'publish', 'closed', 'closed', '', 'mens-divi-hoodie-medium', '', '', '2024-03-08 13:18:13', '2024-03-08 13:18:13', '', 46, 'http://localhost:82/?post_type=product&#038;p=48', 2, 'product_variation', '', 0),
(49, 1, '2024-03-08 13:17:34', '2024-03-08 13:17:34', '', 'Mens Divi Hoodie - Small', 'Size: Small', 'publish', 'closed', 'closed', '', 'mens-divi-hoodie-small', '', '', '2024-03-08 13:18:13', '2024-03-08 13:18:13', '', 46, 'http://localhost:82/?post_type=product&#038;p=49', 3, 'product_variation', '', 0),
(50, 1, '2024-03-08 13:17:35', '2024-03-08 13:17:35', '', 'Bag1.jpg', '', 'inherit', 'open', 'closed', '', 'bag1-jpg', '', '', '2024-03-08 13:17:35', '2024-03-08 13:17:35', '', 20, 'http://localhost:82/wp-content/uploads/2024/03/Bag1.jpg', 0, 'attachment', 'image/jpeg', 0),
(51, 1, '2024-03-08 13:17:37', '2024-03-08 13:17:37', '', 'Bag1-1.jpg', '', 'inherit', 'open', 'closed', '', 'bag1-1-jpg', '', '', '2024-03-08 13:17:37', '2024-03-08 13:17:37', '', 20, 'http://localhost:82/wp-content/uploads/2024/03/Bag1-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2024-03-08 13:17:38', '2024-03-08 13:17:38', '', 'Bag1-2.jpg', '', 'inherit', 'open', 'closed', '', 'bag1-2-jpg', '', '', '2024-03-08 13:17:38', '2024-03-08 13:17:38', '', 20, 'http://localhost:82/wp-content/uploads/2024/03/Bag1-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2024-03-08 13:17:41', '2024-03-08 13:17:41', '', 'Bag2.jpg', '', 'inherit', 'open', 'closed', '', 'bag2-jpg', '', '', '2024-03-08 13:17:41', '2024-03-08 13:17:41', '', 21, 'http://localhost:82/wp-content/uploads/2024/03/Bag2.jpg', 0, 'attachment', 'image/jpeg', 0),
(54, 1, '2024-03-08 13:17:42', '2024-03-08 13:17:42', '', 'Bag2-1.jpg', '', 'inherit', 'open', 'closed', '', 'bag2-1-jpg', '', '', '2024-03-08 13:17:42', '2024-03-08 13:17:42', '', 21, 'http://localhost:82/wp-content/uploads/2024/03/Bag2-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2024-03-08 13:17:44', '2024-03-08 13:17:44', '', 'Bag2-2.jpg', '', 'inherit', 'open', 'closed', '', 'bag2-2-jpg', '', '', '2024-03-08 13:17:44', '2024-03-08 13:17:44', '', 21, 'http://localhost:82/wp-content/uploads/2024/03/Bag2-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(56, 1, '2024-03-08 13:17:45', '2024-03-08 13:17:45', '', 'DE-Pins-4.jpg', '', 'inherit', 'open', 'closed', '', 'de-pins-4-jpg', '', '', '2024-03-08 13:17:45', '2024-03-08 13:17:45', '', 22, 'http://localhost:82/wp-content/uploads/2024/03/DE-Pins-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(57, 1, '2024-03-08 13:17:47', '2024-03-08 13:17:47', '', 'DE-Pins-1.jpg', '', 'inherit', 'open', 'closed', '', 'de-pins-1-jpg', '', '', '2024-03-08 13:17:47', '2024-03-08 13:17:47', '', 23, 'http://localhost:82/wp-content/uploads/2024/03/DE-Pins-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(58, 1, '2024-03-08 13:17:48', '2024-03-08 13:17:48', '', 'DE-Pins-2.jpg', '', 'inherit', 'open', 'closed', '', 'de-pins-2-jpg', '', '', '2024-03-08 13:17:48', '2024-03-08 13:17:48', '', 25, 'http://localhost:82/wp-content/uploads/2024/03/DE-Pins-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(59, 1, '2024-03-08 13:17:51', '2024-03-08 13:17:51', '', 'DE-Pins-3.jpg', '', 'inherit', 'open', 'closed', '', 'de-pins-3-jpg', '', '', '2024-03-08 13:17:51', '2024-03-08 13:17:51', '', 26, 'http://localhost:82/wp-content/uploads/2024/03/DE-Pins-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2024-03-08 13:17:52', '2024-03-08 13:17:52', '', 'Lanyard1.jpg', '', 'inherit', 'open', 'closed', '', 'lanyard1-jpg', '', '', '2024-03-08 13:17:52', '2024-03-08 13:17:52', '', 27, 'http://localhost:82/wp-content/uploads/2024/03/Lanyard1.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2024-03-08 13:17:54', '2024-03-08 13:17:54', '', 'Shirt-3-yellow-front.jpg', '', 'inherit', 'open', 'closed', '', 'shirt-3-yellow-front-jpg', '', '', '2024-03-08 13:17:54', '2024-03-08 13:17:54', '', 28, 'http://localhost:82/wp-content/uploads/2024/03/Shirt-3-yellow-front.jpg', 0, 'attachment', 'image/jpeg', 0),
(62, 1, '2024-03-08 13:17:56', '2024-03-08 13:17:56', '', 'Shirt-3-blue-front.jpg', '', 'inherit', 'open', 'closed', '', 'shirt-3-blue-front-jpg', '', '', '2024-03-08 13:17:56', '2024-03-08 13:17:56', '', 28, 'http://localhost:82/wp-content/uploads/2024/03/Shirt-3-blue-front.jpg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2024-03-08 13:17:57', '2024-03-08 13:17:57', '', 'Shirt-3-white-front.jpg', '', 'inherit', 'open', 'closed', '', 'shirt-3-white-front-jpg', '', '', '2024-03-08 13:17:57', '2024-03-08 13:17:57', '', 28, 'http://localhost:82/wp-content/uploads/2024/03/Shirt-3-white-front.jpg', 0, 'attachment', 'image/jpeg', 0),
(64, 1, '2024-03-08 13:18:02', '2024-03-08 13:18:02', '', 'Dat Divi Engine Life Hoodie - Limited Edition', 'This Divi Engine hoodie is a must have for any Divi Engine fan. It is made from a soft, comfortable, and durable cotton blend. The hoodie is a perfect way to stay warm and show your Divi Engine pride.', 'publish', 'open', 'closed', '', 'dat-divi-engine-life-hoodie-limited-edition', '', '', '2024-03-08 13:18:19', '2024-03-08 13:18:19', '', 0, 'http://localhost:82/?post_type=product&#038;p=64', 0, 'product', '', 0),
(65, 1, '2024-03-08 13:18:02', '2024-03-08 13:18:02', '', 'Dat Divi Engine Life Hoodie - Limited Edition - Large', 'Size: Large', 'publish', 'closed', 'closed', '', 'dat-divi-engine-life-hoodie-limited-edition-large', '', '', '2024-03-08 13:18:15', '2024-03-08 13:18:15', '', 64, 'http://localhost:82/?post_type=product&#038;p=65', 1, 'product_variation', '', 0),
(66, 1, '2024-03-08 13:18:02', '2024-03-08 13:18:02', '', 'Dat Divi Engine Life Hoodie - Limited Edition - Medium', 'Size: Medium', 'publish', 'closed', 'closed', '', 'dat-divi-engine-life-hoodie-limited-edition-medium', '', '', '2024-03-08 13:18:15', '2024-03-08 13:18:15', '', 64, 'http://localhost:82/?post_type=product&#038;p=66', 2, 'product_variation', '', 0),
(67, 1, '2024-03-08 13:18:02', '2024-03-08 13:18:02', '', 'Dat Divi Engine Life Hoodie - Limited Edition - Small', 'Size: Small', 'publish', 'closed', 'closed', '', 'dat-divi-engine-life-hoodie-limited-edition-small', '', '', '2024-03-08 13:18:15', '2024-03-08 13:18:15', '', 64, 'http://localhost:82/?post_type=product&#038;p=67', 3, 'product_variation', '', 0),
(68, 1, '2024-03-08 13:18:03', '2024-03-08 13:18:03', '', 'Mens WordPress Hoodie', 'This WordPress hoodie is a must have for any WordPress fan. It is made from a soft, comfortable, and durable cotton blend. The hoodie is a perfect way to stay warm and show your WordPress pride.', 'publish', 'open', 'closed', '', 'mens-wordpress-hoodie', '', '', '2024-03-08 13:18:19', '2024-03-08 13:18:19', '', 0, 'http://localhost:82/?post_type=product&#038;p=68', 0, 'product', '', 0),
(69, 1, '2024-03-08 13:18:03', '2024-03-08 13:18:03', '', 'Mens WordPress Hoodie - Large', 'Size: Large', 'publish', 'closed', 'closed', '', 'mens-wordpress-hoodie-large', '', '', '2024-03-08 13:18:17', '2024-03-08 13:18:17', '', 68, 'http://localhost:82/?post_type=product&#038;p=69', 1, 'product_variation', '', 0),
(70, 1, '2024-03-08 13:18:03', '2024-03-08 13:18:03', '', 'Mens WordPress Hoodie - Medium', 'Size: Medium', 'publish', 'closed', 'closed', '', 'mens-wordpress-hoodie-medium', '', '', '2024-03-08 13:18:17', '2024-03-08 13:18:17', '', 68, 'http://localhost:82/?post_type=product&#038;p=70', 2, 'product_variation', '', 0),
(71, 1, '2024-03-08 13:18:03', '2024-03-08 13:18:03', '', 'Mens WordPress Hoodie - Small', 'Size: Small', 'publish', 'closed', 'closed', '', 'mens-wordpress-hoodie-small', '', '', '2024-03-08 13:18:17', '2024-03-08 13:18:17', '', 68, 'http://localhost:82/?post_type=product&#038;p=71', 3, 'product_variation', '', 0),
(72, 1, '2024-03-08 13:18:03', '2024-03-08 13:18:03', '', 'Divi Engine Logo Zipper Hoodie', 'This Divi Engine hoodie is a must have for any Divi Engine fan. It is made from a soft, comfortable, and durable cotton blend. The hoodie is a perfect way to stay warm and show your Divi Engine pride.', 'publish', 'open', 'closed', '', 'divi-engine-logo-zipper-hoodie', '', '', '2024-03-08 13:18:46', '2024-03-08 13:18:46', '', 0, 'http://localhost:82/?post_type=product&#038;p=72', 0, 'product', '', 0),
(73, 1, '2024-03-08 13:18:05', '2024-03-08 13:18:05', '', 'Shirt-2-front.jpg', '', 'inherit', 'open', 'closed', '', 'shirt-2-front-jpg', '', '', '2024-03-08 13:18:05', '2024-03-08 13:18:05', '', 38, 'http://localhost:82/wp-content/uploads/2024/03/Shirt-2-front.jpg', 0, 'attachment', 'image/jpeg', 0),
(74, 1, '2024-03-08 13:18:06', '2024-03-08 13:18:06', '', 'Shirt-2-back.jpg', '', 'inherit', 'open', 'closed', '', 'shirt-2-back-jpg', '', '', '2024-03-08 13:18:06', '2024-03-08 13:18:06', '', 38, 'http://localhost:82/wp-content/uploads/2024/03/Shirt-2-back.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2024-03-08 13:18:08', '2024-03-08 13:18:08', '', 'Shirt-1-front.jpg', '', 'inherit', 'open', 'closed', '', 'shirt-1-front-jpg', '', '', '2024-03-08 13:18:08', '2024-03-08 13:18:08', '', 42, 'http://localhost:82/wp-content/uploads/2024/03/Shirt-1-front.jpg', 0, 'attachment', 'image/jpeg', 0),
(76, 1, '2024-03-08 13:18:10', '2024-03-08 13:18:10', '', 'Shirt-1-back.jpg', '', 'inherit', 'open', 'closed', '', 'shirt-1-back-jpg', '', '', '2024-03-08 13:18:10', '2024-03-08 13:18:10', '', 42, 'http://localhost:82/wp-content/uploads/2024/03/Shirt-1-back.jpg', 0, 'attachment', 'image/jpeg', 0),
(77, 1, '2024-03-08 13:18:12', '2024-03-08 13:18:12', '', 'Hoodie-2.jpg', '', 'inherit', 'open', 'closed', '', 'hoodie-2-jpg', '', '', '2024-03-08 13:18:12', '2024-03-08 13:18:12', '', 46, 'http://localhost:82/wp-content/uploads/2024/03/Hoodie-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(78, 1, '2024-03-08 13:18:14', '2024-03-08 13:18:14', '', 'Hoodie-1.jpg', '', 'inherit', 'open', 'closed', '', 'hoodie-1-jpg', '', '', '2024-03-08 13:18:14', '2024-03-08 13:18:14', '', 64, 'http://localhost:82/wp-content/uploads/2024/03/Hoodie-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(79, 1, '2024-03-08 13:18:16', '2024-03-08 13:18:16', '', 'Hoodie-3.jpg', '', 'inherit', 'open', 'closed', '', 'hoodie-3-jpg', '', '', '2024-03-08 13:18:16', '2024-03-08 13:18:16', '', 68, 'http://localhost:82/wp-content/uploads/2024/03/Hoodie-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(80, 1, '2024-03-08 13:18:18', '2024-03-08 13:18:18', '', 'Hoodie-Women-1.jpg', '', 'inherit', 'open', 'closed', '', 'hoodie-women-1-jpg', '', '', '2024-03-08 13:18:18', '2024-03-08 13:18:18', '', 72, 'http://localhost:82/wp-content/uploads/2024/03/Hoodie-Women-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(81, 1, '2024-03-08 13:18:26', '2024-03-08 13:18:26', '', 'Divi Engine Logo Zipper Hoodie - Large', 'Size: Large', 'publish', 'closed', 'closed', '', 'divi-engine-logo-zipper-hoodie-large', '', '', '2024-03-08 13:18:30', '2024-03-08 13:18:30', '', 72, 'http://localhost:82/?post_type=product&#038;p=81', 1, 'product_variation', '', 0),
(82, 1, '2024-03-08 13:18:26', '2024-03-08 13:18:26', '', 'Divi Engine Logo Zipper Hoodie - Medium', 'Size: Medium', 'publish', 'closed', 'closed', '', 'divi-engine-logo-zipper-hoodie-medium', '', '', '2024-03-08 13:18:30', '2024-03-08 13:18:30', '', 72, 'http://localhost:82/?post_type=product&#038;p=82', 2, 'product_variation', '', 0),
(83, 1, '2024-03-08 13:18:27', '2024-03-08 13:18:27', '', 'Divi Engine Logo Zipper Hoodie - Small', 'Size: Small', 'publish', 'closed', 'closed', '', 'divi-engine-logo-zipper-hoodie-small', '', '', '2024-03-08 13:18:30', '2024-03-08 13:18:30', '', 72, 'http://localhost:82/?post_type=product&#038;p=83', 3, 'product_variation', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(84, 1, '2024-03-08 13:18:27', '2024-03-08 13:18:27', '', 'Purple Divi Engine Text Zipper Hoodie', 'This Divi Engine hoodie is a must have for any Divi Engine fan. It is made from a soft, comfortable, and durable cotton blend. The hoodie is a perfect way to stay warm and show your Divi Engine pride.', 'publish', 'open', 'closed', '', 'purple-divi-engine-text-zipper-hoodie', '', '', '2024-03-08 13:18:46', '2024-03-08 13:18:46', '', 0, 'http://localhost:82/?post_type=product&#038;p=84', 0, 'product', '', 0),
(85, 1, '2024-03-08 13:18:27', '2024-03-08 13:18:27', '', 'Purple Divi Engine Text Zipper Hoodie - Large', 'Size: Large', 'publish', 'closed', 'closed', '', 'purple-divi-engine-text-zipper-hoodie-large', '', '', '2024-03-08 13:18:32', '2024-03-08 13:18:32', '', 84, 'http://localhost:82/?post_type=product&#038;p=85', 1, 'product_variation', '', 0),
(86, 1, '2024-03-08 13:18:27', '2024-03-08 13:18:27', '', 'Purple Divi Engine Text Zipper Hoodie - Medium', 'Size: Medium', 'publish', 'closed', 'closed', '', 'purple-divi-engine-text-zipper-hoodie-medium', '', '', '2024-03-08 13:18:32', '2024-03-08 13:18:32', '', 84, 'http://localhost:82/?post_type=product&#038;p=86', 2, 'product_variation', '', 0),
(87, 1, '2024-03-08 13:18:27', '2024-03-08 13:18:27', '', 'Purple Divi Engine Text Zipper Hoodie - Small', 'Size: Small', 'publish', 'closed', 'closed', '', 'purple-divi-engine-text-zipper-hoodie-small', '', '', '2024-03-08 13:18:32', '2024-03-08 13:18:32', '', 84, 'http://localhost:82/?post_type=product&#038;p=87', 3, 'product_variation', '', 0),
(88, 1, '2024-03-08 13:18:27', '2024-03-08 13:18:27', '', 'WooCommerce "Gimme the Money" Zipper Hoodie', 'This WooCommerce hoodie is a must have for any WooCommerce fan. It is made from a soft, comfortable, and durable cotton blend. The hoodie is a perfect way to stay warm and show your WooCommerce pride.', 'publish', 'open', 'closed', '', 'woocommerce-gimme-the-money-zipper-hoodie', '', '', '2024-03-08 13:18:46', '2024-03-08 13:18:46', '', 0, 'http://localhost:82/?post_type=product&#038;p=88', 0, 'product', '', 0),
(89, 1, '2024-03-08 13:18:27', '2024-03-08 13:18:27', '', 'WooCommerce "Gimme the Money" Zipper Hoodie - Large', 'Size: Large', 'publish', 'closed', 'closed', '', 'woocommerce-gimme-the-money-zipper-hoodie-large', '', '', '2024-03-08 13:18:34', '2024-03-08 13:18:34', '', 88, 'http://localhost:82/?post_type=product&#038;p=89', 1, 'product_variation', '', 0),
(90, 1, '2024-03-08 13:18:27', '2024-03-08 13:18:27', '', 'WooCommerce "Gimme the Money" Zipper Hoodie - Medium', 'Size: Medium', 'publish', 'closed', 'closed', '', 'woocommerce-gimme-the-money-zipper-hoodie-medium', '', '', '2024-03-08 13:18:34', '2024-03-08 13:18:34', '', 88, 'http://localhost:82/?post_type=product&#038;p=90', 2, 'product_variation', '', 0),
(91, 1, '2024-03-08 13:18:28', '2024-03-08 13:18:28', '', 'WooCommerce "Gimme the Money" Zipper Hoodie - Small', 'Size: Small', 'publish', 'closed', 'closed', '', 'woocommerce-gimme-the-money-zipper-hoodie-small', '', '', '2024-03-08 13:18:34', '2024-03-08 13:18:34', '', 88, 'http://localhost:82/?post_type=product&#038;p=91', 3, 'product_variation', '', 0),
(92, 1, '2024-03-08 13:18:28', '2024-03-08 13:18:28', '', 'Divi Ninja Tee', 'This comfortable cotton t-shirt features the Divi logo on the front and expresses your Ninja status with the theme. It is the perfect tee for any occasion.', 'publish', 'open', 'closed', '', 'divi-ninja-tee', '', '', '2024-03-08 13:18:46', '2024-03-08 13:18:46', '', 0, 'http://localhost:82/?post_type=product&#038;p=92', 0, 'product', '', 0),
(93, 1, '2024-03-08 13:18:28', '2024-03-08 13:18:28', '', 'Divi Ninja Tee - Large', 'Size: Large', 'publish', 'closed', 'closed', '', 'divi-ninja-tee-large', '', '', '2024-03-08 13:18:36', '2024-03-08 13:18:36', '', 92, 'http://localhost:82/?post_type=product&#038;p=93', 1, 'product_variation', '', 0),
(94, 1, '2024-03-08 13:18:28', '2024-03-08 13:18:28', '', 'Divi Ninja Tee - Medium', 'Size: Medium', 'publish', 'closed', 'closed', '', 'divi-ninja-tee-medium', '', '', '2024-03-08 13:18:36', '2024-03-08 13:18:36', '', 92, 'http://localhost:82/?post_type=product&#038;p=94', 2, 'product_variation', '', 0),
(95, 1, '2024-03-08 13:18:28', '2024-03-08 13:18:28', '', 'Divi Ninja Tee - Small', 'Size: Small', 'publish', 'closed', 'closed', '', 'divi-ninja-tee-small', '', '', '2024-03-08 13:18:36', '2024-03-08 13:18:36', '', 92, 'http://localhost:82/?post_type=product&#038;p=95', 3, 'product_variation', '', 0),
(96, 1, '2024-03-08 13:18:28', '2024-03-08 13:18:28', '', 'Divi Simplified Crop-top', 'This comfortable cotton crop-top features the Divi and Divi Engine logos on the front and back. It is the perfect tee for any occasion.', 'publish', 'open', 'closed', '', 'divi-simplified-crop-top', '', '', '2024-03-08 13:18:46', '2024-03-08 13:18:46', '', 0, 'http://localhost:82/?post_type=product&#038;p=96', 0, 'product', '', 0),
(97, 1, '2024-03-08 13:18:28', '2024-03-08 13:18:28', '', 'Dat Divi Engine Life Crop-top (3-Tone)', 'This comfortable cotton crop-top features the Divi Engine logo on the front expressing how easy "data Divi Engine life" is. It is the perfect tee for any occasion.', 'publish', 'open', 'closed', '', 'dat-divi-engine-life-crop-top-3-tone', '', '', '2024-03-08 13:18:46', '2024-03-08 13:18:46', '', 0, 'http://localhost:82/?post_type=product&#038;p=97', 0, 'product', '', 0),
(98, 1, '2024-03-08 13:18:28', '2024-03-08 13:18:28', '', 'Dat Divi Engine Life Crop-top (3-Tone) - Large', 'Size: Large', 'publish', 'closed', 'closed', '', 'dat-divi-engine-life-crop-top-3-tone-large', '', '', '2024-03-08 13:18:45', '2024-03-08 13:18:45', '', 97, 'http://localhost:82/?post_type=product&#038;p=98', 1, 'product_variation', '', 0),
(99, 1, '2024-03-08 13:18:28', '2024-03-08 13:18:28', '', 'Dat Divi Engine Life Crop-top (3-Tone) - Medium', 'Size: Medium', 'publish', 'closed', 'closed', '', 'dat-divi-engine-life-crop-top-3-tone-medium', '', '', '2024-03-08 13:18:45', '2024-03-08 13:18:45', '', 97, 'http://localhost:82/?post_type=product&#038;p=99', 2, 'product_variation', '', 0),
(100, 1, '2024-03-08 13:18:28', '2024-03-08 13:18:28', '', 'Dat Divi Engine Life Crop-top (3-Tone) - Small', 'Size: Small', 'publish', 'closed', 'closed', '', 'dat-divi-engine-life-crop-top-3-tone-small', '', '', '2024-03-08 13:18:45', '2024-03-08 13:18:45', '', 97, 'http://localhost:82/?post_type=product&#038;p=100', 3, 'product_variation', '', 0),
(101, 1, '2024-03-08 13:18:29', '2024-03-08 13:18:29', '', 'Divi Simplified Crop-top - Large, Blue', 'Size: Large, Color: Blue', 'publish', 'closed', 'closed', '', 'divi-simplified-crop-top-large-blue', '', '', '2024-03-08 13:18:45', '2024-03-08 13:18:45', '', 96, 'http://localhost:82/?post_type=product&#038;p=101', 1, 'product_variation', '', 0),
(102, 1, '2024-03-08 13:18:29', '2024-03-08 13:18:29', '', 'Divi Simplified Crop-top - Large, White', 'Size: Large, Color: White', 'publish', 'closed', 'closed', '', 'divi-simplified-crop-top-large-white', '', '', '2024-03-08 13:18:45', '2024-03-08 13:18:45', '', 96, 'http://localhost:82/?post_type=product&#038;p=102', 2, 'product_variation', '', 0),
(103, 1, '2024-03-08 13:18:29', '2024-03-08 13:18:29', '', 'Divi Simplified Crop-top - Large, Yellow', 'Size: Large, Color: Yellow', 'publish', 'closed', 'closed', '', 'divi-simplified-crop-top-large-yellow', '', '', '2024-03-08 13:18:45', '2024-03-08 13:18:45', '', 96, 'http://localhost:82/?post_type=product&#038;p=103', 3, 'product_variation', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(104, 1, '2024-03-08 13:18:29', '2024-03-08 13:18:29', '', 'Divi Simplified Crop-top - Medium, Blue', 'Size: Medium, Color: Blue', 'publish', 'closed', 'closed', '', 'divi-simplified-crop-top-medium-blue', '', '', '2024-03-08 13:18:46', '2024-03-08 13:18:46', '', 96, 'http://localhost:82/?post_type=product&#038;p=104', 4, 'product_variation', '', 0),
(105, 1, '2024-03-08 13:18:29', '2024-03-08 13:18:29', '', 'Divi Simplified Crop-top - Medium, White', 'Size: Medium, Color: White', 'publish', 'closed', 'closed', '', 'divi-simplified-crop-top-medium-white', '', '', '2024-03-08 13:18:46', '2024-03-08 13:18:46', '', 96, 'http://localhost:82/?post_type=product&#038;p=105', 5, 'product_variation', '', 0),
(106, 1, '2024-03-08 13:18:29', '2024-03-08 13:18:29', '', 'Divi Simplified Crop-top - Medium, Yellow', 'Size: Medium, Color: Yellow', 'publish', 'closed', 'closed', '', 'divi-simplified-crop-top-medium-yellow', '', '', '2024-03-08 13:18:46', '2024-03-08 13:18:46', '', 96, 'http://localhost:82/?post_type=product&#038;p=106', 6, 'product_variation', '', 0),
(107, 1, '2024-03-08 13:18:29', '2024-03-08 13:18:29', '', 'Divi Simplified Crop-top - Small, Blue', 'Size: Small, Color: Blue', 'publish', 'closed', 'closed', '', 'divi-simplified-crop-top-small-blue', '', '', '2024-03-08 13:18:46', '2024-03-08 13:18:46', '', 96, 'http://localhost:82/?post_type=product&#038;p=107', 7, 'product_variation', '', 0),
(108, 1, '2024-03-08 13:18:29', '2024-03-08 13:18:29', '', 'Divi Simplified Crop-top - Small, White', 'Size: Small, Color: White', 'publish', 'closed', 'closed', '', 'divi-simplified-crop-top-small-white', '', '', '2024-03-08 13:18:46', '2024-03-08 13:18:46', '', 96, 'http://localhost:82/?post_type=product&#038;p=108', 8, 'product_variation', '', 0),
(109, 1, '2024-03-08 13:18:29', '2024-03-08 13:18:29', '', 'Divi Simplified Crop-top - Small, Yellow', 'Size: Small, Color: Yellow', 'publish', 'closed', 'closed', '', 'divi-simplified-crop-top-small-yellow', '', '', '2024-03-08 13:18:46', '2024-03-08 13:18:46', '', 96, 'http://localhost:82/?post_type=product&#038;p=109', 9, 'product_variation', '', 0),
(110, 1, '2024-03-08 13:18:31', '2024-03-08 13:18:31', '', 'Hoodie-Women-2.jpg', '', 'inherit', 'open', 'closed', '', 'hoodie-women-2-jpg', '', '', '2024-03-08 13:18:31', '2024-03-08 13:18:31', '', 84, 'http://localhost:82/wp-content/uploads/2024/03/Hoodie-Women-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(111, 1, '2024-03-08 13:18:33', '2024-03-08 13:18:33', '', 'Hoodie-Women-3.jpg', '', 'inherit', 'open', 'closed', '', 'hoodie-women-3-jpg', '', '', '2024-03-08 13:18:33', '2024-03-08 13:18:33', '', 88, 'http://localhost:82/wp-content/uploads/2024/03/Hoodie-Women-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(112, 1, '2024-03-08 13:18:35', '2024-03-08 13:18:35', '', 'Divi-Ninja.jpg', '', 'inherit', 'open', 'closed', '', 'divi-ninja-jpg', '', '', '2024-03-08 13:18:35', '2024-03-08 13:18:35', '', 92, 'http://localhost:82/wp-content/uploads/2024/03/Divi-Ninja.jpg', 0, 'attachment', 'image/jpeg', 0),
(113, 1, '2024-03-08 13:18:36', '2024-03-08 13:18:36', '', 'divi-Simplified-croptop-white.jpg', '', 'inherit', 'open', 'closed', '', 'divi-simplified-croptop-white-jpg', '', '', '2024-03-08 13:18:36', '2024-03-08 13:18:36', '', 96, 'http://localhost:82/wp-content/uploads/2024/03/divi-Simplified-croptop-white.jpg', 0, 'attachment', 'image/jpeg', 0),
(114, 1, '2024-03-08 13:18:39', '2024-03-08 13:18:39', '', 'divi-Simplified-croptop-blue.jpg', '', 'inherit', 'open', 'closed', '', 'divi-simplified-croptop-blue-jpg', '', '', '2024-03-08 13:18:39', '2024-03-08 13:18:39', '', 96, 'http://localhost:82/wp-content/uploads/2024/03/divi-Simplified-croptop-blue.jpg', 0, 'attachment', 'image/jpeg', 0),
(115, 1, '2024-03-08 13:18:43', '2024-03-08 13:18:43', '', 'divi-Simplified-croptop-yellow.jpg', '', 'inherit', 'open', 'closed', '', 'divi-simplified-croptop-yellow-jpg', '', '', '2024-03-08 13:18:43', '2024-03-08 13:18:43', '', 96, 'http://localhost:82/wp-content/uploads/2024/03/divi-Simplified-croptop-yellow.jpg', 0, 'attachment', 'image/jpeg', 0),
(116, 1, '2024-03-08 13:18:44', '2024-03-08 13:18:44', '', 'Dat-Divi_Life.jpg', '', 'inherit', 'open', 'closed', '', 'dat-divi_life-jpg', '', '', '2024-03-08 13:18:44', '2024-03-08 13:18:44', '', 97, 'http://localhost:82/wp-content/uploads/2024/03/Dat-Divi_Life.jpg', 0, 'attachment', 'image/jpeg', 0),
(117, 1, '2024-03-08 15:15:04', '2024-03-08 15:15:04', '<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->\n<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:columns {"align":"wide"} -->\n<div class="wp-block-columns alignwide"><!-- wp:column {"width":"30%"} -->\n<div class="wp-block-column" style="flex-basis:30%"><!-- wp:group {"style":{"dimensions":{"minHeight":""},"layout":{"selfStretch":"fit","flexSize":null}},"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:site-logo {"width":20,"shouldSyncIcon":true,"style":{"layout":{"selfStretch":"fit","flexSize":null}}} /-->\n\n<!-- wp:site-title {"level":0,"fontSize":"medium"} /-->\n\n<!-- wp:site-tagline {"fontSize":"small"} /--></div>\n<!-- /wp:group --></div>\n<!-- /wp:column -->\n\n<!-- wp:column {"width":"50%"} -->\n<div class="wp-block-column" style="flex-basis:50%"><!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"top"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch"}} -->\n<div class="wp-block-group"><!-- wp:heading {"style":{"typography":{"fontStyle":"normal","fontWeight":"600"}},"className":"has-medium-font-size","fontFamily":"body"} -->\n<h2 class="wp-block-heading has-medium-font-size has-body-font-family" style="font-style:normal;font-weight:600">Contact</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|10"}},"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:navigation {"ref":123,"overlayMenu":"never","layout":{"type":"flex","orientation":"vertical"},"style":{"typography":{"fontStyle":"normal","fontWeight":"400"},"spacing":{"blockGap":"var:preset|spacing|10"}},"fontSize":"small"} /--></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch"}} -->\n<div class="wp-block-group"><!-- wp:heading {"style":{"typography":{"fontStyle":"normal","fontWeight":"600"}},"className":"has-medium-font-size","fontFamily":"body"} -->\n<h2 class="wp-block-heading has-medium-font-size has-body-font-family" style="font-style:normal;font-weight:600">Privacy</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|10"}},"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:navigation {"overlayMenu":"never","layout":{"type":"flex","orientation":"vertical"},"style":{"typography":{"fontStyle":"normal","fontWeight":"400"},"spacing":{"blockGap":"var:preset|spacing|10"}},"fontSize":"small"} -->\n<!-- wp:navigation-link {"label":"Privacy Policy","url":"#"} /-->\n\n<!-- wp:navigation-link {"label":"Terms and Conditions","url":"#"} /-->\n\n<!-- wp:navigation-link {"label":"Contact Us","url":"#"} /-->\n<!-- /wp:navigation --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch"}} -->\n<div class="wp-block-group"><!-- wp:heading {"style":{"typography":{"fontStyle":"normal","fontWeight":"600"}},"className":"has-medium-font-size","fontFamily":"body"} -->\n<h2 class="wp-block-heading has-medium-font-size has-body-font-family" style="font-style:normal;font-weight:600">Social</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|10"}},"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:navigation {"overlayMenu":"never","layout":{"type":"flex","orientation":"vertical"},"style":{"typography":{"fontStyle":"normal","fontWeight":"400"},"spacing":{"blockGap":"var:preset|spacing|10"}},"fontSize":"small"} -->\n<!-- wp:navigation-link {"label":"Facebook","url":"#"} /-->\n\n<!-- wp:navigation-link {"label":"Instagram","url":"#"} /-->\n\n<!-- wp:navigation-link {"label":"Twitter/X","url":"#"} /-->\n<!-- /wp:navigation --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns --></div>\n<!-- /wp:group -->', 'Footer', '', 'publish', 'closed', 'closed', '', 'footer', '', '', '2024-03-08 15:20:37', '2024-03-08 15:20:37', '', 0, 'http://localhost:82/footer/', 0, 'wp_template_part', '', 0),
(121, 1, '2024-03-08 15:16:42', '2024-03-08 15:16:42', '<!-- wp:template-part {"slug":"header","theme":"twentytwentyfour"} /-->\n\n<!-- wp:group {"layout":{"inherit":true,"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:woocommerce/breadcrumbs /-->\n\n<!-- wp:woocommerce/store-notices /-->\n\n<!-- wp:columns {"align":"wide"} -->\n<div class="wp-block-columns alignwide"><!-- wp:column {"width":"512px"} -->\n<div class="wp-block-column" style="flex-basis:512px"><!-- wp:woocommerce/product-image-gallery /--></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:post-title {"level":1,"__woocommerceNamespace":"woocommerce/product-query/product-title"} /-->\n\n<!-- wp:woocommerce/product-rating -->\n<div class="is-loading"></div>\n<!-- /wp:woocommerce/product-rating -->\n\n<!-- wp:woocommerce/product-price {"fontSize":"large"} -->\n<div class="is-loading"></div>\n<!-- /wp:woocommerce/product-price -->\n\n<!-- wp:post-excerpt {"__woocommerceNamespace":"woocommerce/product-query/product-summary"} /-->\n\n<!-- wp:woocommerce/add-to-cart-form /-->\n\n<!-- wp:woocommerce/product-meta -->\n<div class="wp-block-woocommerce-product-meta"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:woocommerce/product-sku -->\n<div class="is-loading"></div>\n<!-- /wp:woocommerce/product-sku -->\n\n<!-- wp:post-terms {"term":"product_cat","prefix":"Category: "} /-->\n\n<!-- wp:post-terms {"term":"product_tag","prefix":"Tags: "} /--></div>\n<!-- /wp:group --></div>\n<!-- /wp:woocommerce/product-meta --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n<!-- wp:woocommerce/product-details {"align":"wide","className":"is-style-minimal"} /-->\n\n<!-- wp:woocommerce/related-products {"align":"wide"} -->\n<div class="wp-block-woocommerce-related-products alignwide"><!-- wp:query {"queryId":0,"query":{"perPage":5,"pages":0,"offset":0,"postType":"product","order":"asc","orderBy":"title","author":"","search":"","exclude":[],"sticky":"","inherit":false},"namespace":"woocommerce/related-products","lock":{"remove":true,"move":true}} -->\n<div class="wp-block-query"><!-- wp:heading {"style":{"spacing":{"margin":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} -->\n<h2 class="wp-block-heading" style="margin-top:var(--wp--preset--spacing--30);margin-bottom:var(--wp--preset--spacing--30)">\n				Related products			</h2>\n<!-- /wp:heading -->\n\n<!-- wp:post-template {"className":"products-block-post-template","layout":{"type":"grid","columnCount":5},"__woocommerceNamespace":"woocommerce/product-query/product-template"} -->\n<!-- wp:woocommerce/product-image {"isDescendentOfQueryLoop":true} /-->\n\n<!-- wp:post-title {"textAlign":"center","level":3,"fontSize":"medium","__woocommerceNamespace":"woocommerce/product-query/product-title"} /-->\n\n<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true,"textAlign":"center","fontSize":"small","style":{"spacing":{"margin":{"bottom":"1rem"}}}} /-->\n\n<!-- wp:woocommerce/product-button {"textAlign":"center","isDescendentOfQueryLoop":true,"fontSize":"small","style":{"spacing":{"margin":{"bottom":"1rem"}}}} /-->\n<!-- /wp:post-template --></div>\n<!-- /wp:query --></div>\n<!-- /wp:woocommerce/related-products --></div>\n<!-- /wp:group -->\n\n<!-- wp:template-part {"slug":"footer","theme":"twentytwentyfour"} /-->', 'Single Product', 'Displays a single product.', 'publish', 'closed', 'closed', '', 'single-product', '', '', '2024-03-08 15:16:42', '2024-03-08 15:16:42', '', 0, 'http://localhost:82/single-product/', 0, 'wp_template', '', 0),
(123, 1, '2024-03-08 15:20:37', '2024-03-08 15:20:37', '<!-- wp:navigation-link {"label":"Phone : 0120700113","url":"#"} /-->\n\n<!-- wp:navigation-link {"label":"Mail : admin@email.com","url":"#"} /-->\n\n<!-- wp:navigation-link {"label":"Address: 123 ACB City Country","url":"#"} /-->', 'Footer navigation', '', 'publish', 'closed', 'closed', '', 'footer-navigation', '', '', '2024-03-08 15:20:37', '2024-03-08 15:20:37', '', 0, 'http://localhost:82/?p=123', 0, 'wp_navigation', '', 0),
(124, 1, '2024-03-08 15:20:37', '2024-03-08 15:20:37', '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"20px","bottom":"20px"}}},"backgroundColor":"base","layout":{"type":"constrained"}} -->\n<div class="wp-block-group alignwide has-base-background-color has-background" style="padding-top:20px;padding-bottom:20px"><!-- wp:group {"align":"wide","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->\n<div class="wp-block-group alignwide"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}},"layout":{"type":"flex"}} -->\n<div class="wp-block-group"><!-- wp:site-logo {"width":60,"shouldSyncIcon":true,"style":{"color":{"duotone":"unset"}}} /-->\n\n<!-- wp:group {"style":{"spacing":{"blockGap":"0px"}}} -->\n<div class="wp-block-group"><!-- wp:site-title {"level":0} /--></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:search {"label":"Search","showLabel":false,"placeholder":"This is custom","width":614,"widthUnit":"px","buttonText":"Search","buttonPosition":"button-inside","buttonUseIcon":true} /-->\n\n<!-- wp:navigation {"ref":5,"layout":{"type":"flex","orientation":"horizontal"},"style":{"spacing":{"margin":{"top":"0"},"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}}} /-->\n\n<!-- wp:woocommerce/mini-cart /--></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->', 'Header', '', 'publish', 'closed', 'closed', '', 'header', '', '', '2024-03-09 03:58:25', '2024-03-09 03:58:25', '', 0, 'http://localhost:82/header/', 0, 'wp_template_part', '', 0),
(130, 1, '2024-03-08 15:41:12', '2024-03-08 15:41:12', '\n<!-- wp:woocommerce/filter-wrapper {"filterType":"active-filters"} -->\n<div class="wp-block-woocommerce-filter-wrapper"><!-- wp:heading {"level":3} -->\n<h3>Active filters</h3>\n<!-- /wp:heading -->\n\n<!-- wp:woocommerce/active-filters {"heading":"","lock":{"remove":true}} -->\n<div class="wp-block-woocommerce-active-filters is-loading" data-display-style="list" data-heading="" data-heading-level="3"><span aria-hidden="true" class="wc-block-active-filters__placeholder"></span></div>\n<!-- /wp:woocommerce/active-filters --></div>\n<!-- /wp:woocommerce/filter-wrapper -->\n\n<!-- wp:woocommerce/filter-wrapper {"filterType":"price-filter"} -->\n<div class="wp-block-woocommerce-filter-wrapper"><!-- wp:heading {"level":3} -->\n<h3>Filter by price</h3>\n<!-- /wp:heading -->\n\n<!-- wp:woocommerce/price-filter {"heading":"","lock":{"remove":true}} -->\n<div class="wp-block-woocommerce-price-filter is-loading" data-showinputfields="true" data-showfilterbutton="false" data-heading="" data-heading-level="3"><span aria-hidden="true" class="wc-block-product-categories__placeholder"></span></div>\n<!-- /wp:woocommerce/price-filter --></div>\n<!-- /wp:woocommerce/filter-wrapper -->\n\n<!-- wp:woocommerce/filter-wrapper {"filterType":"stock-filter"} -->\n<div class="wp-block-woocommerce-filter-wrapper"><!-- wp:heading {"level":3} -->\n<h3>Filter by stock status</h3>\n<!-- /wp:heading -->\n\n<!-- wp:woocommerce/stock-filter {"heading":"","lock":{"remove":true}} -->\n<div class="wp-block-woocommerce-stock-filter is-loading" data-show-counts="true" data-heading="" data-heading-level="3"><span aria-hidden="true" class="wc-block-product-stock-filter__placeholder"></span></div>\n<!-- /wp:woocommerce/stock-filter --></div>\n<!-- /wp:woocommerce/filter-wrapper -->\n\n<!-- wp:woocommerce/filter-wrapper {"filterType":"attribute-filter"} -->\n<div class="wp-block-woocommerce-filter-wrapper"><!-- wp:heading {"level":3} -->\n<h3>Filter by attribute</h3>\n<!-- /wp:heading -->\n\n\n<!-- wp:woocommerce/attribute-filter {"attributeId":3,"heading":"","lock":{"remove":true}} -->\n<div class="wp-block-woocommerce-attribute-filter is-loading" data-attribute-id="3" data-show-counts="true" data-query-type="or" data-heading="" data-heading-level="3"><span aria-hidden="true" class="wc-block-product-attribute-filter__placeholder"></span></div>\n<!-- /wp:woocommerce/attribute-filter --></div>\n<!-- /wp:woocommerce/filter-wrapper -->\n\n<!-- wp:woocommerce/filter-wrapper {"filterType":"rating-filter"} -->\n<div class="wp-block-woocommerce-filter-wrapper"><!-- wp:heading {"level":3} -->\n<h3>Filter by rating</h3>\n<!-- /wp:heading -->\n\n<!-- wp:woocommerce/rating-filter {"lock":{"remove":true}} -->\n<div class="wp-block-woocommerce-rating-filter is-loading" data-show-counts="true"><span aria-hidden="true" class="wc-block-product-rating-filter__placeholder"></span></div>\n<!-- /wp:woocommerce/rating-filter --></div>\n<!-- /wp:woocommerce/filter-wrapper -->\n', 'Product Filters (Copy)', '', 'publish', 'closed', 'closed', '', 'product-filters-copy', '', '', '2024-03-08 15:41:12', '2024-03-08 15:41:12', '', 0, 'http://localhost:82/product-filters-copy/', 0, 'wp_block', '', 0),
(135, 1, '2024-03-09 03:45:06', '2024-03-09 03:45:06', '', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2024-03-09 03:45:06', '2024-03-09 03:45:06', '', 0, 'http://localhost:82/?post_type=shop_order_placehold&p=135', 0, 'shop_order_placehold', '', 0),
(144, 1, '2024-03-09 03:59:36', '2024-03-09 03:59:36', '<!-- wp:template-part {"slug":"header","theme":"twentytwentyfour","tagName":"header","area":"header"} /-->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"var:preset|spacing|30","right":"var:preset|spacing|30"},"margin":{"top":"0px","bottom":"80px"}}},"layout":{"type":"constrained"}} -->\n<div class="wp-block-group alignwide" style="margin-top:0px;margin-bottom:80px;padding-top:0;padding-right:var(--wp--preset--spacing--30);padding-bottom:0;padding-left:var(--wp--preset--spacing--30)"><!-- wp:heading {"level":3,"align":"wide"} -->\n<h3 class="wp-block-heading alignwide">Staff picks</h3>\n<!-- /wp:heading -->\n\n<!-- wp:woocommerce/product-collection {"id":"d5f8f960-15f4-4cb0-afe3-26fbc80290f5","queryId":1,"query":{"perPage":9,"pages":0,"offset":0,"postType":"product","order":"asc","orderBy":"title","search":"","exclude":[],"inherit":false,"taxQuery":{},"isProductCollectionBlock":true,"featured":false,"woocommerceOnSale":false,"woocommerceStockStatus":["instock","outofstock","onbackorder"],"woocommerceAttributes":[],"woocommerceHandPickedProducts":[]},"tagName":"div","displayLayout":{"type":"flex","columns":3,"shrinkColumns":true},"align":"wide"} -->\n<div class="wp-block-woocommerce-product-collection alignwide"><!-- wp:woocommerce/product-template -->\n<!-- wp:woocommerce/product-image {"imageSizing":"thumbnail","isDescendentOfQueryLoop":true} /-->\n\n<!-- wp:post-title {"textAlign":"center","level":3,"isLink":true,"style":{"spacing":{"margin":{"bottom":"0.75rem","top":"0"}}},"fontSize":"medium","__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->\n\n<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true,"textAlign":"center","fontSize":"small"} /-->\n\n<!-- wp:woocommerce/product-button {"textAlign":"center","isDescendentOfQueryLoop":true,"fontSize":"small"} /-->\n<!-- /wp:woocommerce/product-template --></div>\n<!-- /wp:woocommerce/product-collection --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:template-part {"slug":"footer","theme":"twentytwentyfour","tagName":"footer","area":"footer"} /-->', 'Blog Home', 'Displays the latest posts as either the site homepage or as the "Posts page" as defined under reading settings. If it exists, the Front Page template overrides this template when posts are shown on the homepage.', 'publish', 'closed', 'closed', '', 'home', '', '', '2024-03-09 04:07:35', '2024-03-09 04:07:35', '', 0, 'http://localhost:82/home/', 0, 'wp_template', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(9, 2, 0),
(16, 17, 0),
(17, 17, 0),
(20, 3, 0),
(20, 18, 0),
(20, 22, 0),
(21, 3, 0),
(21, 18, 0),
(21, 22, 0),
(22, 5, 0),
(22, 18, 0),
(22, 22, 0),
(22, 23, 0),
(22, 24, 0),
(22, 25, 0),
(23, 16, 0),
(24, 16, 0),
(25, 16, 0),
(26, 16, 0),
(27, 3, 0),
(27, 18, 0),
(27, 22, 0),
(28, 5, 0),
(28, 19, 0),
(28, 20, 0),
(28, 22, 0),
(28, 26, 0),
(28, 27, 0),
(28, 28, 0),
(28, 29, 0),
(28, 30, 0),
(28, 31, 0),
(29, 16, 0),
(30, 16, 0),
(31, 16, 0),
(32, 16, 0),
(33, 16, 0),
(34, 16, 0),
(35, 16, 0),
(36, 16, 0),
(37, 16, 0),
(38, 5, 0),
(38, 19, 0),
(38, 20, 0),
(38, 23, 0),
(38, 29, 0),
(38, 30, 0),
(38, 31, 0),
(39, 16, 0),
(40, 16, 0),
(41, 16, 0),
(42, 5, 0),
(42, 19, 0),
(42, 20, 0),
(42, 25, 0),
(42, 29, 0),
(42, 30, 0),
(42, 31, 0),
(43, 16, 0),
(44, 16, 0),
(45, 16, 0),
(46, 5, 0),
(46, 10, 0),
(46, 19, 0),
(46, 21, 0),
(46, 23, 0),
(46, 29, 0),
(46, 30, 0),
(46, 31, 0),
(47, 10, 0),
(47, 16, 0),
(48, 10, 0),
(48, 16, 0),
(49, 10, 0),
(49, 16, 0),
(64, 5, 0),
(64, 19, 0),
(64, 21, 0),
(64, 22, 0),
(64, 29, 0),
(64, 30, 0),
(64, 31, 0),
(65, 16, 0),
(66, 16, 0),
(67, 16, 0),
(68, 5, 0),
(68, 19, 0),
(68, 21, 0),
(68, 25, 0),
(68, 29, 0),
(68, 30, 0),
(68, 31, 0),
(69, 16, 0),
(70, 16, 0),
(71, 16, 0),
(72, 5, 0),
(72, 22, 0),
(72, 29, 0),
(72, 30, 0) ;
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(72, 31, 0),
(72, 32, 0),
(72, 33, 0),
(81, 16, 0),
(82, 16, 0),
(83, 16, 0),
(84, 5, 0),
(84, 22, 0),
(84, 29, 0),
(84, 30, 0),
(84, 31, 0),
(84, 32, 0),
(84, 33, 0),
(85, 16, 0),
(86, 16, 0),
(87, 16, 0),
(88, 5, 0),
(88, 24, 0),
(88, 29, 0),
(88, 30, 0),
(88, 31, 0),
(88, 32, 0),
(88, 33, 0),
(89, 16, 0),
(90, 16, 0),
(91, 16, 0),
(92, 5, 0),
(92, 23, 0),
(92, 29, 0),
(92, 30, 0),
(92, 31, 0),
(92, 32, 0),
(92, 34, 0),
(93, 16, 0),
(94, 16, 0),
(95, 16, 0),
(96, 5, 0),
(96, 22, 0),
(96, 23, 0),
(96, 26, 0),
(96, 27, 0),
(96, 28, 0),
(96, 29, 0),
(96, 30, 0),
(96, 31, 0),
(96, 32, 0),
(96, 34, 0),
(97, 5, 0),
(97, 22, 0),
(97, 29, 0),
(97, 30, 0),
(97, 31, 0),
(97, 32, 0),
(97, 34, 0),
(98, 16, 0),
(99, 16, 0),
(100, 16, 0),
(101, 16, 0),
(102, 16, 0),
(103, 16, 0),
(104, 16, 0),
(105, 16, 0),
(106, 16, 0),
(107, 16, 0),
(108, 16, 0),
(109, 16, 0),
(117, 2, 0),
(117, 35, 0),
(121, 17, 0),
(124, 2, 0),
(124, 36, 0),
(130, 37, 0),
(144, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'wp_theme', '', 0, 4),
(3, 3, 'product_type', '', 0, 3),
(4, 4, 'product_type', '', 0, 0),
(5, 5, 'product_type', '', 0, 13),
(6, 6, 'product_type', '', 0, 0),
(7, 7, 'product_visibility', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 4),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_visibility', '', 0, 0),
(16, 16, 'product_cat', '', 0, 0),
(17, 17, 'wp_theme', '', 0, 3),
(18, 18, 'product_cat', '', 0, 4),
(19, 19, 'product_cat', '', 0, 6),
(20, 20, 'product_cat', '', 19, 3),
(21, 21, 'product_cat', '', 19, 3),
(22, 22, 'pa_brand', '', 0, 10),
(23, 23, 'pa_brand', '', 0, 5),
(24, 24, 'pa_brand', '', 0, 2),
(25, 25, 'pa_brand', '', 0, 3),
(26, 26, 'pa_color', '', 0, 2),
(27, 27, 'pa_color', '', 0, 2),
(28, 28, 'pa_color', '', 0, 2),
(29, 29, 'pa_size', '', 0, 12),
(30, 30, 'pa_size', '', 0, 12),
(31, 31, 'pa_size', '', 0, 12),
(32, 32, 'product_cat', '', 0, 6),
(33, 33, 'product_cat', '', 32, 3),
(34, 34, 'product_cat', '', 32, 3),
(35, 35, 'wp_template_part_area', '', 0, 1),
(36, 36, 'wp_template_part_area', '', 0, 1),
(37, 37, 'wp_pattern_category', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#
INSERT INTO `wp_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 16, 'product_count_product_cat', '0'),
(2, 18, 'order', '0'),
(3, 19, 'order', '0'),
(4, 20, 'order', '0'),
(5, 21, 'order', '0'),
(6, 18, 'product_count_product_cat', '4'),
(7, 22, 'order', '0'),
(8, 23, 'order', '0'),
(9, 24, 'order', '0'),
(10, 25, 'order', '0'),
(11, 19, 'product_count_product_cat', '6'),
(12, 20, 'product_count_product_cat', '3'),
(13, 26, 'order', '0'),
(14, 27, 'order', '0'),
(15, 28, 'order', '0'),
(16, 29, 'order', '0'),
(17, 30, 'order', '0'),
(18, 31, 'order', '0'),
(19, 32, 'order', '0'),
(20, 33, 'order', '0'),
(21, 21, 'product_count_product_cat', '3'),
(22, 33, 'product_count_product_cat', '3'),
(23, 32, 'product_count_product_cat', '6'),
(24, 34, 'order', '0'),
(25, 34, 'product_count_product_cat', '3') ;

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'twentytwentyfour', 'twentytwentyfour', 0),
(3, 'simple', 'simple', 0),
(4, 'grouped', 'grouped', 0),
(5, 'variable', 'variable', 0),
(6, 'external', 'external', 0),
(7, 'exclude-from-search', 'exclude-from-search', 0),
(8, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(9, 'featured', 'featured', 0),
(10, 'outofstock', 'outofstock', 0),
(11, 'rated-1', 'rated-1', 0),
(12, 'rated-2', 'rated-2', 0),
(13, 'rated-3', 'rated-3', 0),
(14, 'rated-4', 'rated-4', 0),
(15, 'rated-5', 'rated-5', 0),
(16, 'Uncategorized', 'uncategorized', 0),
(17, 'woocommerce/woocommerce', 'woocommerce-woocommerce', 0),
(18, 'Accessories', 'accessories', 0),
(19, 'Men', 'men', 0),
(20, 'Shirts', 'shirts', 0),
(21, 'Hoodies', 'hoodies', 0),
(22, 'Divi Engine', 'divi-engine', 0),
(23, 'Divi', 'divi', 0),
(24, 'WooCommerce', 'woocommerce', 0),
(25, 'WordPress', 'wordpress', 0),
(26, 'Blue', 'blue', 0),
(27, 'White', 'white', 0),
(28, 'Yellow', 'yellow', 0),
(29, 'Large', 'large', 0),
(30, 'Medium', 'medium', 0),
(31, 'Small', 'small', 0),
(32, 'Women', 'women', 0),
(33, 'Hoodies', 'hoodies-women', 0),
(34, 'Shirts', 'shirts-women', 0),
(35, 'footer', 'footer', 0),
(36, 'header', 'header', 0),
(37, 'WooCommerce', 'woo-commerce', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:1:{s:64:"5f67f6cc9d335c75bb646952a8ceb0d8691e7d01beddaeb0e523142dc931da09";a:4:{s:10:"expiration";i:1710071136;s:2:"ip";s:10:"172.25.0.1";s:2:"ua";s:115:"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0";s:5:"login";i:1709898336;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:10:"172.25.0.0";}'),
(19, 1, 'wp_persisted_preferences', 'a:4:{s:14:"core/edit-post";a:3:{s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;s:10:"openPanels";a:3:{i:0;s:11:"post-status";i:1;s:14:"featured-image";i:2;s:16:"discussion-panel";}}s:9:"_modified";s:24:"2024-03-09T03:43:37.686Z";s:14:"core/edit-site";a:2:{s:12:"welcomeGuide";b:0;s:16:"welcomeGuidePage";b:0;}s:17:"core/block-editor";a:1:{s:25:"linkControlSettingsDrawer";b:1;}}'),
(20, 1, 'closedpostboxes_dashboard', 'a:4:{i:0;s:19:"dashboard_right_now";i:1;s:18:"dashboard_activity";i:2;s:21:"dashboard_quick_press";i:3;s:17:"dashboard_primary";}'),
(21, 1, 'metaboxhidden_dashboard', 'a:4:{i:0;s:19:"dashboard_right_now";i:1;s:18:"dashboard_activity";i:2;s:21:"dashboard_quick_press";i:3;s:17:"dashboard_primary";}'),
(22, 1, '_woocommerce_tracks_anon_id', 'woo:zrdBecacAb6aQEEYxkrILJox'),
(23, 1, 'wc_last_active', '1709942400'),
(24, 1, 'last_update', '1709955817'),
(25, 1, 'woocommerce_admin_task_list_tracked_started_tasks', '{"payments":2}'),
(26, 1, 'woocommerce_admin_help_panel_highlight_shown', '"yes"'),
(27, 1, 'dismissed_no_secure_connection_notice', '1'),
(28, 1, 'manageedit-acf-post-typecolumnshidden', 'a:1:{i:0;s:7:"acf-key";}'),
(29, 1, 'acf_user_settings', 'a:2:{s:19:"post-type-first-run";b:1;s:20:"taxonomies-first-run";b:1;}'),
(30, 1, 'manageedit-acf-taxonomycolumnshidden', 'a:1:{i:0;s:7:"acf-key";}'),
(31, 1, 'meta-box-order_product', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:84:"submitdiv,postimagediv,woocommerce-product-images,product_catdiv,tagsdiv-product_tag";s:6:"normal";s:59:"woocommerce-product-data,,,,slugdiv,postexcerpt,commentsdiv";s:8:"advanced";s:0:"";}'),
(32, 1, 'wp_woocommerce_product_import_mapping', 'a:62:{i:0;s:2:"id";i:1;s:4:"type";i:2;s:3:"sku";i:3;s:4:"name";i:4;s:9:"published";i:5;s:8:"featured";i:6;s:18:"catalog_visibility";i:7;s:17:"short_description";i:8;s:11:"description";i:9;s:17:"date_on_sale_from";i:10;s:15:"date_on_sale_to";i:11;s:10:"tax_status";i:12;s:9:"tax_class";i:13;s:12:"stock_status";i:14;s:14:"stock_quantity";i:15;s:16:"low_stock_amount";i:16;s:10:"backorders";i:17;s:17:"sold_individually";i:18;s:0:"";i:19;s:6:"length";i:20;s:5:"width";i:21;s:6:"height";i:22;s:15:"reviews_allowed";i:23;s:13:"purchase_note";i:24;s:10:"sale_price";i:25;s:13:"regular_price";i:26;s:12:"category_ids";i:27;s:7:"tag_ids";i:28;s:17:"shipping_class_id";i:29;s:6:"images";i:30;s:14:"download_limit";i:31;s:15:"download_expiry";i:32;s:9:"parent_id";i:33;s:16:"grouped_products";i:34;s:10:"upsell_ids";i:35;s:14:"cross_sell_ids";i:36;s:11:"product_url";i:37;s:11:"button_text";i:38;s:10:"menu_order";i:39;s:16:"attributes:name1";i:40;s:17:"attributes:value1";i:41;s:19:"attributes:visible1";i:42;s:20:"attributes:taxonomy1";i:43;s:25:"meta:_et_pb_post_hide_nav";i:44;s:23:"meta:_et_pb_page_layout";i:45;s:20:"meta:_et_pb_side_nav";i:46;s:23:"meta:_et_pb_use_builder";i:47;s:23:"meta:_et_pb_first_image";i:48;s:25:"meta:_et_pb_truncate_post";i:49;s:30:"meta:_et_pb_truncate_post_date";i:50;s:23:"meta:_et_pb_old_content";i:51;s:19:"attributes:default1";i:52;s:16:"attributes:name2";i:53;s:17:"attributes:value2";i:54;s:19:"attributes:visible2";i:55;s:20:"attributes:taxonomy2";i:56;s:19:"attributes:default2";i:57;s:16:"attributes:name3";i:58;s:17:"attributes:value3";i:59;s:19:"attributes:visible3";i:60;s:20:"attributes:taxonomy3";i:61;s:19:"attributes:default3";}'),
(33, 1, 'wp_product_import_error_log', 'a:0:{}'),
(34, 1, 'screen_layout_product', '2'),
(35, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:"cart";a:2:{s:32:"dc25f4a9d74ad68f32fc16d92a9c4ede";a:11:{s:3:"key";s:32:"dc25f4a9d74ad68f32fc16d92a9c4ede";s:10:"product_id";i:22;s:12:"variation_id";i:24;s:9:"variation";a:1:{s:18:"attribute_pa_brand";s:11:"divi-engine";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"1b8635a39c699a108e940a9143e942c9";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:9.99;s:17:"line_subtotal_tax";d:0;s:10:"line_total";d:9.99;s:8:"line_tax";d:0;}s:32:"f9222c921b0d369a2c2dd47100871222";a:6:{s:3:"key";s:32:"f9222c921b0d369a2c2dd47100871222";s:10:"product_id";i:97;s:12:"variation_id";i:99;s:9:"variation";a:1:{s:17:"attribute_pa_size";s:6:"medium";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"4f1d32f51df2903a4f5e7fbcb17bb2d0";}}}'),
(36, 1, 'wp_user-settings', 'libraryContent=browse'),
(37, 1, 'wp_user-settings-time', '1709956631') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BkIMsQX3MXAxkd2mdo462qrpEwkOyJ1', 'admin', 'admin@email.com', 'http://localhost:82', '2024-03-08 11:45:30', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_admin_note_actions`
#

DROP TABLE IF EXISTS `wp_wc_admin_note_actions`;


#
# Table structure of table `wp_wc_admin_note_actions`
#

CREATE TABLE `wp_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `query` longtext NOT NULL,
  `status` varchar(255) NOT NULL,
  `actioned_text` varchar(255) NOT NULL,
  `nonce_action` varchar(255) DEFAULT NULL,
  `nonce_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_admin_note_actions`
#
INSERT INTO `wp_wc_admin_note_actions` ( `action_id`, `note_id`, `name`, `label`, `query`, `status`, `actioned_text`, `nonce_action`, `nonce_name`) VALUES
(1, 1, 'notify-refund-returns-page', 'Edit page', 'http://localhost:82/wp-admin/post.php?post=15&action=edit', 'actioned', '', NULL, NULL),
(2, 2, 'connect', 'Connect', '?page=wc-addons&section=helper', 'unactioned', '', NULL, NULL),
(99, 3, 'wayflyer_bnpl_q4_2021', 'Level up with funding', 'https://woo.com/products/wayflyer/?utm_source=inbox_note&utm_medium=product&utm_campaign=wayflyer_bnpl_q4_2021', 'actioned', '', NULL, NULL),
(100, 4, 'wc_shipping_mobile_app_usps_q4_2021', 'Get WooCommerce Shipping', 'https://woo.com/woocommerce-shipping/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_usps_q4_2021', 'actioned', '', NULL, NULL),
(101, 5, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox', 'unactioned', '', NULL, NULL),
(102, 6, 'learn-more', 'Learn more', 'https://woo.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'actioned', '', NULL, NULL),
(103, 7, 'optimizing-the-checkout-flow', 'Learn more', 'https://woo.com/posts/optimizing-woocommerce-checkout?utm_source=inbox_note&utm_medium=product&utm_campaign=optimizing-the-checkout-flow', 'actioned', '', NULL, NULL),
(104, 8, 'qualitative-feedback-from-new-users', 'Share feedback', 'https://automattic.survey.fm/wc-pay-new', 'actioned', '', NULL, NULL),
(105, 9, 'share-feedback', 'Share feedback', 'http://automattic.survey.fm/paypal-feedback', 'unactioned', '', NULL, NULL),
(106, 10, 'get-started', 'Get started', 'https://woo.com/products/google-listings-and-ads?utm_source=inbox_note&utm_medium=product&utm_campaign=get-started', 'actioned', '', NULL, NULL),
(107, 11, 'update-wc-subscriptions-3-0-15', 'View latest version', 'http://localhost:82/wp-admin/&page=wc-addons&section=helper', 'actioned', '', NULL, NULL),
(108, 12, 'update-wc-core-5-4-0', 'How to update WooCommerce', 'https://docs.woocommerce.com/document/how-to-update-woocommerce/', 'actioned', '', NULL, NULL),
(109, 15, 'ppxo-pps-install-paypal-payments-1', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(110, 16, 'ppxo-pps-install-paypal-payments-2', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(111, 17, 'learn-more', 'Learn more', 'https://woo.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(112, 17, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(113, 18, 'learn-more', 'Learn more', 'https://woo.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(114, 18, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(115, 19, 'learn-more', 'Learn more', 'https://woo.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(116, 19, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(117, 20, 'learn-more', 'Learn more', 'https://woo.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(118, 20, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(119, 21, 'share-feedback', 'Share feedback', 'https://automattic.survey.fm/store-management', 'unactioned', '', NULL, NULL),
(120, 22, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(121, 22, 'woocommerce-core-paypal-march-2022-dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(122, 23, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(123, 23, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(124, 24, 'pinterest_03_2022_update', 'Update Instructions', 'https://woo.com/document/pinterest-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=pinterest_03_2022_update#section-3', 'actioned', '', NULL, NULL),
(125, 25, 'store_setup_survey_survey_q2_2022_share_your_thoughts', 'Tell us how it’s going', 'https://automattic.survey.fm/store-setup-survey-2022', 'actioned', '', NULL, NULL),
(126, 26, 'learn-more', 'Find out more', 'https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/', 'unactioned', '', NULL, NULL),
(127, 26, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(128, 27, 'learn-more', 'Find out more', 'https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/', 'unactioned', '', NULL, NULL),
(129, 27, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(130, 28, 'needs-update-eway-payment-gateway-rin-action-button-2022-12-20', 'See available updates', 'http://localhost:82/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(131, 28, 'needs-update-eway-payment-gateway-rin-dismiss-button-2022-12-20', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(132, 29, 'updated-eway-payment-gateway-rin-action-button-2022-12-20', 'See all updates', 'http://localhost:82/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(133, 29, 'updated-eway-payment-gateway-rin-dismiss-button-2022-12-20', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(134, 30, 'share-navigation-survey-feedback', 'Share feedback', 'https://automattic.survey.fm/new-ecommerce-plan-navigation', 'actioned', '', NULL, NULL),
(135, 31, 'woopay-beta-merchantrecruitment-activate-04MAY23', 'Activate WooPay', 'http://localhost:82/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'actioned', '', NULL, NULL),
(136, 31, 'woopay-beta-merchantrecruitment-activate-learnmore-04MAY23', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-activate-learnmore-04MAY23', 'unactioned', '', NULL, NULL),
(137, 32, 'woocommerce-wcpay-march-2023-update-needed-button', 'See Blog Post', 'https://developer.woocommerce.com/2023/03/23/critical-vulnerability-detected-in-woocommerce-payments-what-you-need-to-know', 'unactioned', '', NULL, NULL),
(138, 32, 'woocommerce-wcpay-march-2023-update-needed-dismiss-button', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(139, 33, 'tap_to_pay_iphone_q2_2023_no_wcpay', 'Simplify my payments', 'https://woo.com/products/woocommerce-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=tap_to_pay_iphone_q2_2023_no_wcpay', 'actioned', '', NULL, NULL),
(140, 34, 'extension-settings', 'See available updates', 'http://localhost:82/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(141, 34, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(142, 35, 'woopay-beta-merchantrecruitment-update-WCPay-04MAY23', 'Update WooCommerce Payments', 'http://localhost:82/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(143, 35, 'woopay-beta-merchantrecruitment-update-activate-04MAY23', 'Activate WooPay', 'http://localhost:82/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'actioned', '', NULL, NULL),
(144, 36, 'woopay-beta-existingmerchants-noaction-documentation-27APR23', 'Documentation', 'https://woo.com/document/woopay-merchant-documentation/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-existingmerchants-noaction-documentation-27APR23', 'actioned', '', NULL, NULL),
(145, 37, 'woopay-beta-existingmerchants-update-WCPay-27APR23', 'Update WooCommerce Payments', 'http://localhost:82/wp-admin/plugins.php?plugin_status=all', 'actioned', '', NULL, NULL),
(146, 38, 'woopay-beta-merchantrecruitment-short-activate-04MAY23', 'Activate WooPay', 'http://localhost:82/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'actioned', '', NULL, NULL),
(147, 38, 'woopay-beta-merchantrecruitment-short-activate-learnmore-04MAY23', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-04MAY23', 'actioned', '', NULL, NULL),
(148, 39, 'woopay-beta-merchantrecruitment-short-update-WCPay-04MAY23', 'Update WooCommerce Payments', 'http://localhost:82/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(149, 39, 'woopay-beta-merchantrecruitment-short-update-activate-04MAY23', 'Activate WooPay', 'http://localhost:82/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'actioned', '', NULL, NULL),
(150, 40, 'woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTA', 'Activate WooPay Test A', 'http://localhost:82/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(151, 40, 'woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA', 'unactioned', '', NULL, NULL),
(152, 41, 'woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTB', 'Activate WooPay Test B', 'http://localhost:82/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(153, 41, 'woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA', 'unactioned', '', NULL, NULL),
(154, 42, 'woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTC', 'Activate WooPay Test C', 'http://localhost:82/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(155, 42, 'woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTC', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTC', 'unactioned', '', NULL, NULL),
(156, 43, 'woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTD', 'Activate WooPay Test D', 'http://localhost:82/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(157, 43, 'woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTD', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTD', 'unactioned', '', NULL, NULL),
(158, 44, 'woopay-beta-merchantrecruitment-short-activate-button-09MAY23', 'Activate WooPay', 'http://localhost:82/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(159, 44, 'woopay-beta-merchantrecruitment-short-activate-learnmore-button2-09MAY23', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-button2-09MAY23', 'unactioned', '', NULL, NULL),
(160, 45, 'woopay-beta-merchantrecruitment-short-update-WCPay-09MAY23', 'Update WooCommerce Payments', 'http://localhost:82/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(161, 45, 'woopay-beta-merchantrecruitment-short-update-activate-09MAY23', 'Activate WooPay', 'http://localhost:82/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(162, 46, 'woocommerce-WCStripe-May-2023-updated-needed-Plugin-Settings', 'See available updates', 'http://localhost:82/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(163, 46, 'woocommerce-WCStripe-May-2023-updated-needed-Plugin-Settings-dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(164, 47, 'woocommerce-WCPayments-June-2023-updated-needed-Plugin-Settings', 'See available updates', 'http://localhost:82/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(165, 47, 'woocommerce-WCPayments-June-2023-updated-needed-Dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(166, 48, 'woocommerce-WCSubscriptions-June-2023-updated-needed-Plugin-Settings', 'See available updates', 'http://localhost:82/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(167, 48, 'woocommerce-WCSubscriptions-June-2023-updated-needed-dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(168, 49, 'woocommerce-WCReturnsWarranty-June-2023-updated-needed', 'See available updates', 'http://localhost:82/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(169, 49, 'woocommerce-WCReturnsWarranty-June-2023-updated-needed', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(170, 50, 'woocommerce-WCOPC-June-2023-updated-needed', 'See available updates', 'http://localhost:82/wp-admin/plugins.php?plugin_status=all', 'actioned', '', NULL, NULL),
(171, 50, 'woocommerce-WCOPC-June-2023-updated-needed', 'Dismiss', 'http://localhost:82/wp-admin/#', 'actioned', '', NULL, NULL),
(172, 51, 'woocommerce-WCGC-July-2023-update-needed', 'See available updates', 'http://localhost:82/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(173, 51, 'woocommerce-WCGC-July-2023-update-needed', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(174, 52, 'learn-more', 'Learn more', 'https://woo.com/document/fedex/?utm_medium=product&utm_source=inbox_note&utm_campaign=learn-more#july-2023-api-outage', 'unactioned', '', NULL, NULL),
(175, 53, 'plugin-list', 'See available updates', 'http://localhost:82/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(176, 53, 'dismiss', 'Dismiss', 'http://localhost:82/wp-admin/admin.php?page=wc-admin', 'actioned', '', NULL, NULL),
(177, 54, 'woocommerce-WCStripe-Aug-2023-update-needed', 'See available updates', 'http://localhost:82/wp-admin/update-core.php?', 'unactioned', '', NULL, NULL),
(178, 54, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(179, 55, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(180, 56, 'woocommerce-WooPayments-Aug-2023-update-needed', 'See available updates', 'http://localhost:82/wp-admin/update-core.php?', 'unactioned', '', NULL, NULL),
(181, 56, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(182, 57, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(183, 58, 'avalara_q3-2023_noAvaTax', 'Automate my sales tax', 'https://woo.com/products/woocommerce-avatax/?utm_source=inbox_note&utm_medium=product&utm_campaign=avalara_q3-2023_noAvaTax', 'unactioned', '', NULL, NULL),
(184, 59, 'woo-activation-survey-blockers-survey-button-22AUG23', 'Take our short survey', 'https://woocommerce.survey.fm/getting-started-with-woo', 'unactioned', '', NULL, NULL),
(185, 60, 'woocommerce-usermeta-Sept2023-productvendors', 'See available updates', 'http://localhost:82/wp-admin/plugins.php', 'unactioned', '', NULL, NULL),
(186, 60, 'dismiss', 'Dismiss', 'http://localhost:82/wp-admin/#', 'actioned', '', NULL, NULL),
(187, 61, 'woocommerce-STRIPE-Oct-2023-update-needed', 'See available updates', 'http://localhost:82/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(188, 61, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(189, 62, 'amazon-mcf-review-button-2023-12-07', 'Leave a review', 'https://woo.com/products/woocommerce-amazon-fulfillment/?review&utm_source=inbox_note&utm_medium=product&utm_campaign=amazon-mcf-review-button-2023-12-07', 'actioned', '', NULL, NULL),
(190, 62, 'amazon-mcf-support-button-2023-12-07', 'Request support', 'https://woo.com/my-account/contact-support/?utm_source=inbox_note&utm_medium=product&utm_campaign=amazon-mcf-support-button-2023-12-07', 'actioned', '', NULL, NULL),
(191, 63, 'amazon_pay_ext-link_q1-24', 'Register your account now', 'https://eu.amazonpayments.com/2024-uk-woopricepromoregistration?utm_campaign=woo_price_promo&utm_medium=EM&utm_source=direct&utm_content=cta&utm_creative=&ld=EMUKAPA-woo_price_promo-direct-24Q1', 'actioned', '', NULL, NULL),
(192, 64, 'view_docs', 'Learn about Deposit schedules', 'https://woo.com/document/woopayments/deposits/deposit-schedule/?utm_source=inbox_note&utm_medium=product&utm_campaign=view_docs#available-funds', 'unactioned', '', NULL, NULL),
(193, 65, 'wc_admin_UKpricingchange_WCPay_Q1_2024', 'See related fees for each country', 'https://woo.com/document/woopayments/fees-and-debits/fees/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_admin_UKpricingchange_WCPay_Q1_2024#countries-in-europe', 'actioned', '', NULL, NULL),
(194, 66, 'airwallex_q1_2024', 'Get started with Airwallex', 'https://woo.com/products/airwallexpayments/?utm_source=inbox_note&utm_medium=product&utm_campaign=airwallex_q1_2024', 'actioned', '', NULL, NULL) ;

#
# End of data contents of table `wp_wc_admin_note_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_admin_notes`
#

DROP TABLE IF EXISTS `wp_wc_admin_notes`;


#
# Table structure of table `wp_wc_admin_notes`
#

CREATE TABLE `wp_wc_admin_notes` (
  `note_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `locale` varchar(20) NOT NULL,
  `title` longtext NOT NULL,
  `content` longtext NOT NULL,
  `content_data` longtext DEFAULT NULL,
  `status` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT 0,
  `layout` varchar(20) NOT NULL DEFAULT '',
  `image` varchar(200) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `icon` varchar(200) NOT NULL DEFAULT 'info',
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_admin_notes`
#
INSERT INTO `wp_wc_admin_notes` ( `note_id`, `name`, `type`, `locale`, `title`, `content`, `content_data`, `status`, `source`, `date_created`, `date_reminder`, `is_snoozable`, `layout`, `image`, `is_deleted`, `is_read`, `icon`) VALUES
(1, 'wc-refund-returns-page', 'info', 'en_US', 'Setup a Refund and Returns Policy page to boost your store\'s credibility.', 'We have created a sample draft Refund and Returns Policy page for you. Please have a look and update it to fit your store.', '[]', 'unactioned', 'woocommerce-core', '2024-03-08 12:21:06', NULL, 0, 'plain', '', 1, 1, 'info'),
(2, 'wc-admin-wc-helper-connection', 'info', 'en_US', 'Connect to Woo.com', 'Connect to get important product notifications and updates.', '[]', 'unactioned', 'woocommerce-admin', '2024-03-08 12:21:06', NULL, 0, 'plain', '', 1, 1, 'info'),
(3, 'wayflyer_bnpl_q4_2021', 'marketing', 'en_US', 'Grow your business with funding through Wayflyer', 'Fast, flexible financing to boost cash flow and help your business grow – one fee, no interest rates, penalties, equity, or personal guarantees. Based on your store’s performance, Wayflyer provides funding and analytical insights to invest in your business.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(4, 'wc_shipping_mobile_app_usps_q4_2021', 'marketing', 'en_US', 'Print and manage your shipping labels with WooCommerce Shipping and the WooCommerce Mobile App', 'Save time by printing, purchasing, refunding, and tracking shipping labels generated by <a href="https://woo.com/woocommerce-shipping/">WooCommerce Shipping</a> – all directly from your mobile device!', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(5, 'woocommerce-services', 'info', 'en_US', 'WooCommerce Shipping & Tax', 'WooCommerce Shipping &amp; Tax helps get your store "ready to sell" as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(6, 'your-first-product', 'info', 'en_US', 'Your first product', 'That’s huge! You’re well on your way to building a successful online store — now it’s time to think about how you’ll fulfill your orders.<br /><br />Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href="https://href.li/?https://woo.com/shipping" target="_blank">WooCommerce Shipping</a>.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(7, 'wc-admin-optimizing-the-checkout-flow', 'info', 'en_US', 'Optimizing the checkout flow', 'It’s crucial to get your store’s checkout as smooth as possible to avoid losing sales. Let’s take a look at how you can optimize the checkout experience for your shoppers.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(8, 'wc-payments-qualitative-feedback', 'info', 'en_US', 'WooCommerce Payments setup - let us know what you think', 'Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(9, 'share-your-feedback-on-paypal', 'info', 'en_US', 'Share your feedback on PayPal', 'Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(10, 'google_listings_and_ads_install', 'marketing', 'en_US', 'Drive traffic and sales with Google', 'Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(11, 'wc-subscriptions-security-update-3-0-15', 'info', 'en_US', 'WooCommerce Subscriptions security update!', 'We recently released an important security update to WooCommerce Subscriptions. To ensure your site’s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br /><br />Click the button below to view and update to the latest Subscriptions version, or log in to <a href="https://woo.com/my-dashboard">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br /><br />We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br /><br />If you have any questions we are here to help — just <a href="https://woo.com/my-account/create-a-ticket/">open a ticket</a>.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(12, 'woocommerce-core-update-5-4-0', 'info', 'en_US', 'Update to WooCommerce 5.4.1 now', 'WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(13, 'wcpay-promo-2020-11', 'marketing', 'en_US', 'wcpay-promo-2020-11', 'wcpay-promo-2020-11', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(14, 'wcpay-promo-2020-12', 'marketing', 'en_US', 'wcpay-promo-2020-12', 'wcpay-promo-2020-12', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(15, 'ppxo-pps-upgrade-paypal-payments-1', 'info', 'en_US', 'Get the latest PayPal extension for WooCommerce', 'Heads up! There’s a new PayPal on the block!<br /><br />Now is a great time to upgrade to our latest <a href="https://woo.com/products/woocommerce-paypal-payments/" target="_blank">PayPal extension</a> to continue to receive support and updates with PayPal.<br /><br />Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(16, 'ppxo-pps-upgrade-paypal-payments-2', 'info', 'en_US', 'Upgrade your PayPal experience!', 'Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br /><br />Start using our <a href="https://woo.com/products/woocommerce-paypal-payments/" target="_blank">latest PayPal today</a> to continue to receive support and updates.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(17, 'woocommerce-core-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(18, 'woocommerce-blocks-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(19, 'woocommerce-core-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(20, 'woocommerce-blocks-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(21, 'habit-moment-survey', 'marketing', 'en_US', 'We’re all ears! Share your experience so far with WooCommerce', 'We’d love your input to shape the future of WooCommerce together. Feel free to share any feedback, ideas or suggestions that you have.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(22, 'woocommerce-core-paypal-march-2022-updated', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy PayPal Standard security updates for stores running WooCommerce (version 3.5 to 6.3). It’s recommended to disable PayPal Standard, and use <a href="https://woo.com/products/woocommerce-paypal-payments/" target="_blank">PayPal Payments</a> to accept PayPal.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(23, 'woocommerce-core-paypal-march-2022-updated-nopp', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy security updates related to PayPal Standard payment gateway for stores running WooCommerce (version 3.5 to 6.3).', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(24, 'pinterest_03_2022_update', 'marketing', 'en_US', 'Your Pinterest for WooCommerce plugin is out of date!', 'Update to the latest version of Pinterest for WooCommerce to continue using this plugin and keep your store connected with Pinterest. To update, visit <strong>Plugins &gt; Installed Plugins</strong>, and click on “update now” under Pinterest for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(25, 'store_setup_survey_survey_q2_2022', 'survey', 'en_US', 'How is your store setup going?', 'Our goal is to make sure you have all the right tools to start setting up your store in the smoothest way possible.\r\nWe’d love to know if we hit our mark and how we can improve. To collect your thoughts, we made a 2-minute survey.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(26, 'woocommerce-payments-august-2022-need-to-update', 'update', 'en_US', 'Action required: Please update WooCommerce Payments', 'An updated secure version of WooCommerce Payments is available – please ensure that you’re using the latest patch version. For more information on what action you need to take, please review the article below.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(27, 'woocommerce-payments-august-2022-store-patched', 'update', 'en_US', 'WooCommerce Payments has been automatically updated', 'You’re now running the latest secure version of WooCommerce Payments. We’ve worked with the WordPress Plugins team to deploy a security update to stores running WooCommerce Payments (version 3.9 to 4.5). For further information, please review the article below.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(28, 'needs-update-eway-payment-gateway-rin-2022-12-20', 'update', 'en_US', 'Security vulnerability patched in WooCommerce Eway Gateway', 'In response to a potential vulnerability identified in WooCommerce Eway Gateway versions 3.1.0 to 3.5.0, we’ve worked to deploy security fixes and have released an updated version.\r\nNo external exploits have been detected, but we recommend you update to your latest supported version 3.1.26, 3.2.3, 3.3.1, 3.4.6, or 3.5.1', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(29, 'updated-eway-payment-gateway-rin-2022-12-20', 'update', 'en_US', 'WooCommerce Eway Gateway has been automatically updated', 'Your store is now running the latest secure version of WooCommerce Eway Gateway. We worked with the WordPress Plugins team to deploy a software update to stores running WooCommerce Eway Gateway (versions 3.1.0 to 3.5.0) in response to a security vulnerability that was discovered.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(30, 'ecomm-wc-navigation-survey-2023', 'info', 'en_US', 'Navigating WooCommerce on WordPress.com', 'We are improving the WooCommerce navigation on WordPress.com and would love your help to make it better! Please share your experience with us in this 2-minute survey.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(31, 'woopay-beta-merchantrecruitment-04MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'WooPay, a new express checkout feature built into WooCommerce Payments, is now available —and we’re inviting you to be one of the first to try it. \r\n<br><br>\r\nBoost conversions by offering your customers a simple, secure way to pay with a single click.\r\n<br><br>\r\nGet started in seconds.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(32, 'woocommerce-wcpay-march-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooCommerce Payments', '<strong>Your store requires a security update for WooCommerce Payments</strong>. Please update to the latest version of WooCommerce Payments immediately to address a potential vulnerability discovered on March 22. For more information on how to update, visit this WooCommerce Developer Blog Post.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(33, 'tap_to_pay_iphone_q2_2023_no_wcpay', 'marketing', 'en_US', 'Accept in-person contactless payments on your iPhone', 'Tap to Pay on iPhone and WooCommerce Payments is quick, secure, and simple to set up — no extra terminals or card readers are needed. Accept contactless debit and credit cards, Apple Pay, and other NFC digital wallets in person.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(34, 'woocommerce-WCPreOrders-april-2023-update-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce Pre-Orders extension', '<strong>Your store requires a security update for the WooCommerce Pre-Orders extension</strong>. Please update the WooCommerce Pre-Orders extension immediately to address a potential vulnerability discovered on April 11.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(35, 'woopay-beta-merchantrecruitment-update-04MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'WooPay, a new express checkout feature built into WooCommerce Payments, is now available — and you’re invited to try it. \r\n<br /><br />\r\nBoost conversions by offering your customers a simple, secure way to pay with a single click.\r\n<br /><br />\r\nUpdate WooCommerce Payments to get started.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(36, 'woopay-beta-existingmerchants-noaction-27APR23', 'info', 'en_US', 'WooPay is back!', 'Thanks for previously trying WooPay, the express checkout feature built into WooCommerce Payments. We’re excited to announce that WooPay availability has resumed. No action is required on your part.\r\n<br /><br />\r\nYou can now continue boosting conversions by offering your customers a simple, secure way to pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(37, 'woopay-beta-existingmerchants-update-27APR23', 'info', 'en_US', 'WooPay is back!', 'Thanks for previously trying WooPay, the express checkout feature built into WooCommerce Payments. We’re excited to announce that WooPay availability has resumed.\r\n<br /><br />\r\n\r\nUpdate to the latest WooCommerce Payments version to continue boosting conversions by offering your customers a simple, secure way to pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(38, 'woopay-beta-merchantrecruitment-short-04MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(39, 'woopay-beta-merchantrecruitment-short-update-04MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, our new express checkout feature. <br>Boost conversions by letting customers pay with a single click. <br><br>Update to the latest version of WooCommerce Payments to get started.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(40, 'woopay-beta-merchantrecruitment-short-06MAY23-TESTA', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(41, 'woopay-beta-merchantrecruitment-short-06MAY23-TESTB', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(42, 'woopay-beta-merchantrecruitment-short-06MAY23-TESTC', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(43, 'woopay-beta-merchantrecruitment-short-06MAY23-TESTD', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(44, 'woopay-beta-merchantrecruitment-short-09MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(45, 'woopay-beta-merchantrecruitment-short-update-09MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, our new express checkout feature. <br>Boost conversions by letting customers pay with a single click. <br><br>Update to the latest version of WooCommerce Payments to get started.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(46, 'woocommerce-WCstripe-May-2023-updated-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce Stripe plugin', '<strong>Your store requires a security update for the WooCommerce Stripe plugin</strong>. Please update the WooCommerce Stripe plugin immediately to address a potential vulnerability.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(47, 'woocommerce-WCPayments-June-2023-updated-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce Payments', '<strong>Your store requires a security update for the WooCommerce Payments plugin</strong>. Please update the WooCommerce Payments plugin immediately to address a potential vulnerability.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(48, 'woocommerce-WCSubscriptions-June-2023-updated-needed', 'marketing', 'en_US', 'Action required: Security update of WooCommerce Subscriptions', '<strong>Your store requires a security update for the WooCommerce Subscriptions plugin</strong>. Please update the WooCommerce Subscriptions plugin immediately to address a potential vulnerability.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(49, 'woocommerce-WCReturnsWarranty-June-2023-updated-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce Returns and Warranty Requests extension', '<strong>Your store requires a security update for the Returns and Warranty Requests extension</strong>.  Please update to the latest version of the WooCommerce Returns and Warranty Requests extension immediately to address a potential vulnerability discovered on May 31.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(50, 'woocommerce-WCOPC-June-2023-updated-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce One Page Checkout', '<strong>Your shop requires a security update to address a vulnerability in the WooCommerce One Page Checkout extension</strong>. The fix for this vulnerability was released for this extension on June 13th. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(51, 'woocommerce-WCGC-July-2023-update-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce GoCardless Extension', '<strong>Your shop requires a security update to address a vulnerability in the WooCommerce GoCardless extension</strong>. The fix for this vulnerability was released on July 4th. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(52, 'woocommerce-shipping-fedex-api-outage-2023-07-16', 'warning', 'en_US', 'Scheduled FedEx API outage — July 2023', 'On July 16 there will be a full outage of the FedEx API from 04:00 to 08:00 AM UTC. Due to planned maintenance by FedEx, you\'ll be unable to provide FedEx shipping rates during this time. Follow the link below for more information and recommendations on how to minimize impact.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(53, 'wcship-2023-07-hazmat-update-needed', 'update', 'en_US', 'Action required: USPS HAZMAT compliance update for WooCommerce Shipping & Tax extension', '<strong>Your store requires an update for the WooCommerce Shipping extension</strong>. Please update to the latest version of the WooCommerce Shipping &amp; Tax extension immediately to ensure compliance with new USPS HAZMAT rules currently in effect.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(54, 'woocommerce-WCStripe-Aug-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooCommerce Stripe plugin', '<strong>Your shop requires an important security update for the  WooCommerce Stripe plugin</strong>. The fix for this vulnerability was released on July 31. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(55, 'woocommerce-WCStripe-Aug-2023-security-updated', 'update', 'en_US', 'Security update of WooCommerce Stripe plugin', '<strong>Your store has been updated to the latest secure version of the WooCommerce Stripe plugin</strong>. This update was released on July 31.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(56, 'woocommerce-WooPayments-Aug-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooPayments (WooCommerce Payments) plugin', '<strong>Your shop requires an important security update for the WooPayments (WooCommerce Payments) extension</strong>. The fix for this vulnerability was released on July 31. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(57, 'woocommerce-WooPayments-Aug-2023-security-updated', 'update', 'en_US', 'Security update of WooPayments (WooCommerce Payments) plugin', '<strong>Your store has been updated to the more secure version of WooPayments (WooCommerce Payments)</strong>. This update was released on July 31.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(58, 'avalara_q3-2023_noAvaTax', 'marketing', 'en_US', 'Automatically calculate VAT in real time', 'Take the effort out of determining tax rates and sell confidently across borders with automated tax management from Avalara AvaTax— including built-in VAT calculation when you sell into or across the EU and UK. Save time and stay compliant when you let Avalara do the heavy lifting.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(59, 'woo-activation-survey-blockers-22AUG23', 'info', 'en_US', 'How can we help you get that first sale?', 'Your feedback is vital. Please take a minute to share your experience of setting up your new store and whether anything is preventing you from making those first few sales. Together, we can make Woo even better!', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(60, 'woocommerce-usermeta-Sept2023-productvendors', 'update', 'en_US', 'Your store requires a security update', '<strong>Your shop needs an update to address a vulnerability in WooCommerce.</strong> The fix was released on Sept 15. Please update WooCommerce to the latest version immediately. <a href="https://developer.woocommerce.com/2023/09/16/woocommerce-vulnerability-reintroduced-from-7-0-1/" />Read our developer update</a> for more information.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(61, 'woocommerce-STRIPE-Oct-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooCommerce Stripe Gateway', '<strong>Your shop requires a security update to address a vulnerability in the WooCommerce Stripe Gateway</strong>. The fix for this vulnerability was released on October 17. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(62, 'amazon-mcf-reviews-2023-12-07', 'marketing', 'en_US', 'Enjoying Amazon MCF for WooCommerce?', 'We\'re Never Settle, the developers behind Amazon MCF for WooCommerce, and would be deeply honored to have your review. Reviews help immensely as other users can learn how MCF can solve their needs too! Not happy or need help? Please reach out for support and we’d love to make things right!', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(63, 'amazon_pay_reactivate_q1-24', 'marketing', 'en_US', 'Special offer: Activate 0% promo rate for Amazon Pay', 'For a limited time, Woo merchants who register with Amazon Pay can enjoy a promotional rate of 0% on all transaction fees for 30 days. Valid for businesses based in the United Kingdom. Terms and conditions apply.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(64, 'remove_estimated_deposits_2024', 'marketing', 'en_US', 'Estimated deposits are going away', 'To provide more accurate deposit information and support the expansion of instant deposits, estimated deposit details will no longer be available in WooPayments. We recommend upgrading to the latest version of WooPayments for more detailed balance status information.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(65, 'wc_admin_UKpricingchange_WCPay_Q1_2024', 'marketing', 'en_US', 'Fee Changes for WooPayments in the EEA and UK', 'WooPayments fees for transactions between the EEA and UK will change as of 1st March, 2024. Transactions between the UK and EEA are now deemed by card networks to be cross-border, thus international payment fees will be applicable. This also changes base processing fees.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(66, 'airwallex_q1_2024', 'marketing', 'en_US', 'Save big on foreign exchange (FX) fees', 'Boost your international sales by offering Apple Pay, Google Pay, and 60+ local payment methods with Airwallex. Save time and money by settling payments directly in USD, EUR, HKD, SGD, AUD, and more — without the extra FX fees. Simple, cost-effective, fast.', '[]', 'pending', 'woocommerce.com', '2024-03-08 12:21:50', NULL, 0, 'plain', '', 0, 0, 'info') ;

#
# End of data contents of table `wp_wc_admin_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_category_lookup`
#

DROP TABLE IF EXISTS `wp_wc_category_lookup`;


#
# Table structure of table `wp_wc_category_lookup`
#

CREATE TABLE `wp_wc_category_lookup` (
  `category_tree_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`category_tree_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_category_lookup`
#

#
# End of data contents of table `wp_wc_category_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_customer_lookup`
#

DROP TABLE IF EXISTS `wp_wc_customer_lookup`;


#
# Table structure of table `wp_wc_customer_lookup`
#

CREATE TABLE `wp_wc_customer_lookup` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(60) NOT NULL DEFAULT '',
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) NOT NULL DEFAULT '',
  `postcode` varchar(20) NOT NULL DEFAULT '',
  `city` varchar(100) NOT NULL DEFAULT '',
  `state` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_customer_lookup`
#

#
# End of data contents of table `wp_wc_customer_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_download_log`
#

DROP TABLE IF EXISTS `wp_wc_download_log`;


#
# Table structure of table `wp_wc_download_log`
#

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_download_log`
#

#
# End of data contents of table `wp_wc_download_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_addresses`
#

DROP TABLE IF EXISTS `wp_wc_order_addresses`;


#
# Table structure of table `wp_wc_order_addresses`
#

CREATE TABLE `wp_wc_order_addresses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `address_type` varchar(20) DEFAULT NULL,
  `first_name` text DEFAULT NULL,
  `last_name` text DEFAULT NULL,
  `company` text DEFAULT NULL,
  `address_1` text DEFAULT NULL,
  `address_2` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `postcode` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  `email` varchar(320) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address_type_order_id` (`address_type`,`order_id`),
  KEY `order_id` (`order_id`),
  KEY `email` (`email`(191)),
  KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_order_addresses`
#
INSERT INTO `wp_wc_order_addresses` ( `id`, `order_id`, `address_type`, `first_name`, `last_name`, `company`, `address_1`, `address_2`, `city`, `state`, `postcode`, `country`, `email`, `phone`) VALUES
(1, 135, 'billing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AU', 'admin@email.com', NULL),
(2, 135, 'shipping', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AU', NULL, NULL) ;

#
# End of data contents of table `wp_wc_order_addresses`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_coupon_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_coupon_lookup`;


#
# Table structure of table `wp_wc_order_coupon_lookup`
#

CREATE TABLE `wp_wc_order_coupon_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_id`,`coupon_id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_order_coupon_lookup`
#

#
# End of data contents of table `wp_wc_order_coupon_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_operational_data`
#

DROP TABLE IF EXISTS `wp_wc_order_operational_data`;


#
# Table structure of table `wp_wc_order_operational_data`
#

CREATE TABLE `wp_wc_order_operational_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `created_via` varchar(100) DEFAULT NULL,
  `woocommerce_version` varchar(20) DEFAULT NULL,
  `prices_include_tax` tinyint(1) DEFAULT NULL,
  `coupon_usages_are_counted` tinyint(1) DEFAULT NULL,
  `download_permission_granted` tinyint(1) DEFAULT NULL,
  `cart_hash` varchar(100) DEFAULT NULL,
  `new_order_email_sent` tinyint(1) DEFAULT NULL,
  `order_key` varchar(100) DEFAULT NULL,
  `order_stock_reduced` tinyint(1) DEFAULT NULL,
  `date_paid_gmt` datetime DEFAULT NULL,
  `date_completed_gmt` datetime DEFAULT NULL,
  `shipping_tax_amount` decimal(26,8) DEFAULT NULL,
  `shipping_total_amount` decimal(26,8) DEFAULT NULL,
  `discount_tax_amount` decimal(26,8) DEFAULT NULL,
  `discount_total_amount` decimal(26,8) DEFAULT NULL,
  `recorded_sales` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_id` (`order_id`),
  KEY `order_key` (`order_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_order_operational_data`
#
INSERT INTO `wp_wc_order_operational_data` ( `id`, `order_id`, `created_via`, `woocommerce_version`, `prices_include_tax`, `coupon_usages_are_counted`, `download_permission_granted`, `cart_hash`, `new_order_email_sent`, `order_key`, `order_stock_reduced`, `date_paid_gmt`, `date_completed_gmt`, `shipping_tax_amount`, `shipping_total_amount`, `discount_tax_amount`, `discount_total_amount`, `recorded_sales`) VALUES
(1, 135, 'store-api', '8.6.1', 0, 0, 0, 'c729bd885aa7b0960cd08c20f1c9fd2b', 0, 'wc_order_FXIihL5zmTNTV', 0, NULL, NULL, '0.00000000', '0.00000000', '0.00000000', '0.00000000', 0) ;

#
# End of data contents of table `wp_wc_order_operational_data`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_product_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_product_lookup`;


#
# Table structure of table `wp_wc_order_product_lookup`
#

CREATE TABLE `wp_wc_order_product_lookup` (
  `order_item_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variation_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT 0,
  `product_gross_revenue` double NOT NULL DEFAULT 0,
  `coupon_amount` double NOT NULL DEFAULT 0,
  `tax_amount` double NOT NULL DEFAULT 0,
  `shipping_amount` double NOT NULL DEFAULT 0,
  `shipping_tax_amount` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_order_product_lookup`
#

#
# End of data contents of table `wp_wc_order_product_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_stats`
#

DROP TABLE IF EXISTS `wp_wc_order_stats`;


#
# Table structure of table `wp_wc_order_stats`
#

CREATE TABLE `wp_wc_order_stats` (
  `order_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_paid` datetime DEFAULT '0000-00-00 00:00:00',
  `date_completed` datetime DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT 0,
  `total_sales` double NOT NULL DEFAULT 0,
  `tax_total` double NOT NULL DEFAULT 0,
  `shipping_total` double NOT NULL DEFAULT 0,
  `net_total` double NOT NULL DEFAULT 0,
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_order_stats`
#

#
# End of data contents of table `wp_wc_order_stats`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_tax_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_tax_lookup`;


#
# Table structure of table `wp_wc_order_tax_lookup`
#

CREATE TABLE `wp_wc_order_tax_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT 0,
  `order_tax` double NOT NULL DEFAULT 0,
  `total_tax` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_id`,`tax_rate_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_order_tax_lookup`
#

#
# End of data contents of table `wp_wc_order_tax_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_orders`
#

DROP TABLE IF EXISTS `wp_wc_orders`;


#
# Table structure of table `wp_wc_orders`
#

CREATE TABLE `wp_wc_orders` (
  `id` bigint(20) unsigned NOT NULL,
  `status` varchar(20) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `tax_amount` decimal(26,8) DEFAULT NULL,
  `total_amount` decimal(26,8) DEFAULT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `billing_email` varchar(320) DEFAULT NULL,
  `date_created_gmt` datetime DEFAULT NULL,
  `date_updated_gmt` datetime DEFAULT NULL,
  `parent_order_id` bigint(20) unsigned DEFAULT NULL,
  `payment_method` varchar(100) DEFAULT NULL,
  `payment_method_title` text DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `ip_address` varchar(100) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `customer_note` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `date_created` (`date_created_gmt`),
  KEY `customer_id_billing_email` (`customer_id`,`billing_email`(171)),
  KEY `billing_email` (`billing_email`(191)),
  KEY `type_status_date` (`type`,`status`,`date_created_gmt`),
  KEY `parent_order_id` (`parent_order_id`),
  KEY `date_updated` (`date_updated_gmt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_orders`
#
INSERT INTO `wp_wc_orders` ( `id`, `status`, `currency`, `type`, `tax_amount`, `total_amount`, `customer_id`, `billing_email`, `date_created_gmt`, `date_updated_gmt`, `parent_order_id`, `payment_method`, `payment_method_title`, `transaction_id`, `ip_address`, `user_agent`, `customer_note`) VALUES
(135, 'wc-checkout-draft', 'USD', 'shop_order', '0.00000000', '23.00000000', 1, 'admin@email.com', '2024-03-09 03:45:06', '2024-03-09 04:50:39', 0, '', '', '', '172.25.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0', '') ;

#
# End of data contents of table `wp_wc_orders`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_orders_meta`
#

DROP TABLE IF EXISTS `wp_wc_orders_meta`;


#
# Table structure of table `wp_wc_orders_meta`
#

CREATE TABLE `wp_wc_orders_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meta_key_value` (`meta_key`(100),`meta_value`(82)),
  KEY `order_id_meta_key_meta_value` (`order_id`,`meta_key`(100),`meta_value`(82))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_orders_meta`
#
INSERT INTO `wp_wc_orders_meta` ( `id`, `order_id`, `meta_key`, `meta_value`) VALUES
(1, 135, '_shipping_hash', '9d4568c009d203ab10e33ea9953a0264'),
(2, 135, '_coupons_hash', 'd751713988987e9331980363e24189ce'),
(3, 135, '_fees_hash', 'd751713988987e9331980363e24189ce'),
(4, 135, '_taxes_hash', 'd751713988987e9331980363e24189ce'),
(5, 135, 'is_vat_exempt', 'no'),
(6, 135, '_billing_address_index', '        AU admin@email.com '),
(7, 135, '_shipping_address_index', '        AU ') ;

#
# End of data contents of table `wp_wc_orders_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_attributes_lookup`
#

DROP TABLE IF EXISTS `wp_wc_product_attributes_lookup`;


#
# Table structure of table `wp_wc_product_attributes_lookup`
#

CREATE TABLE `wp_wc_product_attributes_lookup` (
  `product_id` bigint(20) NOT NULL,
  `product_or_parent_id` bigint(20) NOT NULL,
  `taxonomy` varchar(32) NOT NULL,
  `term_id` bigint(20) NOT NULL,
  `is_variation_attribute` tinyint(1) NOT NULL,
  `in_stock` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_or_parent_id`,`term_id`,`product_id`,`taxonomy`),
  KEY `is_variation_attribute_term_id` (`is_variation_attribute`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_product_attributes_lookup`
#

#
# End of data contents of table `wp_wc_product_attributes_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_download_directories`
#

DROP TABLE IF EXISTS `wp_wc_product_download_directories`;


#
# Table structure of table `wp_wc_product_download_directories`
#

CREATE TABLE `wp_wc_product_download_directories` (
  `url_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(256) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`url_id`),
  KEY `url` (`url`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_product_download_directories`
#
INSERT INTO `wp_wc_product_download_directories` ( `url_id`, `url`, `enabled`) VALUES
(1, 'file:///var/www/html/wp-content/uploads/woocommerce_uploads/', 1),
(2, 'http://localhost:82/wp-content/uploads/woocommerce_uploads/', 1) ;

#
# End of data contents of table `wp_wc_product_download_directories`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_meta_lookup`
#

DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;


#
# Table structure of table `wp_wc_product_meta_lookup`
#

CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) DEFAULT '',
  `virtual` tinyint(1) DEFAULT 0,
  `downloadable` tinyint(1) DEFAULT 0,
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT 0,
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `total_sales` bigint(20) DEFAULT 0,
  `tax_status` varchar(100) DEFAULT 'taxable',
  `tax_class` varchar(100) DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_product_meta_lookup`
#
INSERT INTO `wp_wc_product_meta_lookup` ( `product_id`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`, `total_sales`, `tax_status`, `tax_class`) VALUES
(20, '', 0, 0, '19.9900', '19.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(21, '', 0, 0, '19.9900', '19.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(22, '', 0, 0, '9.9900', '9.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(23, '', 0, 0, '9.9900', '9.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(24, '', 0, 0, '9.9900', '9.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(25, '', 0, 0, '9.9900', '9.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(26, '', 0, 0, '9.9900', '9.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(27, '', 0, 0, '7.9900', '7.9900', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(28, '', 0, 0, '14.9900', '14.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(29, '', 0, 0, '14.9900', '14.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(30, '', 0, 0, '14.9900', '14.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(31, '', 0, 0, '14.9900', '14.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(32, '', 0, 0, '14.9900', '14.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(33, '', 0, 0, '14.9900', '14.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(34, '', 0, 0, '14.9900', '14.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(35, '', 0, 0, '14.9900', '14.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(36, '', 0, 0, '14.9900', '14.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(37, '', 0, 0, '14.9900', '14.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(38, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(39, '', 0, 0, '12.9900', '12.9900', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(40, '', 0, 0, '12.9900', '12.9900', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(41, '', 0, 0, '12.9900', '12.9900', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(42, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(43, '', 0, 0, '12.9900', '12.9900', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(44, '', 0, 0, '12.9900', '12.9900', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(45, '', 0, 0, '12.9900', '12.9900', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(46, '', 0, 0, '34.9900', '39.9900', 0, NULL, 'outofstock', 0, '0.00', 0, 'taxable', ''),
(47, '', 0, 0, '39.9900', '39.9900', 0, NULL, 'outofstock', 0, '0.00', 0, 'taxable', 'parent'),
(48, '', 0, 0, '34.9900', '34.9900', 0, NULL, 'outofstock', 0, '0.00', 0, 'taxable', 'parent'),
(49, '', 0, 0, '34.9900', '34.9900', 0, NULL, 'outofstock', 0, '0.00', 0, 'taxable', 'parent'),
(64, '', 0, 0, '44.9900', '44.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(65, '', 0, 0, '44.9900', '44.9900', 0, '100', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(66, '', 0, 0, '44.9900', '44.9900', 0, '2', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(67, '', 0, 0, '44.9900', '44.9900', 0, '33', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(68, '', 0, 0, '34.9900', '34.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(69, '', 0, 0, '34.9900', '34.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(70, '', 0, 0, '34.9900', '34.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(71, '', 0, 0, '34.9900', '34.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(72, '', 0, 0, '29.9900', '29.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(81, '', 0, 0, '29.9900', '29.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(82, '', 0, 0, '29.9900', '29.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(83, '', 0, 0, '29.9900', '29.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(84, '', 0, 0, '27.9900', '27.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(85, '', 0, 0, '27.9900', '27.9900', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(86, '', 0, 0, '27.9900', '27.9900', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(87, '', 0, 0, '27.9900', '27.9900', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(88, '', 0, 0, '27.9900', '27.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(89, '', 0, 0, '27.9900', '27.9900', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(90, '', 0, 0, '27.9900', '27.9900', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(91, '', 0, 0, '27.9900', '27.9900', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(92, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'onbackorder', 0, '0.00', 0, 'taxable', ''),
(93, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'onbackorder', 0, '0.00', 0, 'taxable', 'parent'),
(94, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'onbackorder', 0, '0.00', 0, 'taxable', 'parent'),
(95, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'onbackorder', 0, '0.00', 0, 'taxable', 'parent'),
(96, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(97, '', 0, 0, '12.9900', '14.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(98, '', 0, 0, '14.9900', '14.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(99, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(100, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(101, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(102, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(103, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(104, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(105, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(106, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(107, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(108, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(109, '', 0, 0, '12.9900', '12.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent') ;

#
# End of data contents of table `wp_wc_product_meta_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_rate_limits`
#

DROP TABLE IF EXISTS `wp_wc_rate_limits`;


#
# Table structure of table `wp_wc_rate_limits`
#

CREATE TABLE `wp_wc_rate_limits` (
  `rate_limit_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rate_limit_key` varchar(200) NOT NULL,
  `rate_limit_expiry` bigint(20) unsigned NOT NULL,
  `rate_limit_remaining` smallint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`rate_limit_id`),
  UNIQUE KEY `rate_limit_key` (`rate_limit_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_rate_limits`
#

#
# End of data contents of table `wp_wc_rate_limits`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_reserved_stock`
#

DROP TABLE IF EXISTS `wp_wc_reserved_stock`;


#
# Table structure of table `wp_wc_reserved_stock`
#

CREATE TABLE `wp_wc_reserved_stock` (
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT 0,
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_reserved_stock`
#

#
# End of data contents of table `wp_wc_reserved_stock`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_tax_rate_classes`
#

DROP TABLE IF EXISTS `wp_wc_tax_rate_classes`;


#
# Table structure of table `wp_wc_tax_rate_classes`
#

CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_tax_rate_classes`
#
INSERT INTO `wp_wc_tax_rate_classes` ( `tax_rate_class_id`, `name`, `slug`) VALUES
(1, 'Reduced rate', 'reduced-rate'),
(2, 'Zero rate', 'zero-rate') ;

#
# End of data contents of table `wp_wc_tax_rate_classes`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_webhooks`
#

DROP TABLE IF EXISTS `wp_wc_webhooks`;


#
# Table structure of table `wp_wc_webhooks`
#

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) NOT NULL,
  `name` text NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text NOT NULL,
  `secret` text NOT NULL,
  `topic` varchar(200) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT 0,
  `pending_delivery` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wc_webhooks`
#

#
# End of data contents of table `wp_wc_webhooks`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_api_keys`
#

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;


#
# Table structure of table `wp_woocommerce_api_keys`
#

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `permissions` varchar(10) NOT NULL,
  `consumer_key` char(64) NOT NULL,
  `consumer_secret` char(43) NOT NULL,
  `nonces` longtext DEFAULT NULL,
  `truncated_key` char(7) NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_api_keys`
#

#
# End of data contents of table `wp_woocommerce_api_keys`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;


#
# Table structure of table `wp_woocommerce_attribute_taxonomies`
#

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) NOT NULL,
  `attribute_label` varchar(200) DEFAULT NULL,
  `attribute_type` varchar(20) NOT NULL,
  `attribute_orderby` varchar(20) NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_attribute_taxonomies`
#
INSERT INTO `wp_woocommerce_attribute_taxonomies` ( `attribute_id`, `attribute_name`, `attribute_label`, `attribute_type`, `attribute_orderby`, `attribute_public`) VALUES
(1, 'size', 'Size', 'select', 'menu_order', 0),
(2, 'color', 'Color', 'select', 'menu_order', 0),
(3, 'brand', 'Brand', 'select', 'menu_order', 0) ;

#
# End of data contents of table `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `wp_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `order_key` varchar(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`),
  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_downloadable_product_permissions`
#

#
# End of data contents of table `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_log`
#

DROP TABLE IF EXISTS `wp_woocommerce_log`;


#
# Table structure of table `wp_woocommerce_log`
#

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) NOT NULL,
  `message` longtext NOT NULL,
  `context` longtext DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_log`
#

#
# End of data contents of table `wp_woocommerce_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;


#
# Table structure of table `wp_woocommerce_order_itemmeta`
#

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_order_itemmeta`
#
INSERT INTO `wp_woocommerce_order_itemmeta` ( `meta_id`, `order_item_id`, `meta_key`, `meta_value`) VALUES
(11, 2, '_product_id', '22'),
(12, 2, '_variation_id', '24'),
(13, 2, '_qty', '1'),
(14, 2, '_tax_class', ''),
(15, 2, '_line_subtotal', '9.99'),
(16, 2, '_line_subtotal_tax', '0'),
(17, 2, '_line_total', '9.99'),
(18, 2, '_line_tax', '0'),
(19, 2, '_line_tax_data', 'a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}'),
(20, 2, 'pa_brand', 'divi-engine'),
(21, 3, '_product_id', '97'),
(22, 3, '_variation_id', '99'),
(23, 3, '_qty', '1'),
(24, 3, '_tax_class', ''),
(25, 3, '_line_subtotal', '12.99'),
(26, 3, '_line_subtotal_tax', '0'),
(27, 3, '_line_total', '12.99'),
(28, 3, '_line_tax', '0'),
(29, 3, '_line_tax_data', 'a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}'),
(30, 3, 'pa_size', 'medium') ;

#
# End of data contents of table `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_items`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;


#
# Table structure of table `wp_woocommerce_order_items`
#

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text NOT NULL,
  `order_item_type` varchar(200) NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_order_items`
#
INSERT INTO `wp_woocommerce_order_items` ( `order_item_id`, `order_item_name`, `order_item_type`, `order_id`) VALUES
(2, 'Brand Buttons - Divi Engine', 'line_item', 135),
(3, 'Dat Divi Engine Life Crop-top (3-Tone) - Medium', 'line_item', 135) ;

#
# End of data contents of table `wp_woocommerce_order_items`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokenmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;


#
# Table structure of table `wp_woocommerce_payment_tokenmeta`
#

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_payment_tokenmeta`
#

#
# End of data contents of table `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokens`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;


#
# Table structure of table `wp_woocommerce_payment_tokens`
#

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) NOT NULL,
  `token` text NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `type` varchar(200) NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_payment_tokens`
#

#
# End of data contents of table `wp_woocommerce_payment_tokens`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_sessions`
#

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;


#
# Table structure of table `wp_woocommerce_sessions`
#

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) NOT NULL,
  `session_value` longtext NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_sessions`
#
INSERT INTO `wp_woocommerce_sessions` ( `session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(1, '1', 'a:13:{s:4:"cart";s:909:"a:2:{s:32:"dc25f4a9d74ad68f32fc16d92a9c4ede";a:11:{s:3:"key";s:32:"dc25f4a9d74ad68f32fc16d92a9c4ede";s:10:"product_id";i:22;s:12:"variation_id";i:24;s:9:"variation";a:1:{s:18:"attribute_pa_brand";s:11:"divi-engine";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"1b8635a39c699a108e940a9143e942c9";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:9.99;s:17:"line_subtotal_tax";d:0;s:10:"line_total";d:9.99;s:8:"line_tax";d:0;}s:32:"f9222c921b0d369a2c2dd47100871222";a:11:{s:3:"key";s:32:"f9222c921b0d369a2c2dd47100871222";s:10:"product_id";i:97;s:12:"variation_id";i:99;s:9:"variation";a:1:{s:17:"attribute_pa_size";s:6:"medium";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"4f1d32f51df2903a4f5e7fbcb17bb2d0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:12.99;s:17:"line_subtotal_tax";d:0;s:10:"line_total";d:12.99;s:8:"line_tax";d:0;}}";s:11:"cart_totals";s:390:"a:15:{s:8:"subtotal";s:2:"23";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:1:"0";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:2:"23";s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:2:"23";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:758:"a:27:{s:2:"id";s:1:"1";s:13:"date_modified";s:25:"2024-03-09T03:43:37+00:00";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"AU";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"AU";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:15:"admin@email.com";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";s:14:"shipping_phone";s:0:"";}";s:10:"wc_notices";N;s:22:"shipping_for_package_0";s:92:"a:2:{s:12:"package_hash";s:40:"wc_ship_0a2262c24e3de31f598ee3722aabc8d2";s:5:"rates";a:0:{}}";s:25:"previous_shipping_methods";s:16:"a:1:{i:0;a:0:{}}";s:23:"chosen_shipping_methods";s:14:"a:1:{i:0;b:0;}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:0;}";s:21:"store_api_draft_order";i:135;}', 1710083243) ;

#
# End of data contents of table `wp_woocommerce_sessions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;


#
# Table structure of table `wp_woocommerce_shipping_zone_locations`
#

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) NOT NULL,
  `location_type` varchar(40) NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_locations`
#
INSERT INTO `wp_woocommerce_shipping_zone_locations` ( `location_id`, `zone_id`, `location_code`, `location_type`) VALUES
(1, 1, 'VN', 'country') ;

#
# End of data contents of table `wp_woocommerce_shipping_zone_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_methods`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;


#
# Table structure of table `wp_woocommerce_shipping_zone_methods`
#

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_methods`
#
INSERT INTO `wp_woocommerce_shipping_zone_methods` ( `zone_id`, `instance_id`, `method_id`, `method_order`, `is_enabled`) VALUES
(1, 1, 'free_shipping', 1, 1) ;

#
# End of data contents of table `wp_woocommerce_shipping_zone_methods`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zones`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;


#
# Table structure of table `wp_woocommerce_shipping_zones`
#

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_shipping_zones`
#
INSERT INTO `wp_woocommerce_shipping_zones` ( `zone_id`, `zone_name`, `zone_order`) VALUES
(1, 'Vietnam', 0) ;

#
# End of data contents of table `wp_woocommerce_shipping_zones`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;


#
# Table structure of table `wp_woocommerce_tax_rate_locations`
#

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_tax_rate_locations`
#

#
# End of data contents of table `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;


#
# Table structure of table `wp_woocommerce_tax_rates`
#

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) NOT NULL DEFAULT '',
  `tax_rate` varchar(8) NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT 0,
  `tax_rate_shipping` int(1) NOT NULL DEFAULT 1,
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_tax_rates`
#

#
# End of data contents of table `wp_woocommerce_tax_rates`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

